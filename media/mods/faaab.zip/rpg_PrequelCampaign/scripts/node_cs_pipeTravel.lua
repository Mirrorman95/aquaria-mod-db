dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
cam = 0

function init(me)
	if isFlag(CS_PIPETRAVEL, 1) then
		n = getNaija()
		loadSound("waterfallloop")

		playSfx("waterfallloop", 0)	
	
		entity_setPosition(n, 0, 0)
		cam = createEntity("empty")
		start = getNode("start")
		finish = getNode("finish")

		overrideZoom(0.6)
		entity_warpToNode(cam, start) 
		cam_toEntity(cam)

		fade(0, 5, 0, 0, 0)

		entity_followPath(cam, start, SPEED_NORMAL, 0)

		--entity_setPosition(cam, node_x(finish), node_y(finish), 15)
		--entity_setPosition(cam, node_x(finish), node_y(finish), 15, 0, 0, 10)

		watch(5)

		playSfx("naijasigh1")

		entity_watchForPath(cam)

		--fade2(1, 3, 1, 1, 1)

		setFlag(CS_PIPETRAVEL, 0)
		--setFlag(CS_PIPEEXIT, 1)
		loadMap("rpg_forestWalker", "exit")	
	end
end


function update(me, dt)
end