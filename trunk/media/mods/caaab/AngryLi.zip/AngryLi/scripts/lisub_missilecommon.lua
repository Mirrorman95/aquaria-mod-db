dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/AngryLi/scripts/include.lua"))

n = 0

STATE_DROPPED = 234
STATE_RUN = 567

lifeTime = 1
 
function commonInit(me, pDmg, anim)
 
	dmg = pDmg

	setupEntity(me)
 
	-- set entity graphic
	entity_setTexture(me,"lisub/li-sub-missile")
	
	entity_initSkeletal(me, "missile")
	entity_animate(me, anim, -1)
	missile = entity_getBoneByName(me, "missile")
	
	-- entity_initSkeletal(me, "00_starter")
	-- entity_scale(me, 1, 0.5)
	
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setHealth(me, 1)
	entity_setCollideRadius(me, 20)
	entity_setUpdateCull(me, -1)
	
	entity_setDeathParticleEffect(me, "explode")
	
	entity_setMaxSpeed(me, 4000)

	-- entity_setState(me, STATE_DROPPED, 0.2)
	entity_setState(me, STATE_RUN)
	entity_setBounceType(me, BOUNCE_NONE)
	
	wideScreenAmount = getFlag(WIDESCREEN_AMOUNT)
	entity_setBeautyFlip(me, false)
	
	lisub = getEntity('lisub')

end
 
function postInit(me)
end
 
 BubblesTimer = 0

 -- BOOM !!! 
 function boom(me, ent)

	-- remove trail sound
	fadeSfx(sfx,0.5)
	sfx = playSfx("bossdiesmall", 0, 0.2)
	fadeSfx(sfx,0.4)
	spawnParticleEffect("fertilizer", entity_getPosition(me))
	-- spawnParticleEffect("explode", entity_getPosition(me))
	
	if ent~=0 then entity_damage(ent, me, dmg) end
	
	-- don't delete immediately because the particle effect will disappear
	bone_alpha(missile,0)
	entity_delete(me, 5)
end
 
function update(me, dt)
 
	if entity_isState(me, STATE_RUN) then
	
		scx, scy = toWindowFromWorld(entity_getPosition(me))
		
		-- delete if is offscreen
		if scx < -wideScreenAmount or scy < 0 or scx > 800 + wideScreenAmount or scy > 600 then
			entity_delete(me)
		end
		
		-- delete if no time left
		lifeTime = lifeTime - dt
		if lifeTime <= 0 then
			entity_delete(me)
		end
	
		-- bubble trail
		--BubblesTimer = BubblesTimer - dt			
		--if BubblesTimer <= 0 then				
			--BubblesTimer = 0.01 + BubblesTimer
			-- spawnParticleEffect("lisubmissilebb", entity_x(me), entity_y(me))
		--end
	end
	
	-- spawnParticleEffect("lisubexplode", entity_getPosition(me))
	
	-- ent = entity_getNearestEntity(me)
	ent = entity_getNearestEntity(me, "", 100, ET_ENEMY)

	if ent ~= 0
	and entity_getDistanceToEntity(me, ent) <= entity_getCollideRadius(me) + entity_getCollideRadius(ent) then
		boom(me, ent)
	elseif isObstructed(entity_getPosition(me)) then
		boom(me, 0)
	end
	
	entity_updateMovement(me, dt)
end

function hitSurface(me)
	boom(me, ent)
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end
 
function dieNormal(me)
end
 
function enterState(me)

	if entity_isState(me, STATE_DROPPED) then
		entity_setWeight(me, 2000)
		-- entity_setState(me, STATE_IDLE)
	elseif entity_isState(me, STATE_RUN) then
		entity_clearVel(me)
		entity_setWeight(me, 0)
		--entity_setMaxSpeedLerp(me, 0.1)
		--entity_setMaxSpeedLerp(me, 2, 0.5)
		
		if entity_isfh(lisub) then
			entity_addVel(me, 2000, 0)
		else
			entity_addVel(me, -2000, 0)
			entity_fhTo(me, true)
		end
		-- entity_setMaxSpeedLerp(me, 1, 2)
		
		-- entity_sound(me, "airship-boost", 2000, 0.7)
		
		sfx = playSfx("airship-boost", 0, 0.6)
		fadeSfx(sfx, 2)
		
		-- entity_setState(me, STATE_IDLE)
	end

end
 
function exitState(me)

	if entity_isState(me, STATE_DROPPED) then
		entity_setState(me, STATE_RUN)
	end

end
 
function songNote(me, note)
end
 
function songNoteDone(me, note)
end
 
function song(me, song)
end
 
function activate(me)
end