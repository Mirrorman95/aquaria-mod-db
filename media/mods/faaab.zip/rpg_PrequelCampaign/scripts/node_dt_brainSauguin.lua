dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))
dofile("scripts/entities/entityinclude.lua")

imagePath = "panels/Sauguin/panelSauguin_"
entityOther = "rpg_Sauguin"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = 0
flagRepeat = 0
flagVersion = DT_VERSION_SAUGUIN
flagMain = 0

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3",		"3",		"exit"	},
		{"3", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5b",		0		},
		{"5a", 				"other",		"6"								},
		{"5b", 				"other",		"6"								},
		{"6", 				"elena",		"7a",		"7b",		"7c"	},
		{"7a", 				"other",		"8"								},
		{"7b", 				"other",		"8"								},
		{"7c", 				"other",		"8"								},
		{"8", 				"elena",		"9a",		"9b",		0		},
		{"9a", 				"other",		"10"							},
		{"9b", 				"other",		"10"							},
		{"10", 				"elena",		"11a",		"11b",		0		},
		{"11a", 			"other",		"exit"							},
		{"11b", 			"other",		"exit"							},
	}
	
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 11A or 11b (2 fixed when combat starts)
		if numPanel == "11a" or numPanel == "11b" then
			nodeClickableOnExit = false
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 2 or 11A
		if numPanel == "2" or numPanel == "11a" then
			entity_delete(chatBubble, 1)
			
			entity_setPosition(n, x + 100, y)
			setFlag(MORAL_SAUGUIN, 1)
		
		--PANEL 11B
		elseif numPanel == "11b" then
			playSfx("mia-appear")
			spawnParticleEffect("MiaWarp", x, y)
			entity_delete(mapEntity, 2)
			entity_delete(chatBubble, 2)				

			setFlag(MORAL_SAUGUIN, 2)
			
			entity_setPosition(n, x + 100, y)
			watch(2)
			createEntity("crystal_large", "", x, y)
			playSfx("secret", 0, 0.5)
		end
	end
				
	numPanel = "1"
	currentRowID = 1
end

door = 0
--INIT
function init(me)	
	door = node_getNearestEntity(me, "EnergyDoor")
	entity_setState(door, STATE_OPENED)

	if isFlag(MORAL_SAUGUIN, 0) then
		CommonInit(me)
		CreateMapEntity(entityOther, x, y, 1)
		CreateChatBubble(x - 40, y - 80, 1)
		
		loadSound("mia-appear")
	end
end

started = false
--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
	
	if isFlag(MORAL_SAUGUIN, 1) then
		if started == false then
			started = true

			node_setCursorActivation(me, false)
			
			playMusic("bigboss")
			overrideZoom(0.4, 4)

			entity_setState(door, STATE_CLOSE)
			entity_setState(mapEntity, STATE_IDLE)
		else
			c = 0
			e = getFirstEntity()
			while e ~= 0 do
				if entity_getEntityType(e) == ET_ENEMY and entity_isName(e, "rpg_sauguin") then			
					c = c + 1
				end
				e = getNextEntity()
			end

			if c == 0 then
				setFlag(MORAL_SAUGUIN, 2)

				updateMusic()
				overrideZoom(0)
				entity_setState(door, STATE_OPEN)
			end
		end
	end
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end