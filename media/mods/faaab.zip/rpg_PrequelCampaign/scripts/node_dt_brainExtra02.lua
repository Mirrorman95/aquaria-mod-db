dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Extras/Cathedral/panelExtra02_"
entityOther = "priestnormal"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = DT_NEW_EXTRA02
flagRepeat = 0
flagVersion = DT_VERSION_EXTRA02
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"elena",		"3a",		"3b",		0		},
		{"3a",				"other",		"4"								},
		{"3b",				"other",		"3be1"							},
		{"3be1",			"other",		"4"								},
		{"4",				"elena",		"5a",		"5b",		"5c"	},
		{"5a",				"other",		"exit"							},
		{"5b",				"other",		"exit"							},
		{"5c",				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 5A-5C
		if numPanel == "5a" or numPanel == "5b" or numPanel == "5c" then
			AlphaChatBubble()
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	CreateMapEntity(entityOther, x, y - 30, 0)
	CreateChatBubble(x + 50, y - 110, 0)
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end