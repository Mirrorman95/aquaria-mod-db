dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 11
holderID = 14
flag = ED_OPENWATERS_HEALTH_1

dofile("scripts/include/energyslottemplate.lua")