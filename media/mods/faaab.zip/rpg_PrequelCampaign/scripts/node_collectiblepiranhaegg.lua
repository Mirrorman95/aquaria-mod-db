dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	debugLog("CollectiblePiranhaEgg")
	commonInit(me, "CollectiblePiranhaEgg", FLAG_COLLECTIBLE_PIRANHAEGG)
end

function update(me, dt)
end
