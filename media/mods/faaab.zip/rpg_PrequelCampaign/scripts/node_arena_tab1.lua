dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, false)	
end

function update(me, dt)
	
end

function activate(me)
	playSfx("click")

	setFlag(MENU_TAB, 1)
	setFlag(MENU_CHANGE_MODE, 1)

	node_setCursorActivation(me, false)
end