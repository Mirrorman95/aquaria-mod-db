dofile("scripts/entities/entityinclude.lua")

n = 0
done = false
function init(me)
	n = getNaija()
end
	
function activate(me)
end

function update(me, dt)
	if isFlag(FLAG_MINIBOSS_KINGJELLY, 0) and not done then
		if node_isEntityIn(me, n) then
			done = true
			kingJelly = node_getNearestEntity(me, "KingJelly")
			if kingJelly ~=0 then
				debugLog("has king jelly")
				playMusic("inevitable")
				cam_toEntity(kingJelly)
				watch(2)
				entity_setState(kingJelly, STATE_DESCEND)
				watch(3)
				cam_toEntity(n)
			else
				debugLog("Could not find king jelly")
			end
		end
	end
end
