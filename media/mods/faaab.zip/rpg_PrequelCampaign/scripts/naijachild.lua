dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_initSkeletal(me, "NaijaChild")	
	entity_setAllDamageTargets(me, false)
	entity_scale(me, 0.55, 0.55)
	
	entity_fh(me)

	entity_setState(me, STATE_IDLE)
end

function postInit(me)
end

function update(me, dt)
	entity_updateCurrents(me, dt)
	--entity_rotateToVel(me, 0)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end

function exitState(me)
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end

function animationKey(me, key)
end

function hitSurface(me)
end

function songNote(me, note)
end

function songNoteDone(me, note)
end

function song(me, song)
end

function activate(me)
end

