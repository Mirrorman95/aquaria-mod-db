--[[ 
DEFEND MISSION CODE: by Danny O'Connell (vxnervegas [at] gmail [dot] com)
Waves of enemies are spawned at 20 second intervals once the event is started by the player.
Spawn locations and enemies are predetermined at the moment.
The final wave creates a miniboss (Nautilus Prime) that rewards the player with a pet and then tells this file that the player has succeeded.
]]--


dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
symbol = 0

spawn1 = 0
spawn2 = 0
spawn3 = 0
spawn4 = 0

energyDoor1 = 0
energyDoor2 = 0

createdMiniboss = false

waveNumber = 1
waveSetup = false
group1Spawned = false
group2Spawned = false
delayWave = 10
delaySpawn1 = 2
delaySpawn2 = 6


function init(me)
	n = getNaija()

	--SPAWN POINTS: for all enemies
	spawn1 = getNode("SPAWN1")
	spawn2 = getNode("SPAWN2")
	spawn3 = getNode("SPAWN3")
	spawn4 = getNode("SPAWN4")

	--BARRIERS: block the defend area off
	energyDoor1 = node_getNearestEntity(getNode("DOOR1"), "energydoor")
	energyDoor2 = node_getNearestEntity(getNode("DOOR2"), "energydoor")

	loadSound("mia-appear")
	loadSound("mia-scream")
	loadSound("mia-sillygirl")

	--UI: shows the player this node can be clicked to start an event
	symbol = createEntity("symbol_pet", "", node_x(me) + 40, node_y(me) - 350)
	node_setCursorActivation(me, true)

	--RESET MISSION: safety measure in case Mission is aborted in an unforseen way
	if getFlag(DEFEND_CRYSTALS) ~= 0 then
		setFlag(DEFEND_CRYSTALS, 0)
	end
end


function update(me, dt)

	--SCARY!: lock down defend area
	if isFlag(DEFEND_CRYSTALS, 1) then
		setFlag(DEFEND_CRYSTALS, 2)

		shakeCamera(10, 2)
		voice("laugh2")

		entity_alpha(symbol, 0, 1)
	
		entity_setState(energyDoor1, STATE_CLOSE)
		entity_setState(energyDoor2, STATE_CLOSE)

		--watch(2)

		playMusic("bigboss")

	--DEFEND!: handles all waves of enemies
	elseif isFlag(DEFEND_CRYSTALS, 2) then
		
		--DELAY START OF WAVE: inform the player that a wave is incoming 5 seconds before it does
		if delayWave > 0 then
			if delayWave < 5 and waveSetup == false then
				waveSetup = true
				centerText("Incoming! Wave " .. waveNumber .. "/4")
			end		

			delayWave = delayWave - dt

		--CREATE NEXT WAVE: whenever an entity is created a portal(MiaWarp) and SFX(mia-appear) are created
		else

			--WAVE 1
			if waveNumber == 1 then
				--SUCCESSFUL?: set variables for new wave only after current wave setup
				if group1Spawned == true and group2Spawned == true then
					group1Spawned = false
					group2Spawned = false
					delaySpawn1 = 2
					delaySpawn2 = 6	

					waveNumber = waveNumber + 1
					delayWave = 20
					waveSetup = false			
				else
					if delaySpawn1 > 0 then
						delaySpawn1 = delaySpawn1 - dt
					--SPAWN: group 1
					elseif group1Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
						spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))

						createEntity("squiddy", "", node_x(spawn2), node_y(spawn2))		
						createEntity("trillious", "", node_x(spawn2), node_y(spawn2))
						createEntity("blaster", "", node_x(spawn3), node_y(spawn3))

						group1Spawned = true
					end

					if delaySpawn2 > 0 then
						delaySpawn2 = delaySpawn2 - dt
					--SPAWN: group 2
					elseif group2Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
						spawnParticleEffect("MiaWarp", node_x(spawn4), node_y(spawn4))

						createEntity("nautilus", "", node_x(spawn1), node_y(spawn1))
						createEntity("nautilus", "", node_x(spawn4), node_y(spawn4))
						createEntity("tabar", "", node_x(spawn4), node_y(spawn4))

						group2Spawned = true
					end
				end

			--WAVE 2
			elseif waveNumber == 2 then
				--SUCCESSFUL?: set variables for new wave only after current wave setup
				if group1Spawned == true and group2Spawned == true then
					group1Spawned = false
					group2Spawned = false
					delaySpawn1 = 2
					delaySpawn2 = 6

					waveNumber = waveNumber + 1
					delayWave = 20
					waveSetup = false		
				else
					if delaySpawn1 > 0 then
						delaySpawn1 = delaySpawn1 - dt
					--SPAWN: group 1
					elseif group1Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
						spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))

						createEntity("pistolshrimp", "", node_x(spawn2), node_y(spawn2))
						createEntity("blaster", "", node_x(spawn3), node_y(spawn3))
						createEntity("nautilus", "", node_x(spawn2), node_y(spawn2))

						group1Spawned = true
					end

					if delaySpawn2 > 0 then
						delaySpawn2 = delaySpawn2 - dt
					--SPAWN: group 2
					elseif group2Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
						spawnParticleEffect("MiaWarp", node_x(spawn4), node_y(spawn4))

						createEntity("tromulo", "", node_x(spawn1), node_y(spawn1))
						createEntity("rednautilus", "", node_x(spawn1), node_y(spawn1))
						createEntity("blaster", "", node_x(spawn4), node_y(spawn4))
						
						group2Spawned = true
					end	
				end

			--WAVE 3
			elseif waveNumber == 3 then
				--SUCCESSFUL?: set variables for new wave only after current wave setup
				if group1Spawned == true and group2Spawned == true then
					group1Spawned = false
					group2Spawned = false
					delaySpawn1 = 2
					delaySpawn2 = 6	

					waveNumber = waveNumber + 1
					delayWave = 20
					waveSetup = false		
				else
					if delaySpawn1 > 0 then
						delaySpawn1 = delaySpawn1 - dt
					--SPAWN: group 1
					elseif group1Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
						spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))

						createEntity("nautilus", "", node_x(spawn1), node_y(spawn1))
						createEntity("nautilus", "", node_x(spawn3), node_y(spawn3))
						createEntity("squiddy", "", node_x(spawn3), node_y(spawn3))

						group1Spawned = true
					end

					if delaySpawn2 > 0 then
						delaySpawn2 = delaySpawn2 - dt
					--SPAWN: group 2
					elseif group2Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
						spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
						spawnParticleEffect("MiaWarp", node_x(spawn4), node_y(spawn4))

						createEntity("shark", "", node_x(spawn1), node_y(spawn1))
						createEntity("blaster", "", node_x(spawn2), node_y(spawn2))
						createEntity("blaster", "", node_x(spawn4), node_y(spawn4))

						group2Spawned = true
					end	
				end

			--WAVE 4
			elseif waveNumber == 4 then				
				--MINIBOSS: Optimus Prime gonna take you out (Nautilus Prime spawned)
				if createdMiniboss == false then
					createdMiniboss = true

					playSfx("mia-appear")
					spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
					createEntity("nautilusprime", "", node_x(spawn2), node_y(spawn2))
				end
			end
		end

	--WRAPUP: reset event and reward player
	elseif isFlag(DEFEND_CRYSTALS, 3) then
		setFlag(DEFEND_CRYSTALS, 4)
		--updateMusic()

		entity_setInvincible(n, true)
		entity_idle(n)
		entity_clearVel(n)

		--RESET: defend mission
		setFlag(DEFEND_CRYSTALS, 0)
		entity_alpha(symbol, 1, 1)
		entity_setState(energyDoor1, STATE_OPEN)
		entity_setState(energyDoor2, STATE_OPEN)

		--POSITIVE REINFORCEMENT: you're so good!
		setControlHint("Soul crystals successfully defended.",  0, 0, 0, 8)
		watch(4)

		--REWARD: 1 currency
		createEntity("crystal_small", "", entity_x(n), entity_y(n))
	end
end

--PLAYER CLICKED NODE
function activate(me)
	startDefend = confirm("Are you ready to defend against\nenemies attempting to steal the\nsouls from these crystals?", "buy")
	if startDefend == true then
		setFlag(DEFEND_CRYSTALS, 1)
		node_setCursorActivation(me, false)
		setControlHint("Defend the soul crystals against an onslaught of enemies!",  0, 0, 0, 5, "")
	end
end