dofile("scripts/include/sporechildflowertemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

active = false
done = false
function init(me)
	commonInit(me, "TubeFlower")
	entity_setName(me, "TubeFlower")
end

function update(me, dt)
	commonUpdate(me, dt)

	if entity_isEntityInRange(me, getNaija(), 356) then
		if entity_isFlag(me, 0) then
			entity_foundGem(me, "tubeflower")
			entity_setFlag(me, 1)
		end
	end

	if active and not done then
		if entity_isEntityInRange(me, getNaija(), 128) then
			done = true
			entity_sound(me, "TubeFlowerSuck")
			if isMapName("Tree02") then
				warpNaijaToSceneNode("Forest04", "FLOWERPORTAL_FROMBOSS")
			elseif isMapName("Forest04") then
				warpNaijaToSceneNode("Tree02", "FLOWERPORTAL_FROMFOREST")
			elseif isMapName("Mithalas02") then
				warpNaijaToSceneNode("Mithalas01", "TUBEFLOWER_FROMMITHALAS02")
			elseif isMapName("Mithalas01") then
				warpNaijaToSceneNode("Mithalas02", "TUBEFLOWER_FROMMITHALAS01")
			else
				-- find the other one
				debugLog(entity_getName(me))
				e = getFirstEntity()
				while e~=0 do
					if e ~= me and entity_isName(e, "TubeFlower") then
						n = getNaija()
						
						--debugLog("WArping!")
						entity_idle(n)
						--dx,dy = entity_getVectorToEntity(me, e)
						cam_toEntity(e)
						watch(1)
						entity_idle(n)
						entity_alpha(n, 0)
						entity_setState(e, STATE_OPEN)

						--esetv(n, EV_NOINPUTNOVEL, 0)
						dx,dy = entity_getNormal(e)
						dx,dy = vector_setLength(dx, dy, 32)
						entity_setPosition(n, entity_x(e)+dx, entity_y(e)+dy)
						watch(0.5)
												
						einc = getFirstEntity()
						while einc ~= 0 do
							if eisv(einc, EV_TYPEID, EVT_PET) then
								--debugLog(string.format("petname: %s", entity_getName(einc)))
								entity_setPosition(einc, entity_x(n), entity_y(n))
							end
							einc = getNextEntity()
						end

						entity_alpha(n, 1, 0.2)
						dx,dy = vector_setLength(dx, dy, 400)
						entity_addVel(n, dx, dy)		
						entity_flipToVel(n)
						cam_toEntity(n)
						entity_idle(n)
						
						--wait(0.5)
						
						if hasLi() then
							li = getLi()
							
							dx,dy = entity_getNormal(e)
							dx,dy = vector_setLength(dx, dy, 32)
							
							entity_setPosition(li, entity_x(e)+dx, entity_y(e)+dy)
							
							if not isForm(FORM_DUAL) then
								entity_alpha(li, 0)
								entity_alpha(li, 1, 0.2)
							end
							
							dx,dy = vector_setLength(dx, dy, 400)
							entity_addVel(li, dx, dy)
							
							--wait(0.5)
						end
						
					
						
						--watch(0.2)
						
						--esetv(n, EV_NOINPUTNOVEL, 1)
						--entity_idle(n)
						entity_setState(e, STATE_CLOSE)
						
						break
					end
					e = getNextEntity()
				end
				entity_setState(me, STATE_CLOSE)
				done = false
			end

		end
	else
		if not (entity_isState(me, STATE_OPEN) or entity_isState(me, STATE_OPENED)) then
			entity_touchAvatarDamage(me, 64, 0, 400)
		end
	end
end

function enterState(me, state)
	commonEnterState(me, state)
	if entity_isState(me, STATE_OPENED) then		
		active = true
	elseif entity_isState(me, STATE_CLOSE) then
		active = false
	elseif entity_isState(me, STATE_OPEN) then
		entity_sound(me, "TubeFlower")
		--entity_sound(me, "TubeFlower")		
	end
end



