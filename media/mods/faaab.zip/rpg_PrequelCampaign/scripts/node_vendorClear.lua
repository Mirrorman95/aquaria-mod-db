dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, true)
	next = createEntity("panel_next", "", node_x(me), node_y(me))
	entity_alpha(next, 1, 1.5)
end

function activate(me)
	centerText("Clear Vendor")

	setFlag(CRYSTAL_1, 0)
	setFlag(CRYSTAL_2, 0)
	setFlag(CRYSTAL_3, 0)
	setFlag(CRYSTAL_4, 0)
	setFlag(CRYSTAL_5, 0)
	setFlag(CRYSTAL_6, 0)
end