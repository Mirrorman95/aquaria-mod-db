--dofile("scripts/entities/entityinclude.lua")
--dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
started = false

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	
	spawnParticleEffect("vortex", node_x(me), node_y(me))	
end

function update(me, dt)
end

function activate(me)
	avatar_fallOffWall()
	disableInput()
	cam_setPosition(node_x(me), node_y(me))
	entity_setInvincible(n, true)
	entity_setPosition(n, node_x(me), node_y(me))
	toggleCursor(true, 0.1)

	continue = confirm("Return to the Abyss?", "buy")
	if continue then
		warpNaijaToSceneNode("rpg_abyss01", "vortex_loadNightmare")
	else	
		entity_setInvincible(n, false)
		entity_idle(n)
		entity_clearVel(n)
		enableInput()
	end
end