dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Drask/panelDrask_"
entityOther = "drask"
entityOtherScale = 1.7
gemToCreate = "drask"

flagChatBubble = DT_NEW_DRASK
flagRepeat = DT_REPEAT_DRASK
flagVersion = DT_VERSION_DRASK
flagMain = DT_MAIN_DRASK

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"elena",		"2a",		"2b",		"2c"	},
		{"2a",				"other",		"3"								},
		{"2b",				"other",		"3"								},
		{"2c",				"other",		"3"								},
		{"3", 				"elena",		"4a",		"4b",		0		},
		{"4a",				"other",		"5"								},
		{"4b",				"other",		"4be1"							},
		{"4be1",			"other",		"5"								},
		{"5",				"elena",		"6a",		"6b",		"6c"	},
		{"6a",				"other",		"6e1"							},
		{"6b",				"other",		"6e1"							},
		{"6c",				"other",		"6e1"							},
		{"6e1",				"other",		"7"								},
		{"7",				"elena",		"8a",		"8b",		0		},
		{"8a",				"other",		"9"								},
		{"8b",				"other",		"9"								},
		{"9",				"elena",		"10",		"10",		0		},
		{"10",				"other",		"11"							},
		{"11",				"elena",		"12a",		"12b",		0		},
		{"12a",				"other",		"13"							},
		{"12b",				"other",		"12b1"							},
		{"12b1",			"elena",		"12b1a",	0,			0		},
		{"12b1a",			"other",		"13"							},
		{"13",				"other",		"14"							},
		{"14",				"elena",		"exit",		"exit",		0		},
		{"R", 				"other", 		"exit"							},
	}

arrayVersion2 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		0		},
		{"3a", 				"other",		"4"								},
		{"3b", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5b",		0		},
		{"5a", 				"other",		"5a1"							},
		{"5a1",				"elena",		"6",		"6",		"6"		},
		{"5b", 				"other",		"5b1"							},
		{"5b1",				"elena",		"6",		"6",		0		},
		{"6", 				"other",		"6e1"							},
		{"6e1", 			"other",		"7"								},
		{"7", 				"elena",		"8a",		"exit",		"8c"	},
		{"8a", 				"other",		"8ae1"							},
		{"8ae1", 			"other",		"8ae2"							},
		{"8ae2",			"other",		"8ae3"							},
		{"8ae3",			"other",		"8a1"							},
		{"8a1", 			"elena",		"8a1a",		"8a1b",		0		},
		{"8a1a",			"other",		"7"								},
		{"8a1b",			"other",		"7"								},
		{"8c", 				"other",		"7"								},
	}
	
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		if numPanel == "14" then
			AlphaChatBubble()
			setFlag(flagRepeat, 1)
		end
	elseif isFlag(flagVersion, 2) then	
		if numPanel == "7" then
			AlphaChatBubble()

			--QUEST START
			if isFlag(QUEST_DRASK2, 0) then
				setFlag(QUEST_DRASK2, 1)
				setControlHint("Head for Old Fred's home, north of Mithalas, once you have caught up with your conversations.", 0, 0, 0, 8, "priestnormal/head")
			end

			--NEW STARTING POINT
			setFlag(flagMain, 2)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 14
		if numPanel == "14" then
			--QUEST
			if isFlag(QUEST_DRASK1, 0) then
				setFlag(QUEST_DRASK1, 1)
				node_setCursorActivation(getNode("DT_BRAINGUARD"), false)
				setControlHint("You may now leave Mithalas but there are many other Mithalans you should talk to.", 0, 0, 0, 8, "naija/teen-head")
			end
		end
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 7
		if numPanel == "7" then
			node_activate(getNode("sit_drask"), 0)
		end
		
		--CUTSCENE
		if isFlag(QUEST_DRASK2, 1) then
			setFlag(QUEST_DRASK2, 2)
			watch(1)
			loadMap("rpg_Mithalas01")
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	
	--VERSION 1-2
	if getFlag(flagVersion) < 3 then
		CreateChatBubble(x + 50, y - 80, 0)
		CreateMapEntity(entityOther, x, y, 0)
	end
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	--IF MAIN ON THIS VERSION
	if getFlag(flagVersion) == getFlag(flagMain) then
		--VERSION 2
		if isFlag(flagMain, 2) then
			numPanel = "7"
		end
	end
	
	CommonActivate(me)
end