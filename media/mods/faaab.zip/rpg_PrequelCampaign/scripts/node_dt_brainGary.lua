dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Gary/panelGary_"
entityOther = "rpg_gary_dt"
entityOtherScale = 1.2
gemToCreate = 0

flagChatBubble = DT_NEW_GARY
flagRepeat = DT_REPEAT_GARY
flagVersion = DT_VERSION_GARY
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"elena",		"3a",		"3b",		0		},
		{"3a",				"other",		"4"								},
		{"3b",				"other",		"4"								},
		{"4",				"other",		"exit"							},
		{"R",				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 1
		if numPanel == "1" then
			entity_setPosition(entityOther, x + 640, y + 10)
		
		--PANEL 4
		elseif numPanel == "4" then
			AlphaChatBubble()
			setFlag(flagRepeat, 1)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	--CreateMapEntity(entityOther, x, y - 30, 0)
	CreateChatBubble(x + 70, y - 80, 0)
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end