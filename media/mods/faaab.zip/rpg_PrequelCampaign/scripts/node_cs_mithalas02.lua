--dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
camDummy = 0
start = 0
finish = 0

function init(me)
	n = getNaija()
	entity_setPosition(n, 0, 0)

	camDummy = createEntity("Empty")
	start = getNode("start")
	finish = getNode("finish")

	overrideZoom(0.4)
	entity_warpToNode(camDummy, start)
	cam_toEntity(camDummy)

	entity_setPosition(camDummy, node_x(finish), node_y(finish), 10)

	watch(1)
	fade(0, 4)
	watch(3)

	setControlHint("It is now time for you to play your part, Naija.", 0, 0, 0, 5)
	watch(6)

	overrideZoom(0.6, 10)

	watch(5)

	credits1 = createEntity("credits1", "", node_x(me), node_y(me) + 700)
	entity_alpha(credits1, 0)
	entity_alpha(credits1, 1, 2)

	watch(10)

	entity_delete(credits1, 2)
	credits2 = createEntity("credits2", "", node_x(me), node_y(me) + 700)
	entity_alpha(credits2, 0)
	entity_alpha(credits2, 1, 2)

	watch(6)

	fade(1, 4)
	watch(3.5)

	goToTitle()
	--loadMap("rpg_cathedralhome")
end