dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

num = 0

function init(me)
	--node_setCursorActivation(me, false)	
end

--[[
function update(me, dt)
	if isFlag(VENDOR_ACTIVE, 1) then
		node_setCursorActivation(me, true)
	else
		node_setCursorActivation(me, false)
	end
end
]]--

function activate(me)
	purchase = confirm("Are you sure you want to view\n Vision 1?", "buy")
	if purchase == true then
		node_setCursorActivation(me, false)
			
		setFlag(VENDOR_EXIT, 1)
		setFlag(VIEW_VISION_1, 1)

		--loadMap("rpg_vision1", "visionstart", "l")
		--setControlHint("Map does not exist yet.", 0, 0, 0, 8)
	end
end