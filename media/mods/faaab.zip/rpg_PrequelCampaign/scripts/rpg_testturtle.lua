dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	
	entity_initSkeletal(me, "TransTurtle")
	
	seat = entity_getBoneByName(me, "Seat")
	seat2 = entity_getBoneByName(me, "Seat2")
	tame = entity_getBoneByName(me, "Tame")
	
	bone_alpha(seat, 0)
	bone_alpha(seat2, 0)
	bone_alpha(tame, 0)
	
	light1 = entity_getBoneByName(me, "Light1")
	light2 = entity_getBoneByName(me, "Light2")
	
	bone_setBlendType(light1, 1)
	bone_setBlendType(light2, 1)
	
	entity_setState(me, STATE_IDLE)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end
