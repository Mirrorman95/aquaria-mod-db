dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/rpg_breakablecommon.lua"))

function init(me)
	loadSound("mithalasurn-break")
	commonInit(me, "Breakable/urn", 40, 3, 5, "mithalasurn-break", false, 1, 0.6)
end