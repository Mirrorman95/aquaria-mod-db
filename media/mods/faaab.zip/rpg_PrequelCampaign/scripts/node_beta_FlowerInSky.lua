dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5
function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("The above container would house whatever item Old Fred sent you to get. I have yet to code this but by clicking this node you are set.", 0, 0, 0, 12)
	elseif thingSaying == 1 then
		setFlag(MITHALAS_VISION, 1)
		setFlag(DT_VERSION_OLDFRED, 2)
		setControlHint("Return to Old Fred!", 0, 0, 0, 10)
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end