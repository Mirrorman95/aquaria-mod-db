dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_vortex.lua"))

strDestination = "vortex_veil03_3b"

function init(me)
	commonInit(me, strDestination)
end

function update(me, dt)
end

function activate(me)
	commonActivate(me)
end