--dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
camDummy = 0
start = 0
finish = 0


function init(me)
	n = getNaija()
	entity_setPosition(n, 250, 250)

	camDummy = createEntity("Empty")
	start = getNode("start")
	finish = getNode("finish")

	overrideZoom(0.4)
	entity_warpToNode(camDummy, start)
	cam_toEntity(camDummy)

	entity_setPosition(camDummy, node_x(finish), node_y(finish), 20)

	watch(1)
	fade(0, 4)
	watch(4)

	setControlHint("For his failure, Mithala will forever hunger, feasting on the flesh of his children.", 0, 0, 0, 8)
	watch(8)

	fade(1, 4)
	watch(3.5)

	loadMap("vanilla_sunkencity02")
end