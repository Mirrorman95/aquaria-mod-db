dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleJellyPlant", FLAG_COLLECTIBLE_JELLYPLANT)
end

function update(me, dt)
end
