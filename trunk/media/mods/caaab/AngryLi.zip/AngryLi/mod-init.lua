dofile("scripts/entities/entityinclude.lua")

function init()

	loadMap("lisub1")
end
