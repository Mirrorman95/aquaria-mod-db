dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Kaleb/panelKaleb_"
entityOther = "rpg_kaleb"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = DT_NEW_KALEB
flagRepeat = 0
flagVersion = DT_VERSION_KALEB
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"elena",		"3",		"3",		0		},
		{"3",				"other",		"4"								},
		{"4",				"elena",		"5a",		"5b",		0		},
		{"5a",				"other",		"6"								},
		{"5b",				"other",		"5be1"							},
		{"5be1",			"other",		"6"								},
		{"6",				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 6
		if numPanel == "6" then
			AlphaChatBubble()
			nodeClickableOnExit = false
			
			--ERIC IS COMING!
			if isFlag(VISION_2, 0) then
				setFlag(VISION_2, 1)
			end
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		if numPanel == "6" then
			--START DEFEND
			if isFlag(VISION_2, 2) then
				setFlag(VISION_2, 3)
			end
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	CreateMapEntity(entityOther, x, y, 0)
	CreateChatBubble(x - 40, y - 80, 1)
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end