dofile("scripts/entities/EntityInclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	if isFlag(NEW_GAME, 0) then
		setFlag(NEW_GAME, 1)

		--HOME TURTLE
		setFlag(TRANSTURTLE_HOME, 1)
	
		--ELENA GRAPHIC
		setCostume("elena")
		
		--CONVERSATIONS: set to version 1
		setFlag(DT_VERSION_ARCHIVIST, 1)
		setFlag(DT_VERSION_DRASK, 1)
		setFlag(DT_VERSION_GUARD, 1)
		setFlag(DT_VERSION_MIA, 1)
		setFlag(DT_VERSION_RAJAH, 1)
		setFlag(DT_VERSION_OLDFRED, 1)
		setFlag(DT_VERSION_WALKER, 1)
		setFlag(DT_VERSION_OLDFRED, 1)
		setFlag(DT_VERSION_YOUNGFRED, 1)
		setFlag(DT_VERSION_NAIJA, 1)
		
		--CUTSCENE: elena waking up
		n = getNaija()
		start = getNode("start")

		entity_warpToNode(n, start)
		entity_animate(n, "sleep", LOOP_INF)

		overrideZoom(0.5)
		watch(3)
		fade(0,4)
		overrideZoom(0.8, 14)
		watch(3)

		setControlHint("In these trying times the prince of Mithalas looked to his wife Elena for help in stabilizing his kingdom...", 0, 0, 0, 8)
		watch(8)

		entity_idle(n)
		entity_addVel(n, 0, -200)
		overrideZoom(1, 1)
		esetv(n, EV_NOINPUTNOVEL, 0)
		watch(1)
		esetv(n, EV_NOINPUTNOVEL, 1)
		overrideZoom(0)
	end
end