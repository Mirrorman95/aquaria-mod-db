dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "numbers/vendorNum_4")
	entity_setEntityLayer(me, 1)
	
	entity_scale(me, 1.4, 1.4)
	entity_alpha(me, 0)
end

function update(me, dt)
end