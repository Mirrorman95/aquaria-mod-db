dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Krotite/panelKrotite_"
entityOther = "KrotiteWorshipper"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = DT_NEW_KROTITE
flagRepeat = 0
flagVersion = DT_VERSION_KROTITE
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"elena",		"3a",		"3b",		0		},
		{"3a",				"other",		"4"								},
		{"3b",				"other",		"4"								},
		{"4",				"elena",		"5a",		"5b",		0		},
		{"5a",				"other",		"6"								},
		{"5b",				"other",		"6"								},
		{"6",				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		entity_setPosition(other, x + 670, y - 120)
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		entity_delete(chatBubble, 1)
		nodeClickableOnExit = false
		
		--ENERGY GOD ENCOUNTER
		setFlag(KROTITE_ENCOUNTER, 2)
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)	
	if getFlag(KROTITE_ENCOUNTER) < 2 then
		CommonInit(me)
		CreateMapEntity(entityOther, x, y - 60, 0)
		CreateChatBubble(x + 40, y - 60, 0)
	end
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end