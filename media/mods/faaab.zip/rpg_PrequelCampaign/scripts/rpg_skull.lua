dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "collectibles/skull")	
	
	entity_scale(me, 0.75, 0.75)
	entity_setEntityLayer(me, 0)
end

function update(me, dt)
end