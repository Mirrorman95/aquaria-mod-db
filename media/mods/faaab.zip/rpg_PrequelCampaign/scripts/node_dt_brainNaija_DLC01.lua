dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Naija/panelNaija_DLC01_"
entityOther = "rpg_naija_l"
entityOtherScale = 1.7
gemToCreate = 0

flagChatBubble = DT_NEW_NAIJA_DLC01
flagRepeat = DT_REPEAT_NAIJA_DLC01
flagVersion = DT_VERSION_NAIJA_DLC01
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"2"								},
		{"2", 				"elena",	"3a", 		"3b", 		"3c"	},
		{"3a", 				"other",	"3a1",		0,			0		},
		{"3a1", 			"elena",	"3a1a", 	"3a1b",		0		},
		{"3a1a", 			"other",	"3c"							},
		{"3a1b", 			"other",	"3c"							},
		{"3b", 				"other",	"3b1"							},
		{"3b1",				"elena",	"3c", 		"3c",		0		},
		{"3c",				"other",	"4", 							},
		{"4", 				"elena",	"4a", 		"4b",		0		},
		{"4a", 				"other",	"exit"							},
		{"4b", 				"other",	"exit"							},
		{"R", 				"other",	"exit"							}
	}

--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	if numPanel == "4" then
		setFlag(flagChatBubble, 1)
		entity_alpha(chatBubble, 0.25, 1)
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--REPEAT
	if numPanel == 0 and flagRepeat ~= 0 then
		if isFlag(flagRepeat, 0) then
			setFlag(flagRepeat, 1)
		end
	end	
	
	numPanel = "1"
	currentRowID = 1
end

--INIT
function init(me)
	CommonInit(me)
	
	if isFlag(FEDOR_FIRST_RIDE, 0) then
		CreateChatBubble(x + 45, y - 80, 0)
	else
		node_setCursorActivation(me, false)
	end
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end