dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 8


function init(me)
	n = getNaija()
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("Drask knew less about my doings than I gave him credit for. His wisdom and courage were somewhat diminished in his final years but he remained selfless until his last breath.", 0, 0, 0, -1)
	elseif thingSaying == 1 then
		setControlHint("I gave Elena and Drask a chance to restore order, but in time I realized I would have to step in. It was too difficult a task for any mortal to solve.", 0, 0, 0, -1)
	elseif thingSaying == 2 then
		setControlHint("Elena began to head towards the darkness of the Abyss past Open Waters where a final confrontation awaited her.", 0, 0, 0, -1)
	elseif thingSaying == 3 then
		clearControlHint()
	end
end

function update(me, dt)
	--START NARRATION
	if isFlag(DEATH_OF_DRASK, 3) and isFlag(NARRATION_CATHEDRALPRIEST, 0) and node_isEntityIn(me, n) then
		setFlag(NARRATION_CATHEDRALPRIEST, 1)
		
		clearControlHint()
		started = true
		thingSaying = -1
		timer = 999
		setStringFlag("editorhint", node_getName(me))
	end


	--CHANGES TEXT TO BE USED
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end