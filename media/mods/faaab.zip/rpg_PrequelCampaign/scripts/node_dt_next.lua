dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, false)	
end


function update(me, dt)
	if isFlag(DT_NEXT, 1) then
		node_setCursorActivation(me, true)
	else
		node_setCursorActivation(me, false)
	end
end


function activate(me)
	node_setCursorActivation(me, false)
	playSfx("click")

	setFlag(DT_NEXT, 0)
	setFlag(CLICKED_NEXT, 1)
end