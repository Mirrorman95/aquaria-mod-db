dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Events/FinalConfrontation/panelFinalConfrontation_"
entityOther = "rpg_mia"
entityOtherScale = 1.7
gemToCreate = 0

flagChatBubble = DT_NEW_DEATHWISH
flagRepeat = 0
flagVersion = DT_VERSION_DEATHWISH
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"other",		"3"								},
		{"3",				"other",		"4"								},
		{"4",				"other",		"5"								},
		{"5",				"other",		"6"								},
		{"6",				"other",		"7"								},
		{"7",				"other",		"8"								},
		{"8",				"elena",		"9a",		"9b",		0		},
		{"9a",				"other",		""								},
		{"9b",				"other",		""								},
		{"10a",				"other",		"11a"							},
		{"10b",				"other",		"11b"							},
		{"11a",				"other",		"exit"							},
		{"11b",				"other",		"exit"							},
		{"12a",				"other",		"13"							},
		{"12b",				"other",		"13"							},
		{"13",				"other",		"exit"							},
		{"14",				"elena",		"15",		"15",		0		},
		{"15",				"other",		"15e1"							},
		{"15e1",			"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 1
		if numPanel == "1" then
			--SWITCH CHARS(ELENA > ERIC)
			ChangeLeftEntity("rpg_eric", 1.7, x - 675, y - 20)
			entity_fh(elena)
			entity_color(other, 1, 1, 1, 1)
			entity_color(elena, 0.2, 0.2, 0.2, 1)
		
		--PANEL 2
		elseif numPanel == "2" then
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 3
		elseif numPanel == "3" then
			entity_color(other, 1, 1, 1, 1)
			entity_color(elena, 0.2, 0.2, 0.2, 1)
			
		--PANEL 4
		elseif numPanel == "4" then
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 5
		elseif numPanel == "5" then
			entity_color(other, 1, 1, 1, 1)
			entity_color(elena, 0.2, 0.2, 0.2, 1)
			
		--PANEL 6
		elseif numPanel == "6" then
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 7
		elseif numPanel == "7" then
			entity_color(other, 1, 1, 1, 1)
			entity_color(elena, 0.2, 0.2, 0.2, 1)
			
			--SWITCH CHARS(MIA > VEDHA)
			ChangeRightEntity("eric_13", 1.7, x + 670, y)
			
			--CHANGE MIA [IN MAP] TO 13
			entity_delete(mapEntity)
			mapEntity = createEntity("eric_13", "", x, y)
			entity_fh(mapEntity)
			
		--PANEL 8
		elseif numPanel == "8" then
			--SWITCH CHARS(ERIC > ELENA)
			ChangeLeftEntity("rpg_elena", 1.6, x - 675, y - 50)
		
		--PANEL 9B
		elseif numPanel == "9b" then
			--ELENA SUPPORTS VEDHA
			setFlag(SUPPORT_VEDHA, 1)
				
		--PANEL 10A or 10B
		elseif numPanel == "10a" or numPanel == "10b" then
			--SWITCH CHARS(ELENA > MITHALA)
			ChangeLeftEntity("rpg_mithalangod", 0.7, x - 675, y + 10)
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 11A or 11B
		elseif numPanel == "11a" or numPanel == "11b" then
			--PORT OUT: mithala
			setFlag(FINAL_CONFRONTATION, 1)
			
		--PANEL 12A or 12B
		elseif numPanel == "12a" or numPanel == "12b" then	
			--SWITCH CHARS(ELENA > ERIC)
			ChangeLeftEntity("rpg_eric", 1.7, x - 675, y - 20)
			entity_fh(elena)
			
			entity_color(other, 1, 1, 1, 1)
			entity_color(elena, 0.2, 0.2, 0.2, 1)
			
			entity_setPosition(other,  x + 670, y - 10)
			
		--PANEL 13
		elseif numPanel == "13" then		
			--PORT OUT: Eric and TheCreator
			setFlag(FINAL_CONFRONTATION, 3)
			
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 14
		elseif numPanel == "14" then
			entity_setPosition(other,  x + 670, y - 10)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 15E1
		if numPanel == "15e1" then
			--START NIGHTMARE
			entity_setPosition(n, x + 75, y)

			watch(1)

			--PORT OUT ELENA
			entity_setInvincible(n, true)
			entity_idle(n)
			entity_clearVel(n)
			
			spawnParticleEffect("MiaWarp", x + 75, y)
			playSfx("mia-appear")
			entity_alpha(n, 0, 2)

			watch(3)

			warpNaijaToSceneNode("rpg_Nightmare01", "right", "l")
		end
		
		numPanel = "1"
		currentRowID = 1
	
		--PORTAL MITHALA
		if isFlag(FINAL_CONFRONTATION, 1) then
			node_activate(getNode("CS_GOTTAGO"))
			
		--PORTAL ERIC AND CREATOR
		elseif isFlag(FINAL_CONFRONTATION, 3) then
			node_activate(getNode("CS_GOTTAGO"))
		end
	end
end


--INIT
function init(me)
	--DYNAMICALLY CHANGE ARRAY
	--SUPPORT = 1 | OPPOSE = 2
	if isFlag(MITHALA_STANCE, 1) then
		arrayVersion1[9][3] = "10a"
		arrayVersion1[9][3] = "10a"
	else
		arrayVersion1[9][3] = "10b"
		arrayVersion1[10][3] = "10b"
	end
				
	CommonInit(me)
	CreateChatBubble(x - 40, y - 80, 1)
	
	if getFlag(FINAL_CONFRONTATION) > 0 then
		CreateMapEntity("eric_13", x, y - 10, 1)
	else
		CreateMapEntity("rpg_mia", x, y - 10, 1)
	end
	
	loadSound("mia-appear")
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	--CUTSCENE PROGRESS
	if isFlag(FINAL_CONFRONTATION, 2) then
		entityOther = "eric_13"
	
		if isFlag(SUPPORT_VEDHA, 1) then
			numPanel = "12b"
		else
			numPanel = "12a"
		end
	elseif isFlag(FINAL_CONFRONTATION, 4) then
		entityOther = "eric_13"
		numPanel = "14"
	else
		entityOther = "rpg_mia"
	end
	
	CommonActivate(me)
end