dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

n = 0
door = 0
setup = false
delay = 8
delayloadmap = 11

function init(me)
	loadSound("hellbeast-suck") 
	n = getNaija()

	spawn1 = getNode("SPAWN1")
	spawn2 = getNode("SPAWN2")
	spawn3 = getNode("SPAWN3")
	spawn4 = getNode("SPAWN4")
	doorToClose = getNode("CLOSE_THIS")

	door = node_getNearestEntity(doorToClose, "EnergyDoor")
	if isFlag(MITHALAS_VISION, 3) then
		entity_setState(door, STATE_CLOSED)
	else
		entity_setState(door, STATE_OPENED)
	end

	--node_setCursorActivation(me, true)
end


function update(me, dt)
	if isFlag(CS_PIPESUCK, 1) then
		if (setup == false) then
			setup = true

			node_setCursorActivation(getNode("DT_BRAINYOUNGFRED"), false)
			node_setCursorActivation(getNode("DT_BRAINOLDFRED"), false)

			createEntity("abyssoctopus", "", node_x(spawn1), node_y(spawn1))
			createEntity("abyssoctopus", "", node_x(spawn1), node_y(spawn1))
			createEntity("abyssoctopus", "", node_x(spawn2), node_y(spawn2))
			createEntity("abyssoctopus", "", node_x(spawn2), node_y(spawn2))
			createEntity("abyssoctopus", "", node_x(spawn3), node_y(spawn3))
			createEntity("abyssoctopus", "", node_x(spawn3), node_y(spawn3))
			createEntity("abyssoctopus", "", node_x(spawn4), node_y(spawn4))
			createEntity("abyssoctopus", "", node_x(spawn4), node_y(spawn4))	
	
			shakeCamera(10, 5)
			playSfx("naijagasp")
		end
	

		--SUCK ELENA TO PIPE
		if delay > 0 then
			delay = delay - dt
		else
			disableInput()
			entity_moveToNode(n, me, SPEED_NORMAL)
			--entity_pullEntities(me, node_x(me), node_y(me), 2000, 100, 10)
			spawnParticleEffect("sunwormsuck", node_x(me) - 30, node_y(me) - 30)
			playSfx("hellbeast-suck")
			delay = 8
		end

		--LOAD MAP
		if delayloadmap > 0 then
			delayloadmap = delayloadmap - dt
		else
			--MITHALAS CORRUPTED
			setFlag(MITHALAS_CORRUPTED, 1)
			setFlag(MITHALAS_VISION, 4)
			
			--[[UPDATE WORLD MAP
			for i,list in ipairs(mapArr) do
				setFlag(mapArr[6][7], 0)
			end]]--

			--UPDATE DT VERSIONS
			setFlag(DT_VERSION_OLDFRED, 4)
			setFlag(DT_VERSION_WALKER, 3)
			setFlag(DT_VERSION_DRASK, 3)
			setFlag(DT_VERSION_MIA, 3)
			setFlag(DT_VERSION_RAJAH, 3)
			setFlag(DT_VERSION_NAIJA, 3)
			
			--WIPE DT REPEAT
			setFlag(DT_REPEAT_DRASK, 0)
			setFlag(DT_REPEAT_RAJAH, 0)

			--UPDATE NEW THINGS TO SAY
			setFlag(DT_NEW_OLDFRED, 0)
			setFlag(DT_NEW_WALKER, 0)
			setFlag(DT_NEW_DRASK, 0)
			setFlag(DT_NEW_MIA, 0)
			setFlag(DT_NEW_RAJAH, 0)
			setFlag(DT_NEW_NAIJA, 0)

			--PIPE TRAVEL
			setFlag(CS_PIPESUCK, 0)
			setFlag(CS_PIPETRAVEL, 1)
			loadMap("rpg_Veil02", "start")
		end
	end
end


--[[DEBUG TOOL
function activate(me)
	entity_setState(door, STATE_CLOSE)
	centerText("Door should be closing")
end
]]--