--LARGE CRYSTAL

dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
num = 0
num2 = 0
doOnce = false

function init(me)
	n = getNaija()

	setupEntity(me, "lightcrystal/crystal", -1)
	entity_setEntityType(me, ET_NEUTRAL)
	
	entity_scale(me, 0.75, 0.75)
	entity_setEntityLayer(me, 0)

	entity_setWeight(me, 150)
	entity_setBounce(me, 0.3)

	entity_setState(me, STATE_IDLE)

	playSfx("secret", 0, 0.5)
end


function postInit(me)
end


function update(me, dt)
	if entity_isState(me, STATE_IDLE) then
		if entity_isEntityInRange(me, getNaija(), 64) then
			entity_setState(me, STATE_COLLECT, 6)
		else
			entity_updateMovement(me, dt)
			entity_updateCurrents(me)
		end
	end
end

incut = false

function enterState(me, state)
	if incut then return end
	
	if entity_isState(me, STATE_COLLECT) then
		incut = true

	--uPDATE TOTAL
		num = getFlag(TOTAL_CRYSTALS)
		num = num + 1
		setFlag(TOTAL_CRYSTALS, num)
			
	--UPDATE CURRENCY
		num2 = getFlag(CURRENCY)
		num2 = num2 + 1
		setFlag(CURRENCY, num2)

		entity_idle(getNaija())
		entity_flipToEntity(getNaija(), me)
		cam_toEntity(me)
		
		overrideZoom(1.2, 7)
		musicVolume(0.1, 3)
		
		setSceneColor(1, 0.9, 0.5, 3)
		
		spawnParticleEffect("treasure-glow", entity_x(me), entity_y(me))
		
		playSfx("low-note1", 0, 0.4)
		playSfx("low-note5", 0, 0.4)
		watch(3)
		
		--entity_setFlag(me, 1)
		entity_setPosition(me, entity_x(me), entity_y(me) - 100, 3, 0, 0, 1)
		entity_scale(me, 1.2, 1.2, 3)
		playSfx("Collectible")
		
		watch(3)
		
		playSfx("secret", 0, 0.5)
		cam_toEntity(getNaija())
		
		if isFlag(FIRST_LARGE_CRYSTAL, 0) then
			setFlag(FIRST_LARGE_CRYSTAL, 1)
			setControlHint("Large Crystal Collected! Visit the vendor crystal in the Royal Library of the Mithalas Cathedral to exchange this.", 0, 0, 0, 8)
	--SHOW PLAYER WHAT THEY GOTZ
		else
		setControlHint("Large Crystals | Currency = " .. getFlag(CURRENCY) .. " | Total Collected = " .. getFlag(TOTAL_CRYSTALS), 0, 0, 0, 5, "lightcrystal/crystal", 0, 0.5)
		end

		musicVolume(1, 2)
		setSceneColor(1, 1, 1, 1)
		overrideZoom(0)

		incut = false
	elseif entity_isState(me, STATE_COLLECTED) then
		entity_alpha(me, 0)
	end
end

function exitState(me, state)
	if entity_isState(me, STATE_COLLECT) then
		entity_alpha(me, 0, 1)
		spawnParticleEffect("Collect", entity_x(me), entity_y(me))
		--clearControlHint()
		entity_setState(me, STATE_COLLECTED)
	end
end

function hitSurface(me)
end