dofile("scripts/entities/entityinclude.lua")

function init(me)
	node_setCursorActivation(me, false)
end

function activate(me)	
	energyOrb = node_getNearestEntity(me, "EnergyOrb")
	if energyOrb ~= 0 and entity_isState(energyOrb, STATE_CHARGED) then		
		door = node_getNearestEntity(me, "EnergyDoor")
		if door ~= 0 then
			entity_setState(door, STATE_OPEN)
		end
	end
end

function update(me, dt)
end
