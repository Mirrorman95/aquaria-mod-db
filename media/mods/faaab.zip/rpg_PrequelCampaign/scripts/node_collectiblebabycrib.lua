dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleBabyCrib", FLAG_COLLECTIBLE_BABYCRIB)
end

function update(me, dt)
end
