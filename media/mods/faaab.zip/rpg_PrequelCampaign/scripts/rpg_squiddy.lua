dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "squiddy")	
	
	entity_scale(me, 1.0, 1.0)
	entity_alpha(me, 1)
	entity_setEntityLayer(me, 0)

	entity_setSegs(me, 2, 32, 0.2, 0.2, 0.02, 0, 6, 1)
	entity_setState(me, STATE_IDLE)
end


function update(me, dt)
	entity_updateMovement(me, dt)

	--s = createShot("EnemyInk", me, n, entity_x(me), entity_y(me))
	--entity_setDeathParticleEffect(me, "InkExplode")
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end