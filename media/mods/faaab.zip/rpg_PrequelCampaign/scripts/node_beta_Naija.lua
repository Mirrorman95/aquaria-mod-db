dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
	
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("I'm embarassed to say that I have yet to spend time devloping Naija's dialogue.", 0, 0, 0, 10)
	elseif thingSaying == 1 then
		setControlHint("Her attitude is that of a loner having grown a hatred towards most Mithalans/Creatures.", 0, 0, 0, 10)
	elseif thingSaying == 2 then
		setControlHint("However, she talks at great lengths about her seahorse and seeks friendship with Elena.", 0, 0, 0, 10)
	elseif thingSaying == 3 then
		setControlHint("Treasures you find on your journey will be placed here to raise Naija's spirits. ", 0, 0, 0, 10)
	elseif thingSaying == 4 then
		setControlHint("I had originally planned to give player's the choice to allow Naija to use your home.", 0, 0, 0, 10)
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end