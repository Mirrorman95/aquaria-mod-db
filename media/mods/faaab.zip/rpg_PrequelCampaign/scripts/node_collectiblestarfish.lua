dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleStarfish", FLAG_COLLECTIBLE_STARFISH)
end

function update(me, dt)
end
