--SeaHorse

--dofile("scripts/entities/seahorsecommon.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/seahorsecommon.lua"))

function init(me)
	commonInit(me, "Seahorse/Seahorse-0004", 0)
end

function msg(me, msg)
	if msg == "DialogueTree" and riding == true then
		stopRide(me)
	end
end