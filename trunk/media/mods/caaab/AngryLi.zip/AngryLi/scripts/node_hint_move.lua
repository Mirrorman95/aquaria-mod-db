dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/angryli/scripts/include.lua"))
n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)

	if node_isFlag(me, 0) and node_isEntityIn(me, n) then
		node_setFlag(me, 1)
		setControlHint("Move the mouse to move Li's submarine", 0, 0, 0, 3)
	end
end