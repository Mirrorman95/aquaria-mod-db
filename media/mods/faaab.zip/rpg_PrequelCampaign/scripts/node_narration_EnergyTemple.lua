dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 8


function init(me)
	n = getNaija()
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("Elena had always recalled being a peaceful creature and was confused by her desire for and apparent skill in combat. She had felt no remorse in killing the last survivor of an entire race.", 0, 0, 0, -1)
	elseif thingSaying == 1 then
		setControlHint("Though the Krotite had died, the Energy God had not yet met his end. The lives of many more creatures would soon weigh upon Elena's hands; much as they will upon yours, Naija.", 0, 0, 0, -1)
	elseif thingSaying == 2 then
		clearControlHint()
	end
end

function update(me, dt)
	--START NARRATION
	if isFlag(NARRATION_ENERGYTEMPLE, 0) and node_isEntityIn(me, n) then
		setFlag(NARRATION_ENERGYTEMPLE, 1)
		
		clearControlHint()
		started = true
		thingSaying = -1
		timer = 999
		setStringFlag("editorhint", node_getName(me))
	end


	--CHANGES TEXT TO BE USED
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end