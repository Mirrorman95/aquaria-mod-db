dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Extras/Veil02/panelLumerean02_"
entityOther = "architect"
entityOtherScale = 0.8
gemToCreate = 0

flagChatBubble = DT_NEW_LUMEREAN02
flagRepeat = 0
flagVersion = DT_VERSION_LUMEREAN02
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 1
		if numPanel == "1" then
			AlphaChatBubble()
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)	
	CommonInit(me)
	CreateMapEntity(entityOther, x, y, 0)
	CreateChatBubble(x + 50, y - 100, 0)
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end