dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleTeenCostume", FLAG_COLLECTIBLE_TEENCOSTUME)
end

function update(me, dt)
end
