dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleCrabCostume", FLAG_COLLECTIBLE_CRABCOSTUME)
end

function update(me, dt)
end
