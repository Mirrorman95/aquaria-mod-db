dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/angryli/scripts/include.lua"))

n = 0
inNode = false

function init(me)
	n = getNaija()
end

nextMessage = 3

function update(me, dt)

	if not inNode and node_isEntityIn(me, n) then
		inNode = true
		entity_msg(getEntity("lisub"),"activateshock")
		if node_isFlag(me, 0) then
			setControlHint("Right clic to deal heavy damage to nearby creatures.", 0, 1, 0, 3)
		end
	end
	
	if inNode and nextMessage > 0 then
		nextMessage = nextMessage - dt
	end
	if nextMessage <= 0 and node_isFlag(me, 0) then
		setControlHint("Shock is slow to reload. The blue light tells when it's ready.", 0, 0, 0, 3)
		node_setFlag(me, 1)
	end
	
end