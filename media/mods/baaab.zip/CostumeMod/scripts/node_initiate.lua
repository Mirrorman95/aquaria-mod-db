dofile("scripts/entities/EntityInclude.lua")

n=0

function init(me)
	--setWaterLevel(3000,0)
	--setFlag(FLAG_LI,100)
end

function update(me, dt)
--	if getForm() == 3 then
--		avatar_toggleCape(true)
--	else
--		avatar_toggleCape(false)
--	end
end
