dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	if not isFlag(QUEST_WALKER1, 1) then
		node = getNode("vine_door")
		node_setElementsInLayerActive(node, 2, false)
		reconstructGrid()
	end
end