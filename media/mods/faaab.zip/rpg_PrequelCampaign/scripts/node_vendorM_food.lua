dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

n = 0
mFoodMenu = 0
tempFoodMenu = 0
canChangeMode = true

BOUGHT_ITEMS = {}
CURRENCY_GFX = {}
TOTAL_GFX = {}
--BOUGHT_GFX = {}

foodCurrencyNum = 0
foodTotalNum = 0
foodTotalNumGFX = 0
button_Tab1 = 0
buttonGFX_Tab1 = 0
button_Tab2 = 0
buttonGFX_Tab2 = 0

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	setFlag(VENDORM_FOOD_TAB, 1)
	createEntity("symbol_food", "", node_x(me), node_y(me) - 110)
	
	vendorCreature = createEntity("druniad", "", node_x(me), node_y(me) + 20)
	if isMapName("rpg_veil03") then
		entity_fh(vendorCreature)
	end
	
--[[DEBUG TOOL: +5 currency
	currency = getFlag(CURRENCY_SMALL_CRYSTALS)
	currency = currency + 5
	setFlag(CURRENCY_SMALL_CRYSTALS, currency)

	total = getFlag(TOTAL_SMALL_CRYSTALS)
	total = total + 5
	setFlag(TOTAL_SMALL_CRYSTALS, total)
]]--

	foodCurrencyNum = getNode("foodCurrencyNum")
	foodTotalNum = getNode("foodTotalNum") 
	button_Tab1 = getNode("vendorM_button_tab1")
	button_Tab2 = getNode("vendorM_button_tab2")
end


function update(me, dt)
	--GEM for WORLDMAP
	if node_isEntityIn(me, n) then
		if node_isFlag(me, 0) then
			node_foundGem(me, "vendor_food")
			node_setFlag(me, 1)
		end
	end
	
	if isFlag(VENDORM_FOOD_ACTIVE, 1) then
	--CHANGE MODE: button graphics and menu graphic change
		if isFlag(FOOD_CHANGE_MODE, 1) and (canChangeMode == true) then
			canChangeMode = false

		--tab1 to tab2
			if isFlag(VENDORM_FOOD_TAB, 1) then
				setFlag(VENDORM_FOOD_TAB, 2)
				setFlag(FOOD_CHANGE_MODE, 0)

				tempFoodMenu = mFoodMenu
				mFoodMenu = createEntity("vendorM_menu_tab1", "", node_x(me), node_y(me) - 85)
				entity_alpha(mFoodMenu, 0)
				entity_alpha(mFoodMenu, 1, 1)

				--buttons
				entity_delete(buttonGFX_Tab1)
				entity_delete(buttonGFX_Tab2)
				buttonGFX_Tab1 = createEntity("vendor_button_tab1-up", "", node_x(button_Tab1), node_y(button_Tab1))
				buttonGFX_Tab2 = createEntity("vendor_button_tab2-down", "", node_x(button_Tab2), node_y(button_Tab2))
				entity_alpha(buttonGFX_Tab1, 1)
				entity_alpha(buttonGFX_Tab2, 1)

				updateCurrencyGFX( node_x(foodCurrencyNum), node_y(foodCurrencyNum) )
				updateTotalGFX(node_x(foodTotalNum), node_y(foodTotalNum))
				--deleteBoughtGFX()

				watch(1.0)
				entity_delete(tempFoodMenu)
				node_setCursorActivation(getNode("vendorM_button_tab1"), true)
				node_setCursorActivation(getNode("vendorM_button_tab2"), false)
				canChangeMode = true
	
		--tab2 to tab1
			elseif isFlag(VENDORM_FOOD_TAB, 2) then
				setFlag(VENDORM_FOOD_TAB, 1)
				setFlag(FOOD_CHANGE_MODE, 0)

				tempFoodMenu = mFoodMenu
				mFoodMenu = createEntity("vendorM_menu_tab2", "", node_x(me), node_y(me) - 85)
				entity_alpha(mFoodMenu, 0)
				entity_alpha(mFoodMenu, 1, 1)
				
				--buttons
				entity_delete(buttonGFX_Tab1)
				entity_delete(buttonGFX_Tab2)
				buttonGFX_Tab1 = createEntity("vendor_button_tab1-down", "", node_x(button_Tab1), node_y(button_Tab1))
				buttonGFX_Tab2 = createEntity("vendor_button_tab2-up", "", node_x(button_Tab2), node_y(button_Tab2))
				entity_alpha(buttonGFX_Tab1, 1)
				entity_alpha(buttonGFX_Tab2, 1)

				updateCurrencyGFX( node_x(foodCurrencyNum), node_y(foodCurrencyNum) )
				updateTotalGFX(node_x(foodTotalNum), node_y(foodTotalNum))
				--updateBoughtGFX()

				watch(1.0)
				entity_delete(tempFoodMenu, 1)
				node_setCursorActivation(getNode("vendorM_button_tab1"), false)
				node_setCursorActivation(getNode("vendorM_button_tab2"), true)
				canChangeMode = true
			end
		end

	--ADD ITEMS: add bought items to array (flag modified by other nodes)
		addItem = getStringFlag(PURCHASE)		
		if ( addItem ~= "" ) then
			table.insert(BOUGHT_ITEMS, addItem)
			setStringFlag(PURCHASE, "")

			updateCurrencyGFX( node_x(foodCurrencyNum), node_y(foodCurrencyNum) )
			
			--[[if isFlag(VENDORM_FOOD_MODE, 0) then
				updateBoughtGFX()
			end]]--
		end

	--EXIT: 
		if isFlag(VENDORM_FOOD_EXIT, 1) then
		debugLog("FOOD VENDOR: vendorM_food start exit")

		debugLog("FOOD VENDOR: vendorWrapup() called")
			vendorWrapup()

		debugLog("FOOD VENDOR: bought items spawned from table")
		--SPAWN purchased items
			for i=1, #BOUGHT_ITEMS do
				spawnIngredient(BOUGHT_ITEMS[i], node_x(me), node_y(me))
			end
			

		debugLog("FOOD VENDOR: clear bought items table")
		--CLEAR BOUGHT_ITEMS
			for i=1, #BOUGHT_ITEMS do
				BOUGHT_ITEMS[i] = nil
			end
			--table.clear(BOUGHT_ITEMS)
			
		debugLog("FOOD VENDOR: finished exiting food vendor")
			node_setCursorActivation(me, true)
			setFlag(VENDORM_FOOD_TAB, 1)
			setFlag(VENDORM_FOOD_ACTIVE, 0)
			setFlag(VENDORM_FOOD_EXIT, 0)
		end
	end
end


function activate(me)
	if entity_getRiding(n) ~= 0 then
		setControlHint("Dismount to access the food vendor.", 0, 0, 0, 6)
	elseif isFlag(VENDORM_FOOD_ACTIVE, 0) then
		setFlag(VENDORM_FOOD_ACTIVE, 1)
		node_setCursorActivation(me, false)	
		vendorSetup( node_x(me), node_y(me) )

	--instructions on first viewing
		if isFlag(VENDORM_FOOD_FIRST, 0) then
			setControlHint("There are two tabs of purchaseable items. Obtain small crystals from crates, urns and song flowers.", 0, 0, 0, 8, "crawlvirus/head")
			setFlag(VENDORM_FOOD_FIRST, 1) 
		end
	end
end


--WRAPUP: called on exit
function vendorWrapup()

debugLog("FOOD VENDOR: item buttons being deactivated")

--NODE: tab buttons
	node_setCursorActivation(getNode("vendorM_button_tab1"), false)
	node_setCursorActivation(getNode("vendorM_button_tab2"), false)

--NODE: turn off 1-12 vendorM_# nodes
	node_setCursorActivation(getNode("vendorM_1"), false)
	node_setCursorActivation(getNode("vendorM_2"), false)
	node_setCursorActivation(getNode("vendorM_3"), false)
	node_setCursorActivation(getNode("vendorM_4"), false)
	node_setCursorActivation(getNode("vendorM_5"), false)
	node_setCursorActivation(getNode("vendorM_6"), false)
	node_setCursorActivation(getNode("vendorM_7"), false)
	node_setCursorActivation(getNode("vendorM_8"), false)
	node_setCursorActivation(getNode("vendorM_9"), false)
	node_setCursorActivation(getNode("vendorM_10"), false)
	node_setCursorActivation(getNode("vendorM_11"), false)
	node_setCursorActivation(getNode("vendorM_12"), false)

debugLog("FOOD VENDOR: deleting currency and total nums")
--GFX: delete
	deleteCurrencyGFX()
	deleteTotalGFX()
	--deleteBoughtGFX()
	
debugLog("FOOD VENDOR: deleting visuals")
	entity_delete(mFoodMenu, 1)
	--entity_delete(tempFoodMenu, 1)
	entity_delete(buttonGFX_Tab1, 1)
	entity_delete(buttonGFX_Tab2, 1)

	entity_setInvincible(n, false)
	enableInput()
	entity_alpha(n, 1.0)
	overrideZoom(0)	

	cam_toEntity(n)
end


--SETUP: called by activate
function vendorSetup(x,y)
	avatar_fallOffWall() 
	n = getNaija()
	overrideZoom(0.52)

	cam_setPosition(x, y)
	entity_setInvincible(n, true)
	entity_alpha(n, 0, 1.0)
	entity_setPosition(n, x, y)
	disableInput()
	toggleCursor(true, 0.1)

	playSfx("recipemenu-open")
	mFoodMenu = createEntity("vendorM_menu_tab2", "", x, y - 1000)
	entity_setPosition(mFoodMenu, x, y - 85, 1.5)

	watch(1.5)

	--BUTTON: tabs
	buttonGFX_Tab1 = createEntity("vendor_button_tab1-down", "", node_x(button_Tab1), node_y(button_Tab1))
	entity_alpha(buttonGFX_Tab1, 1, 1)

	buttonGFX_Tab2 = createEntity("vendor_button_tab2-up", "", node_x(button_Tab2), node_y(button_Tab2))
	entity_alpha(buttonGFX_Tab2, 1, 1)

	--GFX: place currency
	updateCurrencyGFX(node_x(foodCurrencyNum), node_y(foodCurrencyNum))

	--GFX: place total
	updateTotalGFX(node_x(foodTotalNum), node_y(foodTotalNum))

	--GFX: place bought
	--updateBoughtGFX()

	--NODE: tab buttons
	--node_setCursorActivation(getNode("vendorM_button_tab1"), true)
	node_setCursorActivation(getNode("vendorM_button_tab2"), true)

	--NODE: activate 1-12 vendorM_# nodes
	node_setCursorActivation(getNode("vendorM_1"), true)
	node_setCursorActivation(getNode("vendorM_2"), true)
	node_setCursorActivation(getNode("vendorM_3"), true)
	node_setCursorActivation(getNode("vendorM_4"), true)
	node_setCursorActivation(getNode("vendorM_5"), true)
	node_setCursorActivation(getNode("vendorM_6"), true)
	node_setCursorActivation(getNode("vendorM_7"), true)
	node_setCursorActivation(getNode("vendorM_8"), true)
	node_setCursorActivation(getNode("vendorM_9"), true)
	node_setCursorActivation(getNode("vendorM_10"), true)
	node_setCursorActivation(getNode("vendorM_11"), true)
	node_setCursorActivation(getNode("vendorM_12"), true)

end


--CURENCY: delete then place
function updateCurrencyGFX(x,y)
	deleteCurrencyGFX()

	strCurrency = getFlag(CURRENCY_SMALL_CRYSTALS)
	entityIDNum = 0
	tempVar = 0
	offset = 0

	for i = 1, string.len(strCurrency) do
		tempVar = string.sub(strCurrency, i, i)

	   	if (tempVar == "0") then
			entityIDNum = createEntity("vendorNum_0", "", x + offset, y)
		elseif (tempVar == "1") then
			entityIDNum = createEntity("vendorNum_1", "", x + offset, y)
		elseif (tempVar == "2") then
			entityIDNum = createEntity("vendorNum_2", "", x + offset, y)
		elseif (tempVar == "3") then
			entityIDNum = createEntity("vendorNum_3", "", x + offset, y)
		elseif (tempVar == "4") then
			entityIDNum = createEntity("vendorNum_4", "", x + offset, y)
		elseif (tempVar == "5") then
			entityIDNum = createEntity("vendorNum_5", "", x + offset, y)
		elseif (tempVar == "6") then
			entityIDNum = createEntity("vendorNum_6", "", x + offset, y)
		elseif (tempVar == "7") then
			entityIDNum = createEntity("vendorNum_7", "", x + offset, y)
		elseif (tempVar == "8") then
			entityIDNum = createEntity("vendorNum_8", "", x + offset, y)
		elseif (tempVar == "9") then
			entityIDNum = createEntity("vendorNum_9", "", x + offset, y)
		end

		entity_alpha(entityIDNum, 1, 1)
		table.insert(CURRENCY_GFX, entityIDNum)
		offset = offset + 25
	end
end


--CURRENCY: delete
function deleteCurrencyGFX()
	for i = 1, #CURRENCY_GFX do
		entity_delete(CURRENCY_GFX[i], 1)
		CURRENCY_GFX[i] = nil
	end
end


--TOTAL: delete then place
function updateTotalGFX(x,y)
	deleteTotalGFX()

	strTotal = getFlag(TOTAL_SMALL_CRYSTALS)
	entityIDNum = 0
	tempVar = 0
	offset = 0

	for i = 1, string.len(strTotal) do
		tempVar = string.sub(strTotal, i, i)

	   	if (tempVar == "0") then
			entityIDNum = createEntity("vendorNum_0", "", x + offset, y)
		elseif (tempVar == "1") then
			entityIDNum = createEntity("vendorNum_1", "", x + offset, y)
		elseif (tempVar == "2") then
			entityIDNum = createEntity("vendorNum_2", "", x + offset, y)
		elseif (tempVar == "3") then
			entityIDNum = createEntity("vendorNum_3", "", x + offset, y)
		elseif (tempVar == "4") then
			entityIDNum = createEntity("vendorNum_4", "", x + offset, y)
		elseif (tempVar == "5") then
			entityIDNum = createEntity("vendorNum_5", "", x + offset, y)
		elseif (tempVar == "6") then
			entityIDNum = createEntity("vendorNum_6", "", x + offset, y)
		elseif (tempVar == "7") then
			entityIDNum = createEntity("vendorNum_7", "", x + offset, y)
		elseif (tempVar == "8") then
			entityIDNum = createEntity("vendorNum_8", "", x + offset, y)
		elseif (tempVar == "9") then
			entityIDNum = createEntity("vendorNum_9", "", x + offset, y)
		end

		entity_alpha(entityIDNum, 1, 1)
		table.insert(TOTAL_GFX, entityIDNum)
		offset = offset + 25
	end
end


--TOTAL: delete
function deleteTotalGFX()
	for i = 1, #TOTAL_GFX do
		entity_delete(TOTAL_GFX[i], 1)
		TOTAL_GFX[i] = nil
	end
end

--[[
--BOUGHT: delete then place
function updateBoughtGFX()
	deleteBoughtGFX()

	entityIDNum = 0

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_1, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_1")) - 175, node_y(getNode("vendorM_1")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end
	
	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_2, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_2")) - 175, node_y(getNode("vendorM_2")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end
	
	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_3, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_3")) - 175, node_y(getNode("vendorM_3")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_4, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_4")) - 175, node_y(getNode("vendorM_4")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_5, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_5")) - 175, node_y(getNode("vendorM_5")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_6, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_6")) - 175, node_y(getNode("vendorM_6")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_7, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_7")) - 175, node_y(getNode("vendorM_7")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_8, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_8")) - 175, node_y(getNode("vendorM_8")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_9, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_9")) - 175, node_y(getNode("vendorM_9")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_10, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_10")) - 175, node_y(getNode("vendorM_10")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_11, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_11")) - 175, node_y(getNode("vendorM_11")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end

	if isFlag(VENDORM_FOOD_BOUGHT_RECIPE_12, 1) then
		entityIDNum = createEntity("vendor_bought", "", node_x(getNode("vendorM_12")) - 175, node_y(getNode("vendorM_12")) + 10)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(BOUGHT_GFX, entityIDNum)
	end
end


--BOUGHT: delete
function deleteBoughtGFX()
	for i = 1, #BOUGHT_GFX do
		entity_delete(BOUGHT_GFX[i], 1)
		BOUGHT_GFX[i] = nil
	end
end
]]--