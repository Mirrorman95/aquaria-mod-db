dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
--dofile("scripts/entities/entityinclude.lua")

n = 0
displayed = false

function init(me)
	n = getNaija()
end

function update(me, dt)
	if not displayed and isFlag(QUEST_WALKER1, 2) and isFlag(DT_VERSION_DRASK, 1) and node_isEntityIn(me, n) then
		displayed = true
		setControlHint("Elena forgot to return to The Walker after finding a Mithalan skull.", 0, 0, 0, 8)
	end
end