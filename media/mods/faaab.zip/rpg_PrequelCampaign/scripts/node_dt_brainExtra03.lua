dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Extras/Cathedral/panelExtra03_"
entityOther = "lucien"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = DT_NEW_EXTRA03
flagRepeat = 0
flagVersion = DT_VERSION_EXTRA03
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"elena",		"3a",		"3b",		"3c"	},
		{"3a",				"other",		"4"								},
		{"3b",				"other",		"4"								},
		{"3c",				"other",		"4"								},
		{"4",				"elena",		"5a",		"5b",		0		},
		{"5a",				"other",		"exit"							},
		{"5b",				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 5A-5B
		if numPanel == "5a" or numPanel == "5b" then
			AlphaChatBubble()
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	CreateMapEntity(entityOther, x, y - 20, 0)
	CreateChatBubble(x + 40, y - 90, 0)
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end