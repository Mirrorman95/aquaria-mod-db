dofile("scripts/entities/entityinclude.lua")

n = 0
ix,iy=0,0
escapeNode=0

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_initSkeletal(me, "CC")
	entity_setAllDamageTargets(me, false)
	
	entity_scale(me, 0.6, 0.6)
	entity_setBlendType(me, BLEND_ADD)
	entity_alpha(me, 0.5)
	entity_alpha(me, 1, 1, -1, 1, 1)
end

function postInit(me)
	n = getNaija()
	entity_setTarget(me, n)
	
	entity_setState(me, STATE_IDLE)
	entity_rotate(me, 0)
end


function update(me, dt)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "cry", -1)
		entity_setPosition(me, entity_getPosition(me))
	elseif entity_isState(me, STATE_FOLLOW) then
		entity_animate(me, "float", -1)	
	elseif entity_isState(me, STATE_DONE) then
		
	end
end

function exitState(me)
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end

function animationKey(me, key)
end

function hitSurface(me)
end

function songNote(me, note)
end

function songNoteDone(me, note)
end

function song(me, song)
end

function activate(me)
end

