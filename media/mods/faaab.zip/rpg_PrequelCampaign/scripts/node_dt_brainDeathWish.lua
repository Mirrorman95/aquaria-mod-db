dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Events/Deathwish/panelDeathWish_"
entityOther = "rpg_mia"
entityOtherScale = 1.7
gemToCreate = 0

flagChatBubble = DT_NEW_DEATHWISH
flagRepeat = 0
flagVersion = DT_VERSION_DEATHWISH
flagMain = 0

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"1e1"							},
		{"1e1",				"other",		"2"								},
		{"2",				"elena",		"3",		"3",		"3"		},
		{"3",				"other",		"3e1"							},
		{"3e1",				"other",		"4"								},
		{"4",				"elena",		"5",		"5",		"5"		},
		{"5",				"other",		"6"								},
		{"6",				"other",		"exit"							},
	}



--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		if numPanel == "6" then
			AlphaChatBubble()
		end
	end	
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		if numPanel == "6" then
			disableInput()
			entity_setHealth(n, 1)
			entity_setPosition(n, x - 75, y)
			entity_animate(n, "agony", -1)
			--entity_animate(n, "diepainfully")
			
			fadeOutMusic(2)
			playSfx("naijazapped")
			overrideZoom(0.75, 3)
			
			watch(2)
			
			entity_animate(n, "dead")
			
			watch(1.5)
			
			loadMap("vanilla_vedhacave")
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)	
	CommonInit(me)
	CreateChatBubble(x + 50, y - 70, 0)
	CreateMapEntity(entityOther, x, y, 0)
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end