dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Books/panelBookcase_"
entityOther = ""
entityOtherScale = 1.7
gemToCreate = 0

flagChatBubble = 0
flagRepeat = 0
flagVersion = DT_VERSION_BOOKCASE
flagMain = 0

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"elena",		"2a",		"2b",		"2c"	},
		{"2a",				"other",		"2ae1"							},
		{"2ae1",			"other",		"2ae2"							},
		{"2ae2",			"other",		"1"								},
		{"2b", 				"other",		"2be1"							},
		{"2be1",			"other",		"2be2"							},
		{"2be2",			"other",		"1"								},
		{"2c",				"other",		"2ce1"							},
		{"2ce1",	 		"other", 		"1"								},
	}



--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if numPanel == "1" then
		entity_alpha(elena, 0)
		entity_alpha(other, 0)
	end
	
	--SPECIAL: panel text is extra wide due to no characters
	entity_setPosition(next, x + 700, y + 90)
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	chatBubble = createEntity("symbol_bookcase", "", node_x(me), node_y(me) - 175)
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end