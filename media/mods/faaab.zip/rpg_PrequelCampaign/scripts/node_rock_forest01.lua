dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	if isFlag(ROCK_FOREST01, 1) then
		rock = node_getNearestEntity(me, "Rock0005")
		node = getNode("FOREST01_ROCK_MOVED")
		if node ~= 0 then
			entity_setPosition(rock, node_x(node), node_y(node))
		end
	end
end


function update(me, dt)
	if isFlag(ROCK_FOREST01, 0) then
		if node_isEntityIn(me, getNaija()) then
			--debugLog("setting FLAG FOR ROCK")
			--voiceOnce("Naija_EnterEnergyTemple")
			setFlag(ROCK_FOREST01, 1)
		end
	end
end
