dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
numOption1 = 0
numOption2 = 0
numOption3 = 0
numClickedOption1 = 0
numClickedOption2 = 0
numClickedOption3 = 0
numNext = 0
numClickedNext = 0
total = 0

function init(me)
	--n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))	
end


function update(me, dt)
	numOption1 = getFlag(DT_OPTION1)
	numOption2 = getFlag(DT_OPTION2)
	numOption3 = getFlag(DT_OPTION3)
	numNext = getFlag(DT_NEXT)
	numClickedOption1 = getFlag(CLICKED_OPTION1)
	numClickedOption2 = getFlag(CLICKED_OPTION2) 
	numClickedOption3 = getFlag(CLICKED_OPTION3)
	numClickedNext = getFlag(CLICKED_NEXT)

	total = numOption1 + numOption2 + numOption3 + numNext + numClickedOption1 + numClickedOption2 + numClickedOption3 + numClickedNext
end

function activate(me)
	centerText(total)
	--setControlHint("Option1 = " + numOption1 + " | Option2 = " + numOption2 + " | Option3 = " + numOption3 + " | Next = " + numNext + "", 0, 0, 0, 8)
end