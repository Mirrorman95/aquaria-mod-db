dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
vendorCreature = 0

menu = 0
tempMenu = 0
canChangeMode = true
totalButtons = 4

tab1 = 0
tab2 = 0
tab3 = 0
GFX_Tab1 = 0
GFX_Tab2 = 0
GFX_Tab3 = 0

TIMER_GFX = {}

function init(me)
	--node_setCursorActivation(me, true)
	--createEntity("symbol_arena", "", node_x(me), node_y(me) - 110)
	--vendorCreature = createEntity("architect", "", node_x(me), node_y(me) + 20)
	
	setFlag(MENU_TAB, 1)

	tab1 = getNode("arena_tab1")
	tab2 = getNode("arena_tab2")
	tab3 = getNode("arena_tab3")
	
	--setControlHint("Time: " .. getFlag(ARENA_TIME) .. " secs | Map: " .. getStringFlag(ARENA_NAME), 0, 0, 0, 8)
end


function update(me, dt)
	if isFlag(MENU_ACTIVE, 1) then

		--CHANGE MODE: button graphics and menu graphic change
		if isFlag(MENU_CHANGE_MODE, 1) and canChangeMode then
			canChangeMode = false

			--TAB 1
			if isFlag(MENU_TAB, 1) then
				setFlag(MENU_CHANGE_MODE, 0)

				tempMenu = menu
				menu = createEntity("arena_page1", "", node_x(me), node_y(me) - 85)
				entity_alpha(menu, 0)
				entity_alpha(menu, 1, 1)

				--tab buttons
				entity_delete(GFX_Tab1)
				entity_delete(GFX_Tab2)
				entity_delete(GFX_Tab3)
				GFX_Tab1 = createEntity("arena_tab1-down", "", node_x(tab1), node_y(tab1))
				GFX_Tab2 = createEntity("arena_tab2-up", "", node_x(tab2), node_y(tab2))
				GFX_Tab3 = createEntity("arena_tab3-up", "", node_x(tab3), node_y(tab3))
				entity_alpha(GFX_Tab1, 1)
				entity_alpha(GFX_Tab2, 1)
				entity_alpha(GFX_Tab3, 1)

				--NODE: have each button create their timer
				setFlag(ARENA_PLACE_TIMERS, totalButtons)
	
				watch(1.0)
				entity_delete(tempMenu)
				node_setCursorActivation(tab2, true)
				node_setCursorActivation(tab3, true)
				canChangeMode = true
			--TAB 2
			elseif isFlag(MENU_TAB, 2) then
				setFlag(MENU_CHANGE_MODE, 0)
				
				tempMenu = menu
				menu = createEntity("arena_page2", "", node_x(me), node_y(me) - 85)
				entity_alpha(menu, 0)
				entity_alpha(menu, 1, 1)

				--tab buttons
				entity_delete(GFX_Tab1)
				entity_delete(GFX_Tab2)
				entity_delete(GFX_Tab3)
				GFX_Tab1 = createEntity("arena_tab1-up", "", node_x(tab1), node_y(tab1))
				GFX_Tab2 = createEntity("arena_tab2-down", "", node_x(tab2), node_y(tab2))
				GFX_Tab3 = createEntity("arena_tab3-up", "", node_x(tab3), node_y(tab3))
				entity_alpha(GFX_Tab1, 1)
				entity_alpha(GFX_Tab2, 1)
				entity_alpha(GFX_Tab3, 1)

				--NODE: have each button create their timer
				setFlag(ARENA_PLACE_TIMERS, totalButtons)
	
				watch(1.0)
				entity_delete(tempMenu)
				node_setCursorActivation(tab1, true)
				node_setCursorActivation(tab3, true)
				canChangeMode = true
			--TAB 3
			elseif isFlag(MENU_TAB, 3) then
				setFlag(MENU_CHANGE_MODE, 0)

				tempMenu = menu
				menu = createEntity("arena_page3", "", node_x(me), node_y(me) - 85)
				entity_alpha(menu, 0)
				entity_alpha(menu, 1, 1)

				--tab buttons
				entity_delete(GFX_Tab1)
				entity_delete(GFX_Tab2)
				entity_delete(GFX_Tab3)
				GFX_Tab1 = createEntity("arena_tab1-up", "", node_x(tab1), node_y(tab1))
				GFX_Tab2 = createEntity("arena_tab2-up", "", node_x(tab2), node_y(tab2))
				GFX_Tab3 = createEntity("arena_tab3-down", "", node_x(tab3), node_y(tab3))
				entity_alpha(GFX_Tab1, 1)
				entity_alpha(GFX_Tab2, 1)
				entity_alpha(GFX_Tab3, 1)

				--NODE: have each button create their timer
				setFlag(ARENA_PLACE_TIMERS, totalButtons)
				
				watch(1.0)
				entity_delete(tempMenu)
				node_setCursorActivation(tab1, true)
				node_setCursorActivation(tab2, true)
				canChangeMode = true
			end
		end

		--EXIT: 
		if isFlag(MENU_EXIT, 1) then
			menuWrapup()
			
			--node_setCursorActivation(me, true)
			setFlag(MENU_TAB, 1)
			setFlag(MENU_ACTIVE, 0)
			setFlag(MENU_EXIT, 0)
		end
	end
end

--ACTIVATE
function activate(me)
	if isFlag(MENU_ACTIVE, 0) then
		setFlag(MENU_ACTIVE, 1)
		node_setCursorActivation(me, false)
		menuSetup( node_x(me), node_y(me) )

		--instructions on first viewing
		if isFlag(ARENA_FIRST, 0) then
			setControlHint("Choose between bullet hell combat, puzzle/platform navigation, or boss rush. Old Fred will keep track of your fastest time.", 0, 0, 0, 8)
			setFlag(ARENA_FIRST, 1)
		end
	end
end


--SETUP: called by activate
function menuSetup(x,y)
	avatar_fallOffWall() 
	n = getNaija()
	overrideZoom(0.52)

	cam_setPosition(x, y)
	entity_setInvincible(n, true)
	entity_alpha(n, 0, 1.0)
	entity_setPosition(n, x, y)
	disableInput()
	toggleCursor(true, 0.1)

	playSfx("recipemenu-open")
	menu = createEntity("arena_page1", "", x, y - 1000)
	entity_setPosition(menu, x, y - 85, 1.5)

	watch(1.5)

	--BUTTON: tabs
	GFX_Tab1 = createEntity("arena_tab1-down", "", node_x(tab1), node_y(tab1))
	entity_alpha(GFX_Tab1, 1, 1)

	GFX_Tab2 = createEntity("arena_tab2-up", "", node_x(tab2), node_y(tab2))
	entity_alpha(GFX_Tab2, 1, 1)
	
	GFX_Tab3 = createEntity("arena_tab3-up", "", node_x(tab3), node_y(tab3))
	entity_alpha(GFX_Tab3, 1, 1)

	--NODE: tab buttons
	--node_setCursorActivation(getNode("arena_tab1"), true)
	node_setCursorActivation(getNode("arena_tab2"), true)
	node_setCursorActivation(getNode("arena_tab3"), true)
	
	--NODE: have each button create their timer
	setFlag(ARENA_PLACE_TIMERS, totalButtons)
end


--WRAPUP: called on exit
function menuWrapup()
	--TAB BUTTONS
	node_setCursorActivation(tab1, false)
	node_setCursorActivation(tab2, false)
	node_setCursorActivation(tab3, false)
	
	--DT OLD FRED
	node_setCursorActivation(getNode("dt_brainOldFred_DLC01"), true)
	
	--BUTTONS
	node_setCursorActivation(getNode("arena_button1"), false)
	node_setCursorActivation(getNode("arena_button2"), false)
	node_setCursorActivation(getNode("arena_button3"), false)
	node_setCursorActivation(getNode("arena_button4"), false)
	
	entity_delete(menu, 1)
	--entity_delete(tempFoodMenu, 1)
	entity_delete(GFX_Tab1, 1)
	entity_delete(GFX_Tab2, 1)
	entity_delete(GFX_Tab3, 1)
	
	--NODE: have each button delete their timer
	setFlag(ARENA_DELETE_TIMERS, totalButtons)
	
	entity_setInvincible(n, false)
	enableInput()
	entity_alpha(n, 1.0)
	overrideZoom(0)	

	cam_toEntity(n)
end