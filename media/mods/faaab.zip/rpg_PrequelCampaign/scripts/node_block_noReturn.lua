--dofile("scripts/entities/entityinclude.lua")
--dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
started = false

function init(me)
	n = getNaija()
end

function update(me, dt)
	if started == false and node_isEntityIn(me, n) then
		started = true

		avatar_fallOffWall()
		disableInput()
		cam_setPosition(node_x(me), node_y(me))
		entity_setInvincible(n, true)
		entity_setPosition(n, node_x(me), node_y(me))
		toggleCursor(true, 0.1)

		continue = confirm("You have reached the point \nof no return. Continue?", "buy")
		if( continue == true ) then
			warpNaijaToSceneNode("rpg_final", "top")
		else	
			entity_setInvincible(n, false)
			entity_idle(n)
			entity_clearVel(n)
			enableInput()
		
			started = false
			entity_setPosition(n, node_x(me), node_y(me) - 250)
		end
	end
end
