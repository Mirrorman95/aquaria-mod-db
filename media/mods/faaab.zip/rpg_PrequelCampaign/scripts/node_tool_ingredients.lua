dofile("scripts/entities/entityinclude.lua")

--[[
INGREDIENT_LIST = 
{ 
"spicyroll", "plantleaf", "specialbulb", "healingpoultice", "seacake", "leafpoultice", "heartysoup", "leachingpoultice", "hotsoup", "handroll", "dumboicecream", "redbulb", "spicymeat", "arcanepoultice", "swampcake", "sharkfinsoup", "spiderroll", "glowingegg", "rainbowmushroom", "leadershiproll", "tastyroll", "fishoil", "fishegg", "rukhegg", "turtlesoup", "sightpoultice", "coldborscht", "eeloil", "veggiesoup", "divinesoup", "sealoaf", "crabcake", "rottenmeat", "smalltentacle", "poisonloaf", "smallbone", "rottencake", "toughcake", "redberry", "veggiecake", "longlifesoup", "spicy soup", "legendarycake", "royalsoup", "specialcake", "perogi", "hotborscht", "icecream", "mushroom", "volcanoeroll", "plumpperogi", "fishmeat"   
}
]]--

n = 0

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function activate(me)
	--always find these functions after I write my own
	spawnAllIngredients(entity_x(n), entity_y(n))

	--[[for i=1, #INGREDIENT_LIST do
		spawnIngredient(INGREDIENT_LIST[i], node_x(me), node_y(me))
	end]]--
end