dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5
function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("Next map would be final encounter between Mia/Mithala/Naija/Eric. Map and fight have not been scripted.", 0, 0, 0, 13)
	elseif thingSaying == 1 then
		setControlHint("Mithala and Eric fight only using ranged attacks. Mithala will refuse to fight if you influenced him to believe there was hope.", 0, 0, 0, 13)
	elseif thingSaying == 2 then
		setControlHint("At the end of the fight Eric runs away and Mithala is banished to suffer in Mithalas.", 0, 0, 0, 10)
	elseif thingSaying == 3 then
		setControlHint("Mia tells Naija about everything being very honest and kind to her. Mia then ports Elena home. This is where you are about to be ported.", 0, 0, 0, 15)
	elseif thingSaying == 4 then
		--setFlag(LOAD_VISION, 0)	
		warpNaijaToSceneNode("rpg_Nightmare01", "right", "l")
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end