--[[
ENCOUNTER CODE: by Danny O'Connell (vxnervegas [at] gmail [dot] com)
Mia shows up with some minions and causes the PC a bit of trouble.
Mia calls the PC out after the PC has killed all spawned enemies.
]]--


dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()

	loadSound("mia-appear")
	loadSound("mia-scream")
	loadSound("mia-sillygirl")

	spawn1 = getNode("SPAWN1_EVIL")
	spawn2 = getNode("SPAWN2_EVIL")
	spawn3 = getNode("SPAWN3_EVIL")

	--node_setCursorActivation(me, true)
end


function update(me, dt)
	--Eric's minions show up and cause some trouble
	if isFlag(CS_DRUNIADS, 2) and node_isEntityIn(me, n) then
		setFlag(CS_DRUNIADS, 3)
		
		--SETUP
		playMusic("worship1")
		overrideZoom(0.45, 1)
		setSceneColor(0.5, 0.5, 1, 2)

		--WARPS
		playSfx("mia-appear")
		playSfx("mia-scream")
		spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
		spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
		spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))

		--SPAWN POINT 1
		ent1 = createEntity("mutilus", "", node_x(spawn1), node_y(spawn1))
		ent2 = createEntity("mutilus", "", node_x(spawn1), node_y(spawn1))
		ent3 = createEntity("mutileye", "", node_x(spawn1), node_y(spawn1))

		--SPAWN POINT 2
		ent4 = createEntity("mutilus", "", node_x(spawn2), node_y(spawn2))
		ent5 = createEntity("abyssoctopus", "", node_x(spawn2), node_y(spawn2))
		ent6 = createEntity("mutantnaija", "", node_x(spawn2), node_y(spawn2))

		--SPAWN POINT 3
		Mia = createEntity("eric_13", "", node_x(spawn3), node_y(spawn3))		

	
	--Mia says a few words and leaves after minions killed
	elseif isFlag(CS_DRUNIADS, 3) then
		--everything dead we just spawned?
		if entity_getNearestEntity(me, "mutilus") == 0 and entity_getNearestEntity(me, "mutileye") == 0 and entity_getNearestEntity(me, "abyssOctopus") == 0 and entity_getNearestEntity(me, "mutantNaija") == 0 then
			setFlag(CS_DRUNIADS, 4)

			--MIA MONOLOGUE
			playSfx("mia-sillygirl")
			setControlHint("This is not a fairy tale Princess Elena. Mithalas is mine. Aquaria will fall.",  0, 0, 0, 10, "13/face")
			spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))
			entity_delete(Mia, 2)

			--CLEANUP
			overrideZoom(0)
			setSceneColor(1, 1, 1, 2)
			updateMusic()
		end		
	end
end

--[[ DEBUG TOOL
function activate(me)
	setFlag(CS_DRUNIADS, 2)
	setControlHint("FLAG (CS_DRUNIADS) = " .. getFlag(CS_DRUNIADS),  0, 0, 0, 5, "")
end
]]--