dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleMithalasPot", FLAG_COLLECTIBLE_MITHALASPOT)
end

function update(me, dt)
end
