dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
--tempVar = 0
CHEAP_HOTEL = {}

Mia_Dark = 0
Mia_Light = 0

function init(me)
	n = getNaija()
	
	spawn_Mia = getNode("SPAWN_MIA")	
	spawn1 = getNode("SPAWN1")
	spawn2 = getNode("SPAWN2")
	spawn3 = getNode("SPAWN3")
	spawn4 = getNode("SPAWN4")

	Mia_Dark = createEntity("eric_13", "", node_x(spawn_Mia), node_y(spawn_Mia))

	tempVar = createEntity("mutantnaija", "", node_x(spawn1), node_y(spawn1))
	table.insert(CHEAP_HOTEL, tempVar)

	tempVar = createEntity("mutantnaija", "", node_x(spawn2), node_y(spawn2))
	table.insert(CHEAP_HOTEL, tempVar)

	tempVar = createEntity("mutantnaija", "", node_x(spawn3), node_y(spawn3))
	table.insert(CHEAP_HOTEL, tempVar)

	tempVar = createEntity("mutantnaija", "", node_x(spawn4), node_y(spawn4))
	table.insert(CHEAP_HOTEL, tempVar)

	loadSound("13Touch")
	loadSound("mia-scream")

	node_setCursorActivation(me, true)
end


function update(me, dt)
	if isFlag(CS_FINALWORDS, 0) and node_isEntityIn(me, n) then
		setFlag(CS_FINALWORDS, 1)
		--playMusic("inevitable")
		
		entity_setInvincible(n, true)
		entity_idle(n)
		entity_clearVel(n)

		--Destroy adds
		playSfx("mia-scream")
		for i=1, #CHEAP_HOTEL do
			entity_setState(CHEAP_HOTEL[i], STATE_DEATHSCENE)
			--entity_delete(CHEAP_HOTEL[i])
			CHEAP_HOTEL[i] = nil
			watch(0.5)
		end

		watch(2)

		setControlHint("You are my daughter.",  0, 0, 0, 8, "13/face")

		watch(8)

		setControlHint("This journey must end with me my daughter. Your true journey begins after death.",  0, 0, 0, 6, "13/face")

		watch(6)

		entity_animate(Mia_Dark, "touchNaija")

		watch(1)
		
		playSfx("13Touch")

		watch(1)

		playSFX("naijazapped")
		entity_animate(n, "diepainfully")
		--animations: dead, agony, headpain, fallen
		--entity_alpha(n, 0, 1)

		watch(5)

		Mia_Light = createEntity("rpg_Mia", "", node_x(spawn_Mia), node_y(spawn_Mia))
		entity_alpha(Mia_Light, 0)
		entity_alpha(Mia_Dark, 0, 1)
		entity_alpha(Mia_Light, 1, 1)

		watch(3)

		--loadMap("VedhaCave")
	end
end


function activate(me)
	setFlag(CS_FINALWORDS, 0)
	setControlHint("FLAG (CS_FINALWORDS) = " .. getFlag(CS_FINALWORDS),  0, 0, 0, 5, "")
end