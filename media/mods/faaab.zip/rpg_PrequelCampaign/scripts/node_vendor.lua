dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

n = 0
menu = 0
totalNum = 0
currencyNum = 0
totalNumGFX = 0
currencyNumGFX = 0

--lockVision1 = 0
lockSeahorse = 0
lockHealth = 0
lockCrystals2 = 0
lockVision2 = 0

boughtNature = 0
boughtFish = 0
boughtCrystals1 = 0
boughtSeahorse = 0
boughtHealth = 0
boughtCrystals2 = 0

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("symbol_treasure", "", node_x(me), node_y(me) - 250)

	--[[DEBUG TOOL: +6 currency
	setFlag(TOTAL_CRYSTALS, 6)
	setFlag(CURRENCY, 6)
	]]--
end


function update(me, dt)
	--GEM for WORLDMAP
	if node_isEntityIn(me, n) then
		if node_isFlag(me, 0) then
			node_foundGem(me, "vendor_items")
			node_setFlag(me, 1)
		end
	end
	
	--EXIT
	if isFlag(VENDOR_EXIT, 1) then
		vendorWrapup()
		
		node_setCursorActivation(me, true)
		setFlag(VENDOR_EXIT, 0)
		
		--ITEMS
		if isFlag(CREATE_SEAHORSE, 1) then
			setFlag(CREATE_SEAHORSE, 0)
			createEntity("collectibleseahorsecostume", "", node_x(me), node_y(me))
		end

		if isFlag(CREATE_CRYSTALS_1, 1) then
			setFlag(CREATE_CRYSTALS_1, 0)
			for i=1, 2 do
				createEntity("crystal_small", "", node_x(me), node_y(me))
			end
		end
		
		if isFlag(CREATE_HEALTH, 1) then
			setFlag(CREATE_HEALTH, 0)
			createEntity("healthupgrade0", "", node_x(me), node_y(me))
		end

		if isFlag(CREATE_CRYSTALS_2, 1) then
			setFlag(CREATE_CRYSTALS_2, 0)
			for i=1, 4 do
				createEntity("crystal_small", "", node_x(me), node_y(me))
			end
		end

		--VISIONS
		if isFlag(VIEW_VISION_1, 1) then
			setFlag(VIEW_VISION_1, 0)
			loadMap("rpg_vision1", "visionstart", "l")
		end

		if isFlag(VIEW_VISION_2, 1) then
			setFlag(VIEW_VISION_2, 0)
			loadMap("rpg_vision2", "visionstart", "r")
		end
	end
end


function activate(me)
	if isFlag(VENDOR_ACTIVE, 0) then
		setFlag(VENDOR_ACTIVE, 1)
		node_setCursorActivation(me, false)
		vendorSetup( node_x(me), node_y(me) )

		if isFlag(VENDOR_FIRST, 0) then
			setControlHint("All items can be obtained by trading 1 large memory crystal.", 0, 0, 0, 8, "lightcrystal/crystal", 0, 0.5)
			setFlag(VENDOR_FIRST, 1) 
		end
	end
end



function vendorSetup(x,y)
	avatar_fallOffWall() 
	n = getNaija()
	overrideZoom(0.52)

	cam_setPosition(x, y)
	entity_setInvincible(n, true)
	entity_alpha(n, 0, 1.0)
	entity_setPosition(n, x, y)
	disableInput()
	toggleCursor(true, 0.1)

	playSfx("recipemenu-open")
	menu = createEntity("vendorMenu", "", x, y - 1000)
	entity_setPosition(menu, x, y - 85, 1.5)

	watch(1.5)

	--place total number
	totalNum = getNode("totalNum")

	if getFlag(TOTAL_CRYSTALS) == 0 then
		totalNumGFX = createEntity("vendorNum_0", "", node_x(totalNum), node_y(totalNum))
	elseif getFlag(TOTAL_CRYSTALS) == 1 then
		totalNumGFX = createEntity("vendorNum_1", "", node_x(totalNum), node_y(totalNum))
	elseif getFlag(TOTAL_CRYSTALS) == 2 then
		totalNumGFX = createEntity("vendorNum_2", "", node_x(totalNum), node_y(totalNum))
	elseif getFlag(TOTAL_CRYSTALS) == 3 then
		totalNumGFX = createEntity("vendorNum_3", "", node_x(totalNum), node_y(totalNum))
	elseif getFlag(TOTAL_CRYSTALS) == 4 then
		totalNumGFX = createEntity("vendorNum_4", "", node_x(totalNum), node_y(totalNum))
	elseif getFlag(TOTAL_CRYSTALS) == 5 then
		totalNumGFX = createEntity("vendorNum_5", "", node_x(totalNum), node_y(totalNum))
	elseif getFlag(TOTAL_CRYSTALS) == 6 then
		totalNumGFX = createEntity("vendorNum_6", "", node_x(totalNum), node_y(totalNum))	
	end

	entity_alpha(totalNumGFX, 1, 1)

	--place currency number
	currencyNum = getNode("currencyNum")

	if getFlag(CURRENCY) == 0 then
		currencyNumGFX = createEntity("vendorNum_0", "", node_x(currencyNum), node_y(currencyNum))
	elseif getFlag(CURRENCY) == 1 then
		currencyNumGFX = createEntity("vendorNum_1", "", node_x(currencyNum), node_y(currencyNum))
	elseif getFlag(CURRENCY) == 2 then
		currencyNumGFX = createEntity("vendorNum_2", "", node_x(currencyNum), node_y(currencyNum))
	elseif getFlag(CURRENCY) == 3 then
		currencyNumGFX = createEntity("vendorNum_3", "", node_x(currencyNum), node_y(currencyNum))
	elseif getFlag(CURRENCY) == 4 then
		currencyNumGFX = createEntity("vendorNum_4", "", node_x(currencyNum), node_y(currencyNum))
	elseif getFlag(CURRENCY) == 5 then
		currencyNumGFX = createEntity("vendorNum_5", "", node_x(currencyNum), node_y(currencyNum))
	elseif getFlag(CURRENCY) == 6 then
		currencyNumGFX = createEntity("vendorNum_6", "", node_x(currencyNum), node_y(currencyNum))	
	end

	entity_alpha(currencyNumGFX, 1, 1)

	--item buttons
	fish = getNode("vendor_fish")
	crystals1 = getNode("vendor_crystals1")
	seahorse = getNode("vendor_seahorse")
	nature = getNode("vendor_nature")
	health = getNode("vendor_health")
	crystals2 = getNode("vendor_crystals2")
	
	vision1 = getNode("vendor_vision1")
	vision2 = getNode("vendor_vision2")

	--place lock images
	if getFlag(TOTAL_CRYSTALS) < 4 then
		lockNature = createEntity("vendor_lock", "", node_x(nature) + 20, node_y(nature) - 175)
		entity_alpha(lockNature, 1, 1)
		
		lockHealth = createEntity("vendor_lock", "", node_x(health) + 20, node_y(health) - 70)
		entity_alpha(lockHealth, 1, 1)
		
		lockCrystals2 = createEntity("vendor_lock", "", node_x(crystals2) + 20, node_y(crystals2) - 60)
		entity_alpha(lockCrystals2, 1, 1)
		
		lockVision2 = createEntity("vendor_lock", "", node_x(vision2), node_y(vision2))
		entity_alpha(lockVision2, 1, 1)
	end

	--place bought images / activate non-bought nodes
	node_setCursorActivation(vision1, true)
	node_setCursorActivation(vision2, true)

	if isFlag(VENDOR_BOUGHT_SEAHORSE, 1) then
		boughtSeahorse = createEntity("vendor_bought", "", node_x(seahorse), node_y(seahorse))
		entity_alpha(boughtSeahorse, 1, 1)
	else
		node_setCursorActivation(seahorse, true)
	end
	
	if isFlag(VENDOR_BOUGHT_FISH, 1) then
		boughtFish = createEntity("vendor_bought", "", node_x(fish), node_y(fish))
		entity_alpha(boughtFish, 1, 1)
	else
		node_setCursorActivation(fish, true)
	end

	if isFlag(VENDOR_BOUGHT_CRYSTALS_1, 1) then
		boughtCrystals1 = createEntity("vendor_bought", "", node_x(crystals1), node_y(crystals1))
		entity_alpha(boughtCrystals1, 1, 1)
	else
		node_setCursorActivation(crystals1, true)
	end
	
	if isFlag(VENDOR_BOUGHT_NATURE, 1) then
		boughtNature = createEntity("vendor_bought", "", node_x(nature), node_y(nature))
		entity_alpha(boughtNature, 1, 1)
	else
		node_setCursorActivation(nature, true)
	end

	if isFlag(VENDOR_BOUGHT_HEALTH, 1) then
		boughtHealth = createEntity("vendor_bought", "", node_x(health), node_y(health))
		entity_alpha(boughtHealth, 1, 1)
	else
		node_setCursorActivation(health, true)
	end

	if isFlag(VENDOR_BOUGHT_CRYSTALS_2, 1) then
		boughtCrystals2 = createEntity("vendor_bought", "", node_x(crystals2), node_y(crystals2))
		entity_alpha(boughtCrystals2, 1, 1)
	else
		node_setCursorActivation(crystals2, true)
	end
end


function vendorWrapup()
	entity_setInvincible(n, false)
	enableInput()
	entity_alpha(n, 1.0)
	overrideZoom(0)

	node_setCursorActivation(seahorse, false)
	node_setCursorActivation(fish, false)
	node_setCursorActivation(crystals1, false)
	node_setCursorActivation(vision1, false)
	node_setCursorActivation(nature, false)
	node_setCursorActivation(health, false)
	node_setCursorActivation(crystals2, false)
	node_setCursorActivation(vision2, false)
	
	entity_delete(menu, 1)
	entity_delete(lockNature, 1)
	entity_delete(lockHealth, 1)
	entity_delete(lockCrystals2, 1)
	entity_delete(lockVision2, 1)

	entity_delete(boughtNature, 1)
	entity_delete(boughtFish, 1)
	entity_delete(boughtCrystals1, 1)
	entity_delete(boughtSeahorse, 1)
	entity_delete(boughtHealth, 1)
	entity_delete(boughtCrystals2, 1)

	entity_delete(totalNumGFX, 1)
	entity_delete(currencyNumGFX, 1)

	cam_toEntity(n)
	
	setFlag(VENDOR_ACTIVE, 0)
	setFlag(VENDOR_EXIT, 0)
end