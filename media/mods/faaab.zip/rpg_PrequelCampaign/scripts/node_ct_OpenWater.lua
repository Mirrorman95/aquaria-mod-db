dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if isFlag(ENTER_OPENWATER, 0) and node_isEntityIn(me, n) then
		setFlag(ENTER_OPENWATER, 1)
		centerText("Open Water")
	end
end