dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if isFlag(HINT_VORTEX, 0) and node_isEntityIn(me, n) then
		setFlag(HINT_VORTEX, 1)
		setControlHint("[RIGHT CLICK] a vortex to warp Elena to its matching exit.", 0, 0, 0, 8)
	end
end