dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

num = 0

function init(me)
	--node_setCursorActivation(me, false)	
end

--[[
function update(me, dt)
	if isFlag(VENDOR_ACTIVE, 1) and isFlag(VENDOR_BOUGHT_FISH, 0) then
		node_setCursorActivation(me, true)
	else
		node_setCursorActivation(me, false)
	end
end
]]--

function activate(me)
	if getFlag(CURRENCY) < 1 then
		setControlHint("You don't have any large crystals to exchange!", 0, 0, 0, 8, "lightcrystal/crystal", 0, 0.5)
	else
		purchase = confirm("Are you sure you want to purchase\nItem: Fish Form", "buy")
		if( purchase == true ) then
			setFlag(VENDOR_EXIT, 1)
			num = getFlag(CURRENCY)
			setFlag(CURRENCY, num - 1)
		
			setFlag(VENDOR_BOUGHT_FISH, 1)
			node_setCursorActivation(me, false)
	
			learnSong(SONG_FISHFORM)
			changeForm(FORM_FISH)
			setControlHint("Learned the Fish Form Song!", 0, 0, 0, 8, "", SONG_FISHFORM)
		end
	end
end