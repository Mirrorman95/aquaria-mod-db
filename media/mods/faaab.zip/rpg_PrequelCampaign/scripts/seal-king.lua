dofile("scripts/include/sealtemplate.lua")

function init(me)
	commonInit(me, "Seal-King", FLAG_SEAL_KING)
end
