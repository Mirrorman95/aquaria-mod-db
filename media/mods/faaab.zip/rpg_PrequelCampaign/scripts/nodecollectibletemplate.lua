dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function commonInit(me, object, flag)

	--Display in Elena's Home starting at Act 3
	if isFlag(flag, 1) and isFlag(MITHALAS_CORRUPTED, 1) and isMapName("rpg_CathedralHome") then
		collectible = createEntity(object, "", node_x(me), node_y(me))
		entity_setState(collectible, STATE_COLLECTEDINHOUSE)

	--Display in rpg_Cathedral01 at all times (not corrupted version though)
	elseif isFlag(flag, 1) and isMapName("rpg_Cathedral01") then
		collectible = createEntity(object, "", node_x(me), node_y(me))
		entity_setState(collectible, STATE_COLLECTEDINHOUSE)
	end
end
