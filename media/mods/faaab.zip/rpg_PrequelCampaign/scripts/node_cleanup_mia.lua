dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
cleanupStarted = false

ENTITY_HOTEL = {"abaddon", "abyssoctopus", "blaster", "groundshocker", "horror", "mermanthin", "mutantnaija", "mutileye", "mutilus"}


function init(me)
	n = getNaija()

	loadSound("mia-scream")
end


function update(me, dt)
	if cleanupStarted == false and node_isEntityIn(me, n) then
		cleanupStarted = true
		
		playSfx("mia-scream")
		shakeCamera(20, 2)

		ent = getFirstEntity()
		while ent ~= 0 do
			for i=1, #ENTITY_HOTEL do
				if entity_getName(ent) == ENTITY_HOTEL[i] then
					entity_delete(ent)
				end
			end		
			ent = getNextEntity()
		end
	end
end

--DEBUG TOOL: must be called by another node
function activate(me)
	ent = getFirstEntity()
	while ent ~= 0 do
		for i=1, #ENTITY_HOTEL do
			if entity_getName(ent) == ENTITY_HOTEL[i] then
				entity_delete(ent)
			end
		end		
		ent = getNextEntity()
	end
end