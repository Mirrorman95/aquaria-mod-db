dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))
dofile("scripts/entities/entityinclude.lua")

imagePath = "panels/Drask/panelDrask_"
entityOther = "drask-statue"
entityOtherScale = 1.7
gemToCreate = 0

flagChatBubble = DT_NEW_DRASK
flagRepeat = DT_REPEAT_DRASK
flagVersion = DT_VERSION_DRASK
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion3 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"elena",		"3a",		"3b",		0		},
		{"3a",				"other",		"3e1"							},
		{"3b",				"other",		"3e1"							},
		{"3e1", 			"other",		"4"								},
		{"4",				"elena",		"5a",		0,			"5b"	},
		{"5a",				"other",		"6"								},
		{"5b",				"other",		"6"								},
		{"6",				"elena",		"7",		"7",		0		},
		{"7",				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 3
	if isFlag(flagVersion, 3) then
		if numPanel == "7" then
			--LEARN SPIRIT FORM
			learnSong(SONG_SPIRITFORM)
			setControlHint(getStringBank(44), 0, 0, 0, 10, "", SONG_SPIRITFORM)
			
			nodeClickableOnExit = false
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 3
	if isFlag(flagVersion, 3) then
		--PANEL 7
		if numPanel == "7" then
			--RAJAH_V3
			if getFlag(DT_VERSION_RAJAH) < 3 then
				setFlag(DT_REPEAT_RAJAH, 0)
				setFlag(DT_VERSION_RAJAH, 3)
				setFlag(DT_NEW_RAJAH, 0)
			end
			
			--DELETE CHAT BUBBLE
			ent = getFirstEntity()
			while ent ~= 0 do
				if entity_isName(ent, "symbol_chatBubble") then
					entity_delete(ent, 1)
				end	
				ent = getNextEntity()
			end	
			
			--DRASK LAST RITES
			setFlag(DEATH_OF_DRASK, 3)
			node_setCursorActivation(me, false)
			doorEnter = node_getNearestEntity(getNode("DOORENTER"), "energydoor")
			entity_setState(doorEnter, STATE_OPEN)

			watch(2)

			createEntity("collectibletridenthead", "", x, y)
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)	
	CommonInit(me)
	
	--DRASK VS PRIEST DUEL DONE
	if isFlag(DEATH_OF_DRASK, 1) then
		CreateMapEntity(entityOther, x, y, 0)
		node_setCursorActivation(me, false)
				
	--PRIESTS DEAD
	elseif isFlag(DEATH_OF_DRASK, 2) then
		CreateMapEntity(entityOther, x, y, 0)
		CreateChatBubble(x + 50, y - 80, 0)

	--DRASK DEAD
	elseif isFlag(DEATH_OF_DRASK, 3) then
		CreateMapEntity(entityOther, x, y, 0)
		node_setCursorActivation(me, false)
	end
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end