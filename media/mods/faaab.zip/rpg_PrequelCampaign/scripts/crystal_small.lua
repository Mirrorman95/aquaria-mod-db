dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

n = 0
collected = false

function init(me)
	n = getNaija()
	
	setupEntity(me, "crawlvirus/head", -1)
	entity_setEntityType(me, ET_NEUTRAL)
	--entity_setCull(me, false)
	entity_scale(me, 1, 1)
	entity_setEntityLayer(me, 0)

	entity_setCollideRadius(me, 16)
	entity_setWeight(me, 150)
	entity_setBounce(me, 0.3)

	-- random X movement in + or -
	goLeft = chance(50)
	ranNum = math.random(75)

	if goLeft then
		entity_addVel(me, -ranNum, -350)
		entity_rotate(me, -360, 2, 1)
	else
		entity_addVel(me, ranNum, -350)
		entity_rotate(me, 360, 2, 1)
	end
end

function update(me, dt)
	if (collected == false) then
		entity_updateMovement(me, dt)
		entity_updateCurrents(me)
		
	--COLLECT MONIES
		if entity_isEntityInRange(me, n, 64) == true then
			collected = true
			--playSfx("secret")
			playSfx("pickup-ingredient")
			entity_delete(me)
		
		--CURRENCY: add 1
			currency = getFlag(CURRENCY_SMALL_CRYSTALS)
			currency = currency + 1
			setFlag(CURRENCY_SMALL_CRYSTALS, currency)

		--TOTAL: add 1
			total = getFlag(TOTAL_SMALL_CRYSTALS)
			total = total + 1
			setFlag(TOTAL_SMALL_CRYSTALS, total)

		--SHOW PLAYER WHAT THEY GOTZ
			setControlHint("Currency = " .. getFlag(CURRENCY_SMALL_CRYSTALS) .. " | Total Collected = " .. getFlag(TOTAL_SMALL_CRYSTALS), 0, 0, 0, 5, "crawlvirus/head")
		end
	end
end

function hitSurface(me)
end