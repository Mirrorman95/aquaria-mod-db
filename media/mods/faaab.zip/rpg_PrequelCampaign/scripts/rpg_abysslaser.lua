dofile("_mods/rpg_PrequelCampaign/scripts/rpg_include.lua")

delay = 0

function init(me)
	setupEntity(me)
	
	entity_initSkeletal(me, "AbyssOctopus")	
	
	entity_setState(me, STATE_IDLE)
	
	entity_rotate(me, -45, -300, 0)
	
	eyes = entity_getBoneByName(me, "Eyes")
end

function update(me, dt)
	if entity_isState(me, STATE_IDLE) then
		if delay > 60 then
			delay = 0
		end
		
		beam_setPosition(beam, entity_getPosition(me))	

		delay = delay + dt

		if delay >= 2 then
			beam_delete(beam)
			beam = 0
			bone_setColor(eyes, 1, 1, 1, 1)
		end
	end
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)		
	elseif entity_isState(me, STATE_SHOOTLASER) then
		delay = 0
		bone_setColor(eyes, 1, 0, 0, 1)
		entity_animate(me, "charge")
		entity_setStateTime(me, 0.5)
		entity_sound(me, "EnergyOrbCharge")
	end
end

function exitState(me)
	if entity_isState(me, STATE_SHOOTLASER) then
		entity_sound(me, "PowerUp")
		entity_sound(me, "FizzleBarrier")
		beam = createBeam(bx, by, entity_getRotation(me) - 180)
		beam_setTexture(beam, "particles/Beam")
		entity_setState(me, STATE_IDLE)
	end
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end