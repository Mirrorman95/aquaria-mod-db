dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 13
holderID = 14
flag = ED_OLDFRED_02

dofile("scripts/include/energyslottemplate.lua")