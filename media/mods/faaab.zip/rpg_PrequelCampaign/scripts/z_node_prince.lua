dofile("scripts/entities/entityinclude.lua")

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5
function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("Prince Drask: I cannot hide his eyes for much longer. Eric will eventually find us and he will kill us. ", 0, 0, 0, 16)
	elseif thingSaying == 1 then
		setControlHint("Prince Drask: All of his focus on Mia and he is blind to all else that he does.", 0, 0, 0, 16)
	elseif thingSaying == 2 then
		setControlHint("Prince Drask: Continue right to see the various obstructions you can make.", 0, 0, 0, 16)
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end

