dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
delay = 3
delayvoice = 3
delayloadmap = 10

spawn1 = 0
spawn2 = 0
spawn3 = 0
spawn4 = 0

drask = 0
chatBubble = 0

function init(me)
	node_setCursorActivation(me, true)
	n = getNaija()

	spawn1 = getNode("spawn1")
	spawn2 = getNode("spawn2")
	spawn3 = getNode("spawn3")
	spawn4 = getNode("spawn4")
	
	loadSound("gateway-die")
	loadSound("screaming")
	loadSound("mia_scream")

	drask = createEntity("drask", "", node_x(me), node_y(me))
	entity_fh(drask)
	--entity_setState(drask, STATE_IDLE)
	entity_animate(drask, "idle", -1)
	
	chatBubble = createEntity("symbol_chatbubble", "", node_x(me) - 40, node_y(me) - 90)
	entity_fh(chatBubble)
end


function update(me, dt)
	--entity_setInvincible(n, true)

	if isFlag(NIGHTMARE_HOLE, 1) then
		playSfx("mia_scream")

		entity_delete(drask, 2)
		entity_delete(chatBubble, 2)

		spawnHole1 = createEntity("nightmare_Hole", "", node_x(spawn1), node_y(spawn1))
		entity_alpha(spawnHole1, 0)
		entity_alpha(spawnHole1, 1, 2)

		spawnHole2 = createEntity("nightmare_Hole", "", node_x(spawn2), node_y(spawn2))
		entity_alpha(spawnHole2, 0)
		entity_alpha(spawnHole2, 1, 2)

		spawnHole3 = createEntity("nightmare_Hole", "", node_x(spawn3), node_y(spawn3))
		entity_alpha(spawnHole3, 0)
		entity_alpha(spawnHole3, 1, 2)

		spawnHole4 = createEntity("nightmare_Hole", "", node_x(spawn4), node_y(spawn4))
		entity_alpha(spawnHole4, 0)
		entity_alpha(spawnHole4, 1, 2)

		playMusic("worship3")
		playSfx("screaming")
		
		setFlag(NIGHTMARE_HOLE, 2)
	end

	if isFlag(NIGHTMARE_HOLE, 2) then
		if delay > 0 then
			delay = delay - dt
		else
			createEntity("nightmare_M", "", node_x(spawn1), node_y(spawn1))
			createEntity("nightmare_M", "", node_x(spawn2), node_y(spawn2))
			createEntity("nightmare_M", "", node_x(spawn3), node_y(spawn3))
			createEntity("nightmare_M", "", node_x(spawn4), node_y(spawn4))
			shakeCamera(10, 1)
			delay = 2
		end

		if delayvoice > 0 then
			delayvoice = delayvoice - dt
		else
			playSfx("gateway-die")
			delayvoice = 2
		end	

		if delayloadmap > 0 then
			delayloadmap = delayloadmap - dt
		else
			loadMap("rpg_nightmare02", "start", "r")
		end	
	end
end

function activate(me)	
	--setControlHint("Inevitability has finally arrived for you.",  0, 0, 0, 10, "13/face")
	
	node_setCursorActivation(me, false)
	setFlag(NIGHTMARE_HOLE, 1)
end