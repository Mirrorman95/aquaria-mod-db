dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleSeedBag", FLAG_COLLECTIBLE_SEEDBAG)
end

function update(me, dt)
end
