dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

num = 0

function init(me)
	--node_setCursorActivation(me, false)	
end

--[[
function update(me, dt)
	if isFlag(VENDOR_ACTIVE, 1) then
		node_setCursorActivation(me, true)
	else
		node_setCursorActivation(me, false)
	end
end
]]--

function activate(me)
	if getFlag(TOTAL_CRYSTALS) < 4	 then
		setControlHint("This vision is locked until you have collected FOUR large crystals. However, you don't have to exchange a large crystal to view it.", 0, 0, 0, 8, "lightcrystal/crystal", 0, 0.5)
	else
		purchase = confirm("Are you sure you want to view\n Vision 2?", "buy")
		if purchase == true then
			node_setCursorActivation(me, false)
			
			setFlag(VENDOR_EXIT, 1)
			setFlag(VIEW_VISION_2, 1)

			--loadMap("rpg_vision2", "visionstart", "r")
			--setControlHint("Map does not exist yet.", 0, 0, 0, 8)
		end
	end
end