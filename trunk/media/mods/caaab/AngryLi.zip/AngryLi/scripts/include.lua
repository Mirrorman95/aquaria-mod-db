-- dofile(appendUserDataPath("_mods/AngryLi/scripts/include.lua"))

-- additional amount of screen to the left and right (support for widescreen)
WIDESCREEN_AMOUNT = 400

-- last checkpoint position
CHECKPOINT_X = 402
CHECKPOINT_Y = 403

FLAG_INTRO = 404