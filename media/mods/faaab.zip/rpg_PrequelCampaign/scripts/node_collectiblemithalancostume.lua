dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleMithalanCostume", FLAG_COLLECTIBLE_MITHALANCOSTUME)
end

function update(me, dt)
end
