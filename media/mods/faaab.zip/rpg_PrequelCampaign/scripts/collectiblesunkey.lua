-- song cave collectible

--dofile("scripts/include/collectibletemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/collectibletemplate.lua"))

function init(me)
	commonInit(me, "Collectibles/sun-key", FLAG_COLLECTIBLE_SUNKEY)
end

function update(me, dt)
	commonUpdate(me, dt)
end

function enterState(me, state)
	commonEnterState(me, state)
	--[[
	if entity_isState(me, STATE_COLLECTEDINHOUSE) then
		createEntity("ClockworkFish", "", entity_x(me)-100, entity_y(me)-200)
		createEntity("ClockworkFish", "", entity_x(me)+100, entity_y(me)-400)
	end
	]]--
end

function exitState(me, state)
	commonExitState(me, state)
end
