dofile("scripts/entities/entityinclude.lua")

n = 0
done = false

function init(me)
	n = getNaija()

	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function activate(me)
	setControlHint("You have found every treasure!",  0, 0, 0, 6)

	debugLog("all treasures")
	for i = FLAG_COLLECTIBLE_START, (FLAG_COLLECTIBLE_END-1) do
		setFlag(i, 1)
	end
end

--[[

--I keep finding existing functions that do something I spent some time developing! =/
dofile("scripts/entities/entityinclude.lua")

--n = 0

function init(me)
	--n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function activate(me)
	setFlag(FLAG_COLLECTIBLE_MITHALASPOT, 1)
	setFlag(FLAG_COLLECTIBLE_BANNER, 1)
	setFlag(FLAG_COLLECTIBLE_TURTLEEGG, 1)
	setFlag(FLAG_COLLECTIBLE_SKULL, 1)
	setFlag(FLAG_COLLECTIBLE_STARFISH, 1)
	setFlag(FLAG_COLLECTIBLE_STONEHEAD, 1)
	setFlag(FLAG_COLLECTIBLE_TRIDENTHEAD, 1)
	setFlag(FLAG_COLLECTIBLE_MITHALADOLL, 1)
	setFlag(FLAG_COLLECTIBLE_CHEST, 1)
	setFlag(FLAG_COLLECTIBLE_SEEDBAG, 1)
	setFlag(FLAG_COLLECTIBLE_ARNASSISTATUE, 1)
	setFlag(FLAG_COLLECTIBLE_BLACKPEARL, 1)
	setFlag(FLAG_COLLECTIBLE_JELLYPLANT, 1)
	setFlag(FLAG_COLLECTIBLE_SUNKEY, 1)
	setFlag(FLAG_COLLECTIBLE_WALKERBABY, 1)
	setFlag(FLAG_COLLECTIBLE_GEAR, 1)
	setFlag(FLAG_COLLECTIBLE_ANEMONESEED, 1)
	setFlag(FLAG_COLLECTIBLE_BIOSEED, 1)
	setFlag(FLAG_COLLECTIBLE_SPORESEED, 1)
	setFlag(FLAG_COLLECTIBLE_UPSIDEDOWNSEED, 1)
	setFlag(FLAG_COLLECTIBLE_SONGCAVE, 1)
	setFlag(FLAG_COLLECTIBLE_ENERGYSTATUE, 1)
	setFlag(FLAG_COLLECTIBLE_ENERGYBOSS, 1)
	setFlag(FLAG_COLLECTIBLE_NAIJACAVE, 1)
end

FLAG_COLLECTIBLE_URCHINCOSTUME
FLAG_COLLECTIBLE_TEENCOSTUME
FLAG_COLLECTIBLE_MUTANTCOSTUME
FLAG_COLLECTIBLE_JELLYCOSTUME
FLAG_COLLECTIBLE_MITHALANCOSTUME
FLAG_COLLECTIBLE_SEAHORSECOSTUME
FLAG_COLLECTIBLE_CRABCOSTUME
FLAG_COLLECTIBLE_ENERGYTEMPLE
]]--