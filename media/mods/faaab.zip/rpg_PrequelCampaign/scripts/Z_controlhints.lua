dofile("scripts/entities/entityinclude.lua")

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5
function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("MIA: Naija, you must travel to the ends of the world to save your people from certain destruction. This is your task", 0, 0, 0, 16)
	elseif thingSaying == 1 then
		setControlHint("MIA: To toggle the Obstruction View on/off, use the F9 key.", 0, 0, 0, 16)
	elseif thingSaying == 2 then
		setControlHint("MIA: Continue right to see the various obstructions you can make.", 0, 0, 0, 16)
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end

