dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_cutman.lua"))

flag = TIMER_BOSS_TREE02

function init(me)
	commonInit(me, flag)
end

function update(me, dt)	
	commonUpdate(me, dt, flag)
end