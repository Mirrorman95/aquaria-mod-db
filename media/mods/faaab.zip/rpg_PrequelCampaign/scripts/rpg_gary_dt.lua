dofile("scripts/entities/entityinclude.lua")

n = 0
sx=0
sy=0
attackDelay = 1 + math.random(100)/100
fireDelay = 0

frontHand = 0
backHand = 0

function init(me)
	setupEntity(me)
	entity_setEntityLayer(me, 0)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_initSkeletal(me, "CastleCrab")
	
	entity_setState(me, STATE_IDLE)
	
	frontHand = entity_getBoneByName(me, "FrontHand")
	backHand = entity_getBoneByName(me, "BackHand")
end

function update(me, dt)
end

function postInit(me)
	n = getNaija()
	entity_setTarget(me, n)
	node = entity_getNearestNode(me, "FLIP")
	if node ~=0 then
		if node_isEntityIn(node, me) then
			entity_fh(me)
		end
	end
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end