dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/angryli/scripts/include.lua"))

n = 0
inNode = false

function init(me)
	n = getNaija()
end

function update(me, dt)

	if not inNode and node_isEntityIn(me, n) then
		inNode = true
		if node_isFlag(me, 0) then
			node_setFlag(me, 1)
			setControlHint("Left clic to fire missiles. You have Infinite Ammo", 1, 0, 0, 3)
		end
		entity_msg(getEntity("lisub"),"activatemissile")
	end
end