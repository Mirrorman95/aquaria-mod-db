dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, true)
	next = createEntity("panel_next", "", node_x(me), node_y(me))
	entity_alpha(next, 1)
end

function activate(me)
	setFlag(MITHALAS_VISION, 2)

	setFlag(DT_VERSION_DRASK, 2)
	setFlag(DT_VERSION_MIA, 2)
	setFlag(DT_VERSION_RAJAH, 2)
	setFlag(DT_VERSION_NAIJA, 2)
	setFlag(DT_VERSION_OLDFRED, 2)
	setFlag(DT_VERSION_WALKER, 2)
	
	setFlag(DT_REPEAT_DRASK, 0)
	setFlag(DT_REPEAT_WALKER, 0)

	centerText("Version 2")
end