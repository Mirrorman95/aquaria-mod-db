dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/MagicOfAquaria/scripts/flags.lua"))

n = 0
 
function init(me)
 
	setupEntity(me)
 
	-- set entity graphic
	entity_setTexture(me,"missingImage")
	
	-- entity_initSkeletal(me, "00_starter")
	-- entity_scale(me, 1, 1)
	
	entity_setEntityType(me, ET_ENEMY)
	entity_setHealth(me, 5)
	entity_setCollideRadius(me, 32)
	entity_setUpdateCull(me, 2000)
	entity_setDeathParticleEffect(me, "TinyRedExplode")
	entity_setMaxSpeed(me, 100)

end
 
function postInit(me)
	n = getNaija()
	entity_setTarget(me, n)
end
 
function update(me, dt)
 
	entity_handleShotCollisions(me)
	entity_touchAvatarDamage(me, entity_getCollideRadius(me), 1, 1200)
	entity_doCollisionAvoidance(me, dt, 4, 1.0)
 
	entity_flipToVel(me)
	
	entity_updateMovement(me, dt)
end

function damage(me, attacker, bone, damageType, dmg)
	return true
end
 
function dieNormal(me)
	if chance(20) then
		spawnIngredient("PlantLeaf", entity_x(me), entity_y(me))
	end
end
 
function enterState(me)

	if entity_isState(me, STATE_IDLE) then
		entity_setState(me, STATE_IDLE)
	end

end
 
function exitState(me)

	if entity_isState(me, STATE_IDLE) then
		entity_setState(me, STATE_IDLE)
	end

end
 
 
function hitSurface(me)
end
 
function songNote(me, note)
end
 
function songNoteDone(me, note)
end
 
function song(me, song)
end
 
function activate(me)
end