--dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
done = false

function init(me)
	n = getNaija()
end

function update(me, dt)
	if not done and entity_getRiding(n) ~= 0 and node_isEntityIn(me, n) then
		done = true
		setControlHint("Cool!", 0, 0, 0, 8)
	end
end