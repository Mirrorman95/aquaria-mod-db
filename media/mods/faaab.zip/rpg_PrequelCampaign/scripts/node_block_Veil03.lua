dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	door = node_getNearestEntity(me, "EnergyDoor")
	
	if isFlag(QUEST_OLDFRED_SOUP, 0) then
		entity_setState(door, STATE_CLOSED)
	else
		entity_setState(door, STATE_OPENED)
	end
end