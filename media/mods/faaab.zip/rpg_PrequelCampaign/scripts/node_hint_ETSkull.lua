dofile("scripts/entities/entityinclude.lua")

n = 0
displayed = false

function init(me)
	n = getNaija()
end

function update(me, dt)
	if not displayed and isFlag(FLAG_COLLECTIBLE_SKULL, 0) and node_isEntityIn(me, n) then
		setControlHint("Elena missed the artifact The Walker instructed her to find and had to turn around. Poor soul.", 0, 0, 0, 8)
		displayed = true
	end
end