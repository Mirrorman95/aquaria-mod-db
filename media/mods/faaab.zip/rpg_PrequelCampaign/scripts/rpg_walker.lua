dofile("scripts/entities/entityinclude.lua")

moveTimer = 0
n = 0
seen = false

function init(me)
	setupEntity(me, "walker")
	
	entity_setCullRadius(me, 2048)
	
	entity_setEntityType(me, ET_NEUTRAL)
	
	entity_initSkeletal(me, "rpg_walker")
	bone_body = entity_getBoneByName(me, "Body")
	
	-- DARKEN BACK LEGS
	backLeg1Bottom = entity_getBoneByName(me, "BackLeg1Bottom")
	backLeg1Top = entity_getBoneByName(me, "BackLeg1Top")
	BackLeg2Bottom = entity_getBoneByName(me, "BackLeg2Bottom")
	backLeg2Top = entity_getBoneByName(me, "BackLeg2Top")
	cl = 0.64
	bone_color(backLeg1Bottom, cl, cl, cl)
	bone_color(backLeg1Top, cl, cl, cl)
	bone_color(BackLeg2Bottom, cl, cl, cl)
	bone_color(backLeg2Top, cl, cl, cl)

	entity_scale(me, 1.23, 1.23)
end

function postInit(me)
	entity_setState(me, STATE_IDLE)
	
	n = getNaija()
	
	-- FLIP WITH A FLIP NODE
	node = entity_getNearestNode(me, "FLIP")
	if node ~=0 then
		if node_isEntityIn(node, me) then 
			entity_fh(me)
		end
	end
end

function update(me, dt)	
	-- emote
	if entity_isEntityInRange(me, n, 512) then
		if not seen then
			if chance(50) then
				emote(EMOTE_NAIJAWOW)
				seen = true
			end
		end
	end

	--entity_setDeathParticleEffect(me, "Explode")
end

function enterState(me)
	if entity_getState(me) == STATE_IDLE then
		entity_animate(me, "idle", LOOP_INF)
	end
end