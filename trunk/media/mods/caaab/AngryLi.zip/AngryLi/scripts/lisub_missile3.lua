dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/AngryLi/scripts/include.lua"))
dofile(appendUserDataPath("_mods/AngryLi/scripts/lisub_missilecommon.lua"))

function init(me)
	commonInit(me,
               8, -- damage
			   "missile3" -- animation
			   )
end
 
function exitState(me)
end
 
function songNote(me, note)
end
 
function songNoteDone(me, note)
end
 
function song(me, song)
end
 
function activate(me)
end