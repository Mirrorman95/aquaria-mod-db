dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

Tab_1_Item = "leadershiproll"
Tab_1_Cost = 1
Tab_2_Item = "heartysoup"
Tab_2_Cost = 2

n = 0
num = 0
purchase = false


function init(me)
	node_setCursorActivation(me, false)
	n = getNaija()
end


function activate(me)
--NO CRYSTALS
	if getFlag(CURRENCY_SMALL_CRYSTALS) < 1 then
		setControlHint("You don't have any small crystal fragments.", 0, 0, 0, 3, "crawlvirus/head")
--TAB 1
	elseif isFlag(VENDORM_FOOD_TAB, 1) then
		if getFlag(CURRENCY_SMALL_CRYSTALS) < Tab_1_Cost then
			setControlHint("You don't have enough small crystal fragments.", 0, 0, 0, 3, "crawlvirus/head")
		else
			purchase = confirm("Are you sure you want to purchase\nItem: " .. Tab_1_Item .. " \nCost: " .. Tab_1_Cost .. " small crystal(s)", "buy")
			if( purchase == true ) then
				setStringFlag(PURCHASE, Tab_1_Item)

				num = getFlag(CURRENCY_SMALL_CRYSTALS)
				setFlag(CURRENCY_SMALL_CRYSTALS, num - Tab_1_Cost)
			end
		end
--TAB 2
	elseif isFlag(VENDORM_FOOD_TAB, 2) then
		if getFlag(CURRENCY_SMALL_CRYSTALS) < Tab_2_Cost then
			setControlHint("You don't have enough small crystal fragments.", 0, 0, 0, 3, "crawlvirus/head")
		else
			purchase = confirm("Are you sure you want to purchase\nItem: " .. Tab_2_Item .. " \nCost: " .. Tab_2_Cost .. " small crystal(s)", "buy")
			if( purchase == true ) then
				setStringFlag(PURCHASE, Tab_2_Item)

				num = getFlag(CURRENCY_SMALL_CRYSTALS)
				setFlag(CURRENCY_SMALL_CRYSTALS, num - Tab_2_Cost)	
			end	
		end
	end
end