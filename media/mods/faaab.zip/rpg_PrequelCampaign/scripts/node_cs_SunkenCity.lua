--dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
camDummy = 0

function init(me)
	n = getNaija()
	entity_setPosition(n, 250, 250)

	camDummy = createEntity("Empty")
	start = getNode("start")
	finish = getNode("finish")
	b1_start = getNode("b1_start")
	b1_finish = getNode("b1_finish")
	b2_start = getNode("b2_start")
	b2_finish = getNode("b2_finish")
	b3_start = getNode("b3_start")
	b3_finish = getNode("b3_finish")
	b4_finish = getNode("b4_finish")
	dust = getNode("dust")
	
	entity_warpToNode(camDummy, start)
	cam_toEntity(camDummy)
	overrideZoom(0.4)
	watch(3)
	fade(0,4)


	building1 = createEntity("building1", "", node_x(b1_start), node_y(b1_start))
	entity_rotate(building1, -30, 0, 0)
	entity_setPosition(building1, node_x(b1_finish), node_y(b1_finish), 20)
	entity_rotate(building1, 25, 20, 0)

	building2 = createEntity("building2", "", node_x(b2_start), node_y(b2_start))
	entity_setPosition(building2, node_x(b2_finish), node_y(b2_finish), 20)
	entity_rotate(building2, 30, 0, 0)
	entity_rotate(building2, -30, 20, 0)

	building4 = createEntity("building3", "", node_x(b3_start) + 200, node_y(b3_start) - 600)
	entity_scale(building4, 0.75, 0.75)
	entity_setPosition(building4, node_x(b4_finish), node_y(b4_finish), 20)
	entity_rotate(building4, 5, 0, 0)

	dust1 = spawnParticleEffect("dusttrail", node_x(dust) - 250, node_y(dust))
	dust2 = spawnParticleEffect("dusttrail", node_x(dust) + 250, node_y(dust))
	building3 = createEntity("building3", "", node_x(b3_start), node_y(b3_start))
	entity_setPosition(building3, node_x(b3_finish), node_y(b3_finish), 20)
	entity_rotate(building3, -5, 0, 0)		
	
	entity_warpToNode(camDummy, start)
	cam_toEntity(camDummy)
	entity_setPosition(camDummy, node_x(finish), node_y(finish), 35)	
	watch(5)	

	setControlHint("Eric will retreat within himself in an attempt to recreate his past life but he will only find more sadness.", 0, 0, 0, 8)
	watch(9)

	setControlHint("He will no longer wish for the love of his mother...but for the love of anyone. His anger has locked the door to his heart and you are the only one that can open it.", 0, 0, 0, 8)
	watch(9)
	
	watch(3)
	fade(1,4)
	watch(3.5)
	
	--goToTitle()
	loadMap("vanilla_mithalas02")
end