dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleTurtleEgg", FLAG_COLLECTIBLE_TURTLEEGG)
end

function update(me, dt)
end
