dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

elena = 0
naija_teen = 0

seat = 0
seat2 = 0
tame = 0
leave = 0
elenaAttached = false
naijaAttached = false
myFlag = 0

light1 = 0
light2 = 0

seen = false
sbank = 0

--Seahorse additions
waiting = false
incut = false
moveTimer = 0
moveDir = 0
avoidCollisionsTimer = 0
riding = false
noteDown = -1
dirx = 0
diry = 0


function init(me)
	elena = getNaija()

	setupEntity(me, "")
	entity_initSkeletal(me, "TransTurtle")

	entity_setEntityType(me, ET_NEUTRAL)
	entity_setActivation(me, AT_CLICK, 128, 512)

	seat = entity_getBoneByName(me, "Seat")
	seat2 = entity_getBoneByName(me, "Seat2")
	tame = entity_getBoneByName(me, "Tame")
	entity_setCullRadius(me, 1024)
	
	bone_alpha(seat, 0)
	bone_alpha(seat2, 0)
	bone_alpha(tame, 0)
	
	light1 = entity_getBoneByName(me, "Light1")
	light2 = entity_getBoneByName(me, "Light2")
	
	bone_setBlendType(light1, BLEND_ADD)
	bone_setBlendType(light2, BLEND_ADD)	

	loadSound("TransTurtle-Light")
	loadSound("transturtle-takeoff")
	
	entity_setMaxSpeed(me, 200)
end

function lights(me, on, t)
	a = 1
	if not on then
		a = 0
		debugLog("Lights off!")
	else
		debugLog("Lights on!")
	end
	
	bone_alpha(light1, a, t)
	bone_alpha(light2, a, t)
end

function postInit(me)
	t = entity_getNearestNode(me, "FLIP")
	if t ~= 0 and node_isEntityIn(t, me) then
		entity_fh(me)
	end

	naija_teen = createEntity("rpg_naija_l", "", entity_x(me) - 450, entity_y(me) + 20)
	
	-- turn on ze lights
	lights(me, true, 0)
	
	-- if naija starts on a turtle, ignore the seen/hint
	if entity_isEntityInRange(me, elena, 350) then
		seen = true
	end
end

function update(me, dt)
	entity_setActivationType(me, AT_CLICK)

	if noteDown ~= -1 then
		amt = 2000*dt
		entity_addVel(me, dirx*amt, diry*amt)
	end

	if entity_getHealth(getNaija()) < 1 then
		stopRide(me)
	else
		overrideZoom(0.55, 1.5)
	end
		
	if elenaAttached then
		--entity_flipToSame(elena, me)
		x,y = bone_getWorldPosition(seat)
		entity_setRidingData(me, x, y, 0, entity_isfh(me))
	end
		
	if naijaAttached then
		x,y = bone_getWorldPosition(seat2)
		entity_setPosition(naija_teen, x, y)
		entity_rotate(naija_teen, entity_getRotation(me))
		if entity_isfh(me) and not entity_isfh(naija_teen) then
			entity_fh(naija_teen)
		elseif not entity_isfh(me) and entity_isfh(naija_teen) then
			entity_fh(naija_teen)
		end
	end
	
	--FLIP
	if dirx < 0 and entity_velx(me) < -100 then
		if entity_isFlippedHorizontal(me) then
			entity_flipHorizontal(me)
		end
	elseif dirx > 0 and entity_velx(me) > 100 then
		if not entity_isFlippedHorizontal(me) then
			entity_flipHorizontal(me)
		end
	end
			
	entity_doCollisionAvoidance(me, dt, 4, 0.6)
	--entity_doCollisionAvoidance(me, dt, 2, 1.0)
	entity_updateMovement(me, dt)
	
	if noteDown == -1 then
		entity_doFriction(me, dt, 450)
	end
end

--ENTER STATE
function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end

function activate(me)
	if incut then return end
	if avatar_isOnWall() then return end
	
	if riding then
		stopRide(me)
	else
		startRide(me)
	end
end

--START RIDE
function startRide(me)
	incut = true
	
	debugLog("start ride")
	entity_setMaxSpeedLerp(me, 3.5, 1)
	
	entity_setInvincible(me, true)
	entity_setInvincible(elena, true)
	entity_clearVel(me)
	entity_clearVel(elena)

	--[[entity_idle(elena)
	entity_animate(me, "swimPrep")
	
	while entity_isAnimating(me) do
		watch(FRAME_TIME)
	end
	]]--
	
	x,y = bone_getWorldPosition(seat)
	entity_swimToPosition(elena, x, y)
	entity_watchForPath(elena)
	entity_animate(elena, "rideTurtle", LOOP_INF, LAYER_OVERRIDE)
	elenaAttached = true
	entity_setRiding(elena, me)
	
	if entity_isfh(me) and not entity_isfh(elena) then
		entity_fh(elena)
	elseif not entity_isfh(me) and entity_isfh(elena) then
		entity_fh(elena)
	end

	if naija_teen ~= 0 then
		--debugLog("here!")
		--entity_setState(naija_teen, STATE_PUPPET, -1, 1)
		x2,y2 = bone_getWorldPosition(seat2)
		entity_swimToPosition(naija_teen, x2, y2)
		entity_watchForPath(naija_teen)
		entity_animate(naija_teen, "rideTurtle", -1)
		naijaAttached = true
		entity_setRiding(naija_teen, me)
	end

	riding = true

	entity_setInvincible(me, false)
	entity_setInvincible(elena, false)
	setCameraLerpDelay(0.05)
	cam_toEntity(me)
	
	incut = false
end

--STOP RIDE
function stopRide(me)
	debugLog("stop ride")
	if riding then
		--entity_sound(me, "SeahorseWhinny")	

		overrideZoom(0)
		riding = false
		
		entity_stopAllAnimations(elena)
		entity_idle(elena)
		--setCanWarp(true)
		entity_setRiding(elena, 0)
		entity_addVel(elena, entity_velx(me), entity_vely(me))
		entity_clearVel(me) 
		
		if not entity_isUnderWater(elena) then
			entity_animate(elena, "burst")
		else
			entity_setMaxSpeedLerp(me, 1, 1)
		end
		
		setCameraLerpDelay(0)
		cam_toEntity(getNaija())
	end
end

-- SONGNOTE MOVEMENT
function songNote(me, note)
	if riding then
		--debugLog("noteUp!")
		noteDown = note
		amt = 1
		amt2 = 0.5
		dirx = 0
		diry = 0
		
		if note == 0 then
			--entity_addVel(me, 0, amt)
			dirx = 0
			diry = amt
		elseif note == 1 then
			--entity_addVel(me, amt2, amt2)
			dirx = amt2
			diry = amt2
		elseif note == 2 then
			--entity_addVel(me, amt, 0)
			dirx = amt
			diry = 0
		elseif note == 3 then
			--entity_addVel(me, amt2, -amt2)
			dirx = amt2
			diry = -amt2
		elseif note == 4 then
			--entity_addVel(me, 0, -amt2)
			dirx = 0
			diry = -amt2
		elseif note == 5 then
			--entity_addVel(me, -amt2, -amt2)
			dirx = -amt2
			diry = -amt2
		elseif note == 6 then
			--entity_addVel(me, -amt2, 0)
			dirx = -amt2
			diry = 0
		elseif note == 7 then
			--entity_addVel(me, -amt2, amt2)
			dirx = -amt2
			diry = amt2
		end
		
		if not entity_isUnderWater(me) then
			if diry < 0 then
				diry = 0
			end
			diry = diry + amt2*0.5
		end
	end
end

function songNoteDone(me, note)
	--debugLog("songNoteDone function")
	if note == noteDown then
		--debugLog("noteDone!")
		dirx = 0
		diry = 0
		noteDown = -1
	end
end