-- song cave collectible

--dofile("scripts/include/collectibletemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/collectibletemplate.lua"))

function init(me)
	commonInit(me, "Collectibles/mithalas-banner", FLAG_COLLECTIBLE_BANNER)
end

function update(me, dt)
	commonUpdate(me, dt)
end

function enterState(me, state)
	commonEnterState(me, state)
	if entity_isState(me, STATE_COLLECTEDINHOUSE) then
		--[[
		createEntity("JellySmall", "", node_x(me)-64, node_y(me))
		createEntity("JellySmall", "", node_x(me)+64, node_y(me))
		createEntity("JellySmall", "", node_x(me), node_y(me)+32)
		]]--
	end	
end

function exitState(me, state)
	commonExitState(me, state)
end
