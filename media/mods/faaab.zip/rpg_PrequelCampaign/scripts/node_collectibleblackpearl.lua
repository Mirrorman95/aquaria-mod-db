dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleBlackPearl", FLAG_COLLECTIBLE_BLACKPEARL)
end

function update(me, dt)
end
