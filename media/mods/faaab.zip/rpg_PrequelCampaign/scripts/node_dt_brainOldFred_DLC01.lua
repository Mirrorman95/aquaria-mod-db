dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/OldFred/panelOldFred_DLC01_"
entityOther = "architect"
entityOtherScale = 0.8
gemToCreate = 0

flagChatBubble = DT_NEW_OLDFRED_DLC01
flagRepeat = 0
flagVersion = DT_VERSION_OLDFRED_DLC01
flagMain = DT_MAIN_OLDFRED_DLC01

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"elena", 	"2",		"2",		"2",	},
		{"2", 				"other",	"3", 							},
		{"3", 				"elena",	"4a",		"4b",		"4c",	},
		{"4a", 				"other",	"exit",							},
		{"4b", 				"other",	"4e1",							},
		{"4c", 				"other",	"4e1",							},
		{"4e1", 			"other",	"5",							},
		{"5",				"elena",	"6a", 		"6b",		"6c",	},
		{"6a",				"other",	"exit", 						},
		{"6b", 				"other",	"exit", 						},
		{"6c", 				"other",	"exit", 						},
	}

--ACTION PANEL
function ActionPanel()
	if numPanel == "5" then
		AlphaChatBubble()		
	end
end

--ACTION EXIT
function ActionExit()
	if numPanel == "6a" or numPanel == "6b" or numPanel == "6c" then
		--ARENA MENU
		setFlag(flagMain, 1)
		node_activate(getNode("arenaMaster"))
	end
	
	numPanel = "1"
	currentRowID = 1
end

--INIT
function init(me)
	CommonInit(me)
	CreateChatBubble(x + 45, y - 80)
	CreateMapEntity(entityOther, x, y, 0)
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)
	--IF MAIN ON THIS VERSION
	if getFlag(flagVersion) == getFlag(flagMain) then
		--VERSION 1
		if isFlag(flagMain, 1) then
			node_activate(getNode("arenaMaster"))
		end
	else
		CommonActivate(me)
	end
end