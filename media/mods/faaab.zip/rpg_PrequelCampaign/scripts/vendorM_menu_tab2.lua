dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "gui/vendorM_menu_tab2")	

	entity_scale(me, 1.4, 1.4)
	entity_setEntityLayer(me, 1)
end

function update(me, dt)
end