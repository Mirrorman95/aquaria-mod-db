dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
camDummy = 0

-----------------------------------
-- THIS CUTSCENE IS NOT USED ATM --
-----------------------------------

function init()
	n = getNaija()
	entity_setPosition(n, 0, 0)
	cam = createEntity("Empty")
	start = getNode("START")
	brutal = getNode("BRUTAL")
	first = getNode("FIRST")
	second = getNode("SECOND")
	fullView = getNode("FULLVIEW")
	abyssLaser = getEntityByName("RPG_ABYSSLASER")
	laserVictim = getEntityByName("RPG_LASERVICTIM")
	mithalanGod = getEntityByName("RPG_MITHALANGOD")
	

	overrideZoom(0.4)
	entity_warpToNode(cam, fullView)
	cam_toEntity(cam)
	watch(1)
	fadeIn(2)

	setControlHint("Their never ceasing dependence on their creator had begun to drive Mithala away to become a much more sinister being.", 0, 0, 0, 6)
	watch(10)

	setControlHint("From his mouth he spews forth new Mithalans only to have their first breath silenced by his rage. The waters begin to darken from the blood of his children.", 0, 0, 0, 6)
	--watch(10)

	shakeCamera(30, 10)
	entity_animate(mithalanGod, "AcidSpray", 0)
	watch(2)
	playSfx("HellBeast-Roar")
	uhoh = createEntity("merchild", "", 2000, 2800)
	entity_rotate(uhoh, 360, -100, 0)
	entity_moveToNode(uhoh, brutal, SPEED_SLOW)
	watch(2)
	spawnParticleEffect("bigredexplode", entity_getPosition(uhoh))
	entity_setState(uhoh, STATE_DEAD, -1, 1)
	watch(4)

	fade(1,4)
	watch(3)
	--loadMap("rpg_cathedralhome")
	loadMap("rpg_intro03")
end