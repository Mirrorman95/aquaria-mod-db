SONG_LIST = { --Format: {length (seconds), filename, song title}
{113, "abyss", "Abyss"},
{27, "ancienttest", "Ancient Test"},
{81, "arboreal", "Arboreal"},
{124, "archaic", "Archaic"},
--{9, "bblogo", "Bit Blot Logo"},
{83, "bigboss", "Big Boss"},
{113, "brightwaters", "Bright Waters"},
{91, "cathedral", "Cathedral"},
{76, "cave", "Cave"},
{72, "druniaddance", "Druniad Dance"},
{58, "endingpart1", "Ending Part 1"}, --only has music for first 32 seconds
{69, "fallenbreed", "Fallen Breed"},
{162, "fallofmithalas", "Fall of Mithalas"},
{22, "flyaway", "Fly Away"},
{52, "forestgod", "Forest God"},
{46, "gullet", "Gullet"},
{82, "hopeofwinter", "Hope of Winter"},
{128, "icywaters", "Icy Waters"},
{52, "inevitable", "Inevitable"},
{43, "licave", "Li's Cave"},
{99, "light", "Light"},
{192, "losttothewaves", "Lost to the Waves"},
{53, "lucien", "Lucien"},
{56, "marchofthekrotites", "March of the Krotites"},
{88, "miniboss", "Miniboss"},
{31, "mithala", "Mithala"},
{67, "mithalaanger", "Mithala Anger"},
{22, "mithalaend", "Mithala End"},
{61, "mithalapeace", "Mithala Peace"},
{120, "moment", "Moment"},
{21, "mystery", "Mystery"},
{108, "openwaters", "Open Waters"},
{77, "openwaters2", "Open Waters Alternative"},
{134, "openwaters3", "Undiscovered Waters"},
{67, "prelude", "Prelude"},
{91, "prometheus", "Prometheus"},
{142, "remains", "Remains"},
{89, "seahorse", "Seahorse"},
{94, "sunken", "Mom'n'Pop Jam"},
{165, "sunkencity", "Sunken City"},
{38, "suntemple", "Sun Temple"},
{41, "sunworm", "Sun Worm"},
{58, "sunwormcave", "Sun Worm Cave"},
{43, "superflyremix", "superflyremix"},
--{3, "test", "Test"},
{62, "thebody", "The Body"},
{150, "theend", "The End"},
{96, "title", "Title"},
{85, "veil", "Veil"},
{84, "worship1", "Worship 1"},
{72, "worship2", "Worship 2"},
{55, "worship3", "Worship 3"},
{36, "worship4", "Worship 4"},
{76, "worship5", "Worship 5"},
{58, "youth", "Youth"}
}

--[[
DEFAULT_WATERLEVEL = 0

OVERRIDE_WATERLEVEL = {
	["ancienttest"] = -2700,
}
--]]

function jukebox_initButton(me)
	node_setCursorActivation(me, true)
	node_setCatchActions(me, true)
end

function jukebox_doButtonAction(me, action, state, transitions, isdefault)
	if isNestedMain() then return end
	if getNodeToActivate() == me and state == 1 then
		local name = transitions[action]
		if name then
			debugLog("jukebox_doButtonAction : "..node_getName(me).." -- "..action.." -> "..name)
			local node = getNode(name)
			setNodeToActivate(node)
			setMousePos(toWindowFromWorld(node_x(node), node_y(node)-20))
		end
		return false
	end
	if getNodeToActivate() == 0 and state == 1 and isdefault then
		if action == ACTION_MENURIGHT or action == ACTION_MENULEFT or action == ACTION_MENUUP or action == ACTION_MENUDOWN then
			setNodeToActivate(me)
			setMousePos(toWindowFromWorld(node_x(me), node_y(me)-20))
		end
		return false
	end
	return true
end

function jukebox_getSong()
    return getFlag(380)
end

function jukebox_getSongLength()
    return SONG_LIST[getFlag(380)][1]*2-1 -- casual testing indicates that my numbers are a second or so too long
end

function jukebox_incrementSongTimer(dt)
	setStory(getStory() + dt)
	return getStory()
end

function jukebox_playSong(index)
	-- Reset song timer
	setStory(0) -- Using the "story" global variable for the song timer, as it is floating-point
	setFlag(380, index) -- Using flag 380 for the song index, as flags can only store integers
	local songName = SONG_LIST[index][2]
	setControlHint("Now playing: "..SONG_LIST[index][3].."\n("..songName..".ogg)") --Hint will never fade
	playMusic(songName)

	--[[
	local waterLevel = getWaterLevel()
	local newWaterLevel = OVERRIDE_WATERLEVEL[songName] or DEFAULT_WATERLEVEL
	if newWaterLevel ~= waterLevel then setWaterLevel(newWaterLevel) end
	--]]
end
