dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleTurtleShell", FLAG_COLLECTIBLE_TURTLESHELL)
end

function update(me, dt)
end
