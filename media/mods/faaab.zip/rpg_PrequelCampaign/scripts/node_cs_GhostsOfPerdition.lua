--dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

Mia_1 = 0
Mia_2 = 0
Mia_3 = 0

Mithalan_1 = 0
Mithalan_2 = 0
Mithalan_3 = 0

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)

	if isFlag(CS_GHOSTS_IN_MITHALAS, 1) then
		setCutscene(1,1)
		setFlag(CS_GHOSTS_IN_MITHALAS, 2)

	--CAMERA: setup
		start = getNode("camStart")
		finish = getNode("camFinish")
		
		camDummy = createEntity("Empty")
		entity_warpToNode(camDummy, start)
		setCameraLerpDelay(0)
		cam_toEntity(camDummy)
		overrideZoom(0.55)

	--SCENE COLOR/LOAD SFX
		fade2(0, 1, 1, 1, 1)
		setSceneColor(0.5, 0.5, 1, 0)

		entity_setPosition(getNaija(), 0, 0)
		--playMusic("sunwormcave")
		playMusic("inevitable")

		loadSound("mia-appear")
		loadSound("mia-scream")
		loadSound("mia-sillygirl")

	--CS_ENTITIES: spawn at designated node 
		--mithalans
		spawn_Mithalan_1 = getNode("SPAWN_MITHALAN_1")
		spawn_Mithalan_2 = getNode("SPAWN_MITHALAN_2")
		spawn_Mithalan_3 = getNode("SPAWN_MITHALAN_3")		
		Mithalan_1 = createEntity("merman", "", node_x(spawn_Mithalan_1), node_y(spawn_Mithalan_1))
		Mithalan_2 = createEntity("merwoman", "", node_x(spawn_Mithalan_2), node_y(spawn_Mithalan_2))
		Mithalan_3 = createEntity("merchild", "", node_x(spawn_Mithalan_3), node_y(spawn_Mithalan_3))

		--dark mia ghosts...of perdition
		spawn_Mia_1 = getNode("SPAWN_MIA_1")
		spawn_Mia_2 = getNode("SPAWN_MIA_2")
		spawn_Mia_3 = getNode("SPAWN_MIA_3")
		Mia_1 = createEntity("eric_13", "", node_x(spawn_Mia_1), node_y(spawn_Mia_1))
		Mia_2 = createEntity("eric_13", "", node_x(spawn_Mia_2), node_y(spawn_Mia_2))
		Mia_3 = createEntity("eric_13", "", node_x(spawn_Mia_3), node_y(spawn_Mia_3))
		entity_flipToEntity(Mia_1, Mithalan_1)

	--ELENA AND NAIJA
		entity_scale(Mia_2, 0.55, 0.55)
		entity_scale(Mia_3, 0.5, 0.5)

	--CAMERA: lets roll!
		entity_setPosition(camDummy, node_x(finish), node_y(finish), 20)

	--FADE IN
		fade2(0, 1, 1, 1, 1)
		fadeIn(1)
		
		watch(4)

	--INCOMING!
		entity_setPosition(Mia_1, node_x(spawn_Mithalan_1), node_y(spawn_Mithalan_1), 4)
		playSfx("mia-appear")
		
		watch(4)

		spawnParticleEffect("MiaWarp", node_x(spawn_Mithalan_1), node_y(spawn_Mithalan_1))
		entity_alpha(Mithalan_1, 0, 2)
		entity_alpha(Mia_1, 0, 2)

		entity_setPosition(Mia_2, node_x(spawn_Mithalan_2), node_y(spawn_Mithalan_2), 5)
		playSfx("mia-scream")

		watch(2)

		entity_setPosition(Mia_3, node_x(spawn_Mithalan_3), node_y(spawn_Mithalan_3), 3)
		playSfx("mia-sillygirl")
	
		watch(3)

		spawnParticleEffect("MiaWarp", node_x(spawn_Mithalan_2), node_y(spawn_Mithalan_2))
		entity_alpha(Mithalan_2, 0, 2)
		entity_alpha(Mia_2, 0, 2)
		spawnParticleEffect("MiaWarp", node_x(spawn_Mithalan_3), node_y(spawn_Mithalan_3))
		entity_alpha(Mithalan_3, 0, 2)
		entity_alpha(Mia_3, 0, 2)

		watch(6)

	--LOADMAP: go back to Rajah
		setCutscene(0)
		loadMap("rpg_Cathedral01", "dt_brainRajah")
	end
end

--[[
function activate(me)
	setFlag(CS_GHOSTS_IN_MITHALAS, 1)
	setControlHint("FLAG (CS_GHOSTS_IN_MITHALAS) = " .. getFlag(CS_GHOSTS_IN_MITHALAS),  0, 0, 0, 5, "")
end
]]--