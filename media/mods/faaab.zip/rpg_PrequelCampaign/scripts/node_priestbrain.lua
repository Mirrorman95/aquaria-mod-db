dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

n = 0
started = false
priests = {}
numPriests = 0

doorEnter = 0
doorToMithala = 0

function init(me)
	n = getNaija()

	e = getFirstEntity()
	i = 1
	while e ~=0 do
		if entity_isName(e, "Priest") then
			priests[i] = e
			i = i + 1

			if isFlag(FLAG_MITHALAS_PRIESTS, 1) then
				entity_delete(e)
			end
		end		

		e = getNextEntity()
	end
	numPriests = i
	
	doorEnter = node_getNearestEntity(getNode("DOORENTER"), "energydoor")
	doorToMithala = node_getNearestEntity(getNode("DOORTOMITHALA"), "energydoor")

	if isFlag(FLAG_MITHALAS_PRIESTS, 1) then
		entity_setState(doorToMithala, STATE_OPENED)
	end
end
	
function activate(me)	
end

function update(me, dt)
	if isFlag(FLAG_MITHALAS_PRIESTS,0) then
		if not started then
			if node_isEntityIn(me, n) then
				started = true

				entity_setState(doorEnter, STATE_CLOSE)

				entity_idle(n)
				playMusic("MiniBoss")
				for i=1,numPriests do
					cam_toEntity(priests[i])
					entity_setState(priests[i], STATE_APPEAR)
					watch(1)
				end

				--original = 0.6
				overrideZoom(0.4, 1)

				cam_toEntity(n)
				for i=1,numPriests do
					entity_setState(priests[i], STATE_IDLE)
				end				
			end
		else
			c = 0
			e = getFirstEntity()
			while e ~= 0 do
				if entity_getEntityType(e) == ET_ENEMY and entity_isName(e, "Priest") then					
					c = c + 1
				end
				e = getNextEntity()
			end

			if c == 0 then
				debugLog("PriestEncounter: No priests left")

				setFlag(FLAG_MITHALAS_PRIESTS, 1)
				--setFlag(FLAG_MINIBOSS_PRIESTS, 1)
				
			--DRASK V3
				debugLog("PriestEncounter: setup talk to Drask_v3")
				setFlag(DEATH_OF_DRASK, 2)
				nodeDrask = getNode("dt_brainDrask_v3")
				node_setCursorActivation(nodeDrask, true)

			--CHAT BUBBLE: for Drask v3
				debugLog("PriestEncounter: chatBubble for Drask_v3")
				chatBubble = createEntity("symbol_chatbubble", "", node_x(nodeDrask) + 50, node_y(nodeDrask) - 80)
				entity_alpha(chatBubble, 0)
				entity_alpha(chatBubble, 1, 2)

			--DOORS: doorEnter opened by Drask_v3 as of v1.02
				--entity_setState(doorEnter, STATE_OPEN)
				debugLog("PriestEncounter: open mithala door")
				entity_setState(doorToMithala, STATE_OPEN)

				updateMusic()
				overrideZoom(0)

				--[[
				entity_idle(n)
				changeForm(FORM_NORMAL)
				watch(1)
				entity_setInvincible(n, true)
				watch(1)				
				entity_animate(n, "agony", LOOP_INF)
				learnSong(SONG_SPIRITFORM)
				watch(1)
				changeForm(FORM_SPIRIT)
				--voice("naija_song_spiritform")
				setControlHint(getStringBank(44), 0, 0, 0, 10, "", SONG_SPIRITFORM)
				entity_setInvincible(n, false)
				]]--				
			end
		end
	end
end