dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 1
holderID = 2
flag = ED_ENERGYTEMPLE02_STATUE

dofile("scripts/include/energyslottemplate.lua")