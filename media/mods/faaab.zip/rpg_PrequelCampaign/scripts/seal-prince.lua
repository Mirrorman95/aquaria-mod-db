dofile("scripts/include/sealtemplate.lua")

function init(me)
	commonInit(me, "Seal-Prince", FLAG_SEAL_PRINCE)
end
