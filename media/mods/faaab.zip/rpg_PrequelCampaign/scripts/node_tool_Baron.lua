dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

function init(me)
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function activate(me)
	setFlag(FLAG_MITHALAS_PRIESTS, 1)
	setFlag(DEATH_OF_DRASK, 2)
	setFlag(DT_VERSION_DRASK, 3)

	setControlHint("Level must be reloaded for the following changes to take effect: Mithalas Priests killed, Drask_v3 conversation available.",  0, 0, 0, 8, "")
end