dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/AngryLi/scripts/include.lua"))
dofile(appendUserDataPath("_mods/AngryLi/scripts/lisub_missilecommon.lua"))

function init(me)
	commonInit(me,
               4, -- damage
			   "missile1" -- animation
			   )
end

-- function update(me, dt)
	-- commonUpdate(me, dt)
-- end
 
function exitState(me)
end
 
function songNote(me, note)
end
 
function songNoteDone(me, note)
end
 
function song(me, song)
end
 
function activate(me)
end