
n= 0
isenergylearned=false

function init(me)
	n = getNaija()
	createEntity("hintBubble", "", node_x(me), node_y(me))
end


function update(me, dt)

if isenergylearned==false then
 if node_isEntityIn(me, n) then
   setControlHint("You've found a new song! You can now use ENERGY form!", 0, 0, 0, 16)
   learnSong(1)
   isenergylearned=True
 end
end 

end