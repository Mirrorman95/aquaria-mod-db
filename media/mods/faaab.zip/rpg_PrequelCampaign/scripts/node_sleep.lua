dofile("scripts/entities/EntityInclude.lua")

function init(me)
	node_setCursorActivation(me, true)
end
	
function activate(me)
	n = getNaija()
	
	if getForm() ~= FORM_NORMAL then
		entity_idle(n)
		watch(0.5)
		changeForm(FORM_NORMAL)
		watch(0.5)
	end
	
	entity_swimToNode(n, me)
	entity_watchForPath(n)
	entity_animate(n, "sleep", LOOP_INF)
	overrideZoom(1.25, 2)
	watch(1)
	
	emote(EMOTE_NAIJASADSIGH)
	musicVolume(0.01, 2)
	fadeOut(1)
	watch(1)
	
	entity_heal(getNaija(), 999)
	
	watch(2)
	
	watch(2)

	fadeIn(1)
	watch(1)

	while (not isLeftMouse()) and (not isRightMouse()) do
		watch(FRAME_TIME)
	end
	
	entity_idle(n)
	entity_addVel(n, 0, -200)
	overrideZoom(1, 1)
	musicVolume(1, 1)
	esetv(n, EV_NOINPUTNOVEL, 0)
	watch(1)
	esetv(n, EV_NOINPUTNOVEL, 1)
	overrideZoom(0)	
end

function update(me, dt)
end
