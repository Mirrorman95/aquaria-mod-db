--NOT BEING USED DUE TO CONFUSION IN ALPHA


dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if node_isEntityIn(me, n) then
		if isFlag(MITHALAS_VISION, 0) then
			warpNaijaToSceneNode("rpg_oldFred", "bottom")
		elseif isFlag(MITHALAS_VISION, 1) then
			warpNaijaToSceneNode("rpg_CathedralPriest", "visionstart", "r")
		end
	end
end