dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("How are you not dead yet? You were supposed to die", 0, 0, 0, 13)
	elseif thingSaying == 1 then
		setControlHint("I want to have Eric here in form 1 shooting massive amounts of missiles.", 0, 0, 0, 10)
	elseif thingSaying == 2 then
		setControlHint("This map would load back to final boss with one last conversation with Mia. Mia finishes Elena off herself.", 0, 0, 0, 10)
	elseif thingSaying == 3 then
		setControlHint("You are going to load to a WIP final cutscene. This would be Mia talking to Naija at VedhaCave before leaving her.", 0, 0, 0, 12)
	elseif thingSaying == 4 then
		warpNaijaToSceneNode("sunkencity02", "naijaout")
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end

