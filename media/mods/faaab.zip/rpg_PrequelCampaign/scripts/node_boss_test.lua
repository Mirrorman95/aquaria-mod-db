--[[
ENCOUNTER CODE: by Danny O'Connell (vxnervegas [at] gmail [dot] com)
Mia shows up with some minions and causes the PC a bit of trouble.
Mia calls the PC out after the PC has killed all spawned enemies.
]]--


dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()

	--loadSound("mia-appear")
	--spawn1 = getNode("SPAWN1_EVIL")

	node_setCursorActivation(me, true)
end


function update(me, dt)
end

function activate(me)
	createEntity("rpg_boss_mia-mirror", "", node_x(me), node_y(me))
	--spawnParticleEffect("mia-electricity", node_x(me), node_y(me))
	--spawnParticleEffect("mia-suck", node_x(me), node_y(me))
end