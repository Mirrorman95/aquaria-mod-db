dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/healthupgradetemplate.lua"))

function init(me)
	commonInit(me, 3)
end