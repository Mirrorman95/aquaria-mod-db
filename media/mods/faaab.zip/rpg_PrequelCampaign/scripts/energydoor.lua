-- energy door
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/doorcommon.lua"))

function init(me)
	commonInit(me, "EnergyDoor", "EnergyDoor", 1.5, 0)
end

function update(me, dt)
	commonUpdate(me, dt)
end
