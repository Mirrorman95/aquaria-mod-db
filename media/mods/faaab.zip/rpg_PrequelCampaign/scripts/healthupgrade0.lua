--dofile("scripts/include/healthupgradetemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/healthupgradetemplate.lua"))

function init(me)
	commonInit(me, 0)
end