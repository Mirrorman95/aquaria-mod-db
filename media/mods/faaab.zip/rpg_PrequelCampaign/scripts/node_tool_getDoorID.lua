dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
holderID = 0
doorID = 0

function init(me)
	--n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))	
end


function update(me, dt)
	holder = node_getNearestEntity(me, "orbholder")
	door = node_getNearestEntity(me, "energydoor")

	holderID = entity_getID(holder)
	doorID = entity_getID(door)
end

function activate(me)
	setControlHint("HolderID = " .. holderID .. " | DoorID = " .. doorID,  0, 0, 0, 10, "")
	
	--centerText(holderID)
	--centerText(doorID)
end