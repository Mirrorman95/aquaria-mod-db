dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleUpsideDownSeed", FLAG_COLLECTIBLE_UPSIDEDOWNSEED)
end

function update(me, dt)
end
