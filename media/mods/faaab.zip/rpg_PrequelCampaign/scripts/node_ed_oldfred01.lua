dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 85
holderID = 5
flag = ED_OLDFRED_01

dofile("scripts/include/energyslottemplate.lua")