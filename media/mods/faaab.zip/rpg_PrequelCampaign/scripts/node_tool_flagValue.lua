dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

function init(me)
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function activate(me)
	setControlHint("KILLED_ROTCORE = " .. getFlag(KILLED_ROTCORE),  0, 0, 0, 5, "")
end