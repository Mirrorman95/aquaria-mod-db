dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, false)	
end


function activate(me)
	playSfx("click")

	setFlag(FOOD_CHANGE_MODE, 1)
	node_setCursorActivation(me, false)
end