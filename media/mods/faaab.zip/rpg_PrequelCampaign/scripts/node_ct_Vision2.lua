dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
displayed = false

function init(me)
	n = getNaija()
end

function update(me, dt)
	if displayed == false and node_isEntityIn(me, n) then
		displayed = true
		centerText("Crash Landing")
	end
end