dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/jukebox15b/scripts/jukeboxinclude.lua"))

--[[
Button layout on screen:

        *RAND*
  PREV          NEXT 
  
                     EXIT
--]]
local isContinuous = 0
local myGlyph = nil
local contTimer = 0
local navmap = {
    [ACTION_MENULEFT] = "jukebox-previous",
    [ACTION_MENURIGHT] = "jukebox-next",
    [ACTION_MENUDOWN] = "jukebox-quit"
}

function init(me)
    jukebox_initButton(me)
	myGlyph = createQuad("jukebox-cont-off", 6)
	quad_alpha(myGlyph, 1)
	quad_setPosition(myGlyph, node_getPosition(me))
end

function action(me, action, state)
	if isNestedMain() then return end
    return jukebox_doButtonAction(me, action, state, navmap, true)
end

function activate(me)
	if isNestedMain() then return end
	
	--playSfx("TitleAction")
	spawnParticleEffect("TitleEffect1", node_x(me), node_y(me))
	watch(0.5)
	
	isContinuous = (isContinuous + 1) % 3
	if isContinuous == 0 then
		--display "off" glyph
		quad_delete(myGlyph)
		myGlyph = createQuad("jukebox-cont-off", 6)
		quad_alpha(myGlyph, 1)
		quad_setPosition(myGlyph, node_getPosition(me))
	elseif isContinuous == 1 then
		--display "on straight" glyph
		quad_delete(myGlyph)
		myGlyph = createQuad("jukebox-cont-on", 6)
		quad_alpha(myGlyph, 1)
		quad_setPosition(myGlyph, node_getPosition(me))
	elseif isContinuous == 2 then
		--display "on random" glyph
		quad_delete(myGlyph)
		myGlyph = createQuad("jukebox-cont-on2", 6)
		quad_alpha(myGlyph, 1)
		quad_setPosition(myGlyph, node_getPosition(me))
	end
end

function update(me, dt)
	
	-- Returns the time that the current song has been playing for, adjusted by dt.
	contTimer = jukebox_incrementSongTimer(dt)
	
	--setControlHint(contTimer.."/"..jukebox_getSongLength())
	
	if contTimer > jukebox_getSongLength() then
		if isContinuous == 1 then -- continuous straight
			local n = jukebox_getSong()
			if n < #SONG_LIST then n = n + 1 else n = 1 end
			jukebox_playSong(n)
		elseif isContinuous == 2 then -- continuous random
			local n = jukebox_getSong()
			local count = #SONG_LIST
			if count > 1 then
				local n2 = math.random(count-1)
				if n2 >= n then n2 = n2 + 1 end
				n = n2
			end
			jukebox_playSong(n)
		end
	end
end
