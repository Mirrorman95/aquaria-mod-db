-- song cave collectible

--dofile("scripts/include/collectibletemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/collectibletemplate.lua"))

function init(me)
	commonInit(me, "Collectibles/blackpearl", FLAG_COLLECTIBLE_BLACKPEARL)
end

function update(me, dt)
	commonUpdate(me, dt)
end

function enterState(me, state)
	commonEnterState(me, state)
	--[[
	if entity_isState(me, STATE_COLLECTEDINHOUSE) then
		ent = createEntity("Clam", "", entity_x(me)+200, entity_y(me)-150)
		entity_rotate(ent, entity_getRotation(ent)-18)
	end
	]]--
end

function exitState(me, state)
	commonExitState(me, state)
end
