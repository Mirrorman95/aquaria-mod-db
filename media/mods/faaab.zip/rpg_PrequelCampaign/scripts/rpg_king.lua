dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_initSkeletal(me, "rpg_king")
	
	entity_setState(me, STATE_IDLE)
	entity_scale(me, 0.7, 0.7)
	entity_flipHorizontal(me)
end

function update(me, dt)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end