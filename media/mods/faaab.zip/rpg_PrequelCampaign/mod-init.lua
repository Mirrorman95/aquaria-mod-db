function init()
	loadMap("vanilla_vedhacave")
	--loadMap("rpg_nightmare02")
end