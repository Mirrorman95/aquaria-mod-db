--puts on Elena costume if player takes off a regular costume (would show default Naija otherwise)

function init(me)
end

function update(me, dt)
	--ELENA COSTUME
	if getCostume() == "" then
		setCostume("elena")
	end
end