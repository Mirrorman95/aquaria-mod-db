dofile("scripts/entities/entityinclude.lua")

function init(me)
	entity_alpha(me, 0)
	esetv(me, EV_LOOKAT, 0)
	entity_setCanLeaveWater(me, true)
end

function update(me, dt)
	entity_updateMovement(me, dt)
end
