dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_cutman.lua"))
dofile("scripts/entities/entityinclude.lua")

flag = TIMER_COMBAT01
cleaningUp = false
ENTITY_HOTEL = {"nudibranch0", "nudibranch1", "nudibranch2", "nudibranch3", "upsidedownjelly", "mosshead"}


function init(me)
	commonInit(me, flag)
	--node_setCursorActivation(me, true)
end

function update(me, dt)		
	--if not looking for entity in first IF this updates before entities created: I'm confused
	if not cleaningUp then
		enemyLeft = false 
		
		testEnt = getFirstEntity()
		while testEnt ~= 0 do
			if entity_getEntityType(testEnt) == ET_ENEMY and not BadEnemy(testEnt) then
				--centerText(entity_getName(testEnt))
				enemyLeft = true
				break
			end
			testEnt = getNextEntity()
		end		
		
		--WINNER?
		if not enemyLeft then
			cleaningUp = true
			setFlag(ARENA_COMPLETE, 1)
		end
	end
	
	commonUpdate(me, dt)
end

--[[
function activate(me)	
	testEnt = getFirstEntity()
	while testEnt ~= 0 do
		if entity_getEntityType(testEnt) == ET_ENEMY and not BadEnemy(testEnt) then
			entity_delete(testEnt)			
		end
		testEnt = getNextEntity()
	end
end
]]--

--BAD ENEMY: enemy that is listed as ET_ENEMY but can't be killed by avatar
function BadEnemy(testEnt)
	for i=1, #ENTITY_HOTEL do
		if entity_getName(testEnt) == ENTITY_HOTEL[i] then
			return true
		end
	end
end