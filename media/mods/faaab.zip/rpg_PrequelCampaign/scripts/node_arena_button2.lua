dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_ArenaButton.lua"))

Tab1_Title = "Depths of the Abyss"
Tab1_Map = "rpg_combat02"

Tab2_Title = "Gear"
Tab2_Map = "rpg_navigation02"

Tab3_Title = "Hellbeast"
Tab3_Map = "arena_cathedral04"


function init(me)
	CommonInit(me)
end

function update(me, dt)
	--TIMERS: place (setup in node_arenaMaster.lua)
	--NO MAP: turn off cursor activation if there is no map on the current page
	if getFlag(ARENA_PLACE_TIMERS) > 0 then
		setFlag(ARENA_PLACE_TIMERS, getFlag(ARENA_PLACE_TIMERS) - 1)
		deleteTimerGFX()

		if isFlag(MENU_TAB, 1) then
			node_setCursorActivation(me, false)
			--placeTimerGFX(getFlag(TIMER_COMBAT02), node_x(me) + 220, node_y(me) + 60)
		elseif isFlag(MENU_TAB, 2) then
			node_setCursorActivation(me, false)
			--placeTimerGFX(getFlag(TIMER_NAVIGATION02), node_x(me) + 220, node_y(me) + 60)
		elseif isFlag(MENU_TAB, 3) then
			node_setCursorActivation(me, true)
			placeTimerGFX(getFlag(TIMER_BOSS_CATHEDRAL04), node_x(me) + 220, node_y(me) + 60)
		end
	--TIMERS: delete
	elseif getFlag(ARENA_DELETE_TIMERS) > 0 then
		setFlag(ARENA_DELETE_TIMERS, getFlag(ARENA_DELETE_TIMERS) - 1)
		node_setCursorActivation(me, false)
		deleteTimerGFX()
	end
end

function activate(me)
	--TAB 1
	if isFlag(MENU_TAB, 1) then
		play = confirm("Are you sure you're ready for \nbullet hell: " .. Tab1_Title .. "?", "buy")
		if play then
			menuCleanup()
			warpNaijaToSceneNode(Tab1_Map, "start", "r")
		end
	--TAB 2
	elseif isFlag(MENU_TAB, 2) then
			play = confirm("Are you sure you want to \nnavigate: " .. Tab2_Title .. "?", "buy")
		if play then
			menuCleanup()
			warpNaijaToSceneNode(Tab2_Map, "start", "r")
		end
	--TAB 3
	elseif isFlag(MENU_TAB, 3) then
		play = confirm("Are you sure you want to \nfight: " .. Tab3_Title .. "?", "buy")
		if play then
			menuCleanup()
			warpNaijaToSceneNode(Tab3_Map, "start", "r")
		end
	end
end