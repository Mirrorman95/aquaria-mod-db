dofile("scripts/entities/entityinclude.lua")

n = 0

function init(me)
	setupEntity(me)
 
	if (getForm() == 0) then
		entity_initSkeletal(me, "Naija", getCostume())
	elseif (getForm() == 1) then
		entity_initSkeletal(me, "Naija", "energyform")
	elseif (getForm() == 2) then
		entity_initSkeletal(me, "Naija", "beastform")
	elseif (getForm() == 3) then
		entity_initSkeletal(me, "Naija", "natureform")
	elseif (getForm() == 7) then
		entity_initSkeletal(me, "Naija", "sunform")
	else
		entity_initSkeletal(me, "Naija", "mithalan")

--Fish form is separate entity...could spawn new(fishform) entity
	--elseif (getForm() == 6) then
		--entity_initSkeletal(me, "Naija", "fishform")
	end

	entity_setEntityType(me, ET_NEUTRAL)	
	entity_scale(me, 1.7, 1.7)

	bone_alpha(entity_getBoneByName(me, "Fish2"), 0)
	bone_alpha(entity_getBoneByName(me, "DualFormGlow"), 0)

	entity_flipHorizontal(me)
	entity_setState(me, STATE_IDLE)
end

function update(me, dt)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end