-- song cave collectible

--dofile("scripts/include/collectibletemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/collectibletemplate.lua"))

function init(me)
	commonInit(me, "Collectibles/stonehead", FLAG_COLLECTIBLE_STONEHEAD)
	entity_setEntityLayer(me, -2)
end

function update(me, dt)
	commonUpdate(me, dt)
end

function enterState(me, state)
	commonEnterState(me, state)
	--[[
	if entity_isState(me, STATE_COLLECTEDINHOUSE) then
		createEntity("Scooter", "", entity_x(me), entity_y(me))
	end
	]]--
end

function exitState(me, state)
	commonExitState(me, state)
end
