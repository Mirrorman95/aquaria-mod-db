Aquaria Jukebox v1.5b1
---------------------

Last Updated: May 17th, 2009

Author: Dolphin's Cry

Additional Work: Derek Yu
		 Edwards

Change Log
----------

v1.5 (2009-05-17)
- Added continuous play option. (Added by Edwards)

v1.4 (2007-12-15)
- Added fully working gamepad navigation.
- Made Naija sit on the throne.
- Added seal on throne.
- Added some sparkle to make the scene less static.
- Initial song is now chosen randomly.

v1.3 (2007-12-14)
- New graphics and some polishing by Derek. Woohoo!

v1.1 (2007-12-14)
- Cleaned up left-overs from title-test.
- Added "Random" button.

v1.0 (2007-12-14)
- First rough version based on title-test by Alec.


Thanks go to...
---------------

Dolphin's Cry would like to thank (in no particular order):
- Alec and Derek for making Aquaria and being so supportive of modding. You guys are great!
- Sfiera for setting up a wiki.
- Burton Radons for adding a whole lot of content to the wiki.
- Everyone who gave feedback on this mod.
