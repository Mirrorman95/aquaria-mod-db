dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
camDummy = 0


function init(me)

--BEGINNING OF GAME
	if isFlag(MITHALAS_CORRUPTED, 0) then
		--setCutscene(1,1)

		n = getNaija()
		entity_setPosition(n, 0, 0)

		camDummy = createEntity("Empty")
		setItUp = getNode("setItUp")
		start = getNode("start")
		finish = getNode("finish")

		overrideZoom(0.8)
		entity_warpToNode(camDummy, setItUp)
		cam_toEntity(camDummy)

		watch(1)
		fade(0, 4)
		watch(4)

		setControlHint("Naija, come to the light. Do not let the darkness fill your empty mind with such evil thoughts. I apologize for what I have made you endure... and for what still awaits you.", 0, 0, 0, -1)
		watch(8)

		setControlHint("If it would not affect your decisions, I would graciously give you back the memory of the sacrifices made for you. I feel obligated to tell you, if only for my own sake, all that has occurred.", 0, 0, 0, 12)
		watch(8)	

		fade(1, 4)
		watch(5)

		entity_warpToNode(camDummy, start)
		watch(1)
		fade(0, 4)
	
		--entity_moveToNode(camDummy, finish, SPEED_SLOW)
		entity_setPosition(camDummy, node_x(finish), node_y(finish), 18)
		watch(3)

		setControlHint("My child, many have given of their lives so that you and I may fulfill our purpose. The Mithalans have made the greatest sacrifice for you.", 0, 0, 0, -1)
	watch(6)

		setControlHint("It is a story that you have forgotten, but a story that should long be remembered for the harrowing deeds it records.", 0, 0, 0, -1)
		watch(5)

		fade(1, 4)
		watch(3.5)

		loadMap("rpg_intro01")
		--loadMap("rpg_cathedralhome")
--ENG OF GAME
	else
		playMusic("SunkenCity")

		n = getNaija()
		entity_setPosition(n, 0, 0)

		camDummy = createEntity("Empty")
		setItUp = getNode("setItUp")
		start = getNode("start")
		finish = getNode("finish")

		overrideZoom(0.8)
		entity_warpToNode(camDummy, setItUp)
		cam_toEntity(camDummy)

		watch(1)
		fade(0, 4)
		watch(4)

		setControlHint("Mithalas has suffered the most of all the races I have killed with Eric. I cannot explain my burden, nor would I wish to share it with you. It is a concept that even I have difficulty fully understanding.", 0, 0, 0, 12)
		watch(12)

		fade(1, 4)
		watch(3.5)

		loadMap("vanilla_cathedral04")

		--setCutscene(0)
	end
end