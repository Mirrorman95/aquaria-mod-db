dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 83
holderID = 59
flag = ED_ENERGYTEMPLE01_MINIBOSS

dofile("scripts/include/energyslottemplate.lua")