dofile("scripts/entities/entityinclude.lua")

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5
function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("Walker: I have walked Aquaria for many years...ten I think it's been. ", 0, 0, 0, 16)
	elseif thingSaying == 1 then
		setControlHint("Walker: The lands above the surface are as well. I think I may return soon.", 0, 0, 0, 16)
	elseif thingSaying == 2 then
		setControlHint("Walker: I am not God nor am I one of many. I am but an explorer looking to find every creature, tree, and soup before passing on.", 0, 0, 0, 16)
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end

