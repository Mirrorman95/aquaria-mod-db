function init(me)
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end


function activate(me)
   	learnSong(1)
	--learnSong(2)
	learnSong(3)
	learnSong(4)
	learnSong(5)
	learnSong(6)
	learnSong(7)
	--learnSong(8)
	learnSong(9)
	learnSong(10)
	learnSong(11)
	learnSong(12)

	setControlHint("You have learned all songs.",  0, 0, 0, 6)

	--beast = getForm()
	--setControlHint(beast,  0, 0, 0, 6)
	
end