dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if isFlag(QUEST_DRASK1, 0) and node_isEntityIn(me, n) then
		--playSfx("shield-hit")
		spawnParticleEffect("barrier-hit", entity_x(n), entity_y(n))		

		w, h = node_getSize(me)
		entity_clearVel(n)
		if w > h then
			y = entity_y(n) - node_y(me)
			if entity_y(n) < node_y(me) then
				entity_setPosition(n, entity_x(n), node_y(me) - (h/2) - 10)
			else
				entity_setPosition(n, entity_x(n), node_y(me) + (h+10)/2 + 10)
			end
		else
			x = entity_x(n) - node_x(me)
		end
		
		
		x, y = vector_setLength(x, y, 10000)
		entity_setMaxSpeedLerp(n, 4)
		entity_setMaxSpeedLerp(n, 1, 4)
		entity_addVel(n, x, y)

		setControlHint("You must speak to Prince Drask before leaving the city.",  0, 0, 0, 5, "drask/head")
	end
end
