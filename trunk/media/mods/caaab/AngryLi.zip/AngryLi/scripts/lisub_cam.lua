dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/AngryLi/scripts/include.lua"))

n = 0

curSeg = 0
pathNode = 0
followingPath = false
tx = 0
ty = 0
lastDist = 0
init = true

STATE_WAITFORCLEANUP = 1000
cleanupnode = 0
isInNode = false
isInExitNode = false
isInSpeedNode = false
isInCheckPointNode = false
isFollowing = false

speedNormal = 250
speedSlower = 150
speedFaster = 400
speed = speedNormal
 
function init(me)
 
	setupEntity(me)
 
	-- set entity graphic
	entity_setTexture(me,"missingImage")
	entity_alpha(me, 0)
	
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setHealth(me, 1)
	
	entity_setState(me, STATE_IDLE)
	setSpeed(me, speedNormal)
end

function setSpeed(me, s)

	entity_setMaxSpeed(me, s)
	speed = s
end
 
function postInit(me)

	-- cam_toEntity(me)
	lisub = getEntity("lisub")
	-- entity_setPosition(me, entity_getPosition(lisub))
	
	-- set position to the last check point reached
	if isFlag(FLAG_INTRO,1) then
		entity_setPosition(me, getFlag(CHECKPOINT_X), getFlag(CHECKPOINT_Y))
	end
	
	-- find the nearest path segment

end

function setTargetPoint(me, seg)

	curSeg = seg
	tx, ty = node_getPathPosition(pathNode, seg)
end
 
function update(me, dt)

	if entity_isState(me, STATE_FOLLOW) then
		
		---------------------
		-- NODES DETECTION --
		---------------------
		
		cleanupnode = entity_getNearestNode(me, "waitforcleanup")
		if cleanupnode ~= 0 then
			if not isInNode and node_isEntityIn(cleanupnode, me) then
				isInNode = true
				entity_setState(me, STATE_WAITFORCLEANUP)
			elseif isInNode and not node_isEntityIn(cleanupnode, me) then
				isInNode = false
			end
		end
		
		-- checkpoint
		node = entity_getNearestNode(me, "checkpoint")
		if node ~= 0 then
			if not isInCheckPointNode and node_isEntityIn(node, me) then
				isInCheckPointNode = true
				-- setControlHint("checkpoint !", 0, 0, 0, 1)
				setFlag(FLAG_INTRO, 1) -- won't replay intro
				setFlag(CHECKPOINT_X, node_x(node))
				setFlag(CHECKPOINT_Y, node_y(node))
			elseif isInCheckPointNode and not node_isEntityIn(node, me) then
				isInCheckPointNode = false
			end
		end

		-- speedslower node
		node = entity_getNearestNode(me, "slower")
		if node ~= 0 then
			if not isInSpeedNode and node_isEntityIn(node, me) then
				isInSpeedNode = true
				setSpeed(me, speedSlower)
			elseif isInSpeedNode and not node_isEntityIn(node, me) then
				isInSpeedNode = false
				setSpeed(me, speedNormal)
			end
		end
		
		-- speedfaster node
		node = entity_getNearestNode(me, "faster")
		if node ~= 0 then
			if not isInSpeedNode and node_isEntityIn(node, me) then
				isInSpeedNode = true
				setSpeed(me, speedFaster)
			elseif isInSpeedNode and not node_isEntityIn(node, me) then
				isInSpeedNode = false
				setSpeed(me, speedNormal)
			end
		end
		
		-- speedfaster node
		node = entity_getNearestNode(me, "end")
		if node ~= 0 then
			if not isInExitNode and node_isEntityIn(node, me) then
				setControlHint("IN", 0, 0, 0, 1)
				isInExitNode = true
				setSpeed(me, 0)
				pause()
				setControlHint("You have reached the end of the mod, that's all for now", 0, 0, 0, 3)
				watch(3)
				health = entity_getHealth(lisub)
				if health == 25 then
					rating = "perfect !!!"
				elseif health >= 20 then
					rating = "great !"
				elseif health >= 15 then
					rating = "cool !"
				elseif health >= 10 then
					rating = "not bad"
				elseif health >= 5 then
					rating = "you can do better..."
				else
					rating = "bad ..."
				end
				setControlHint("You have : " .. health .. " structure points left, " .. rating, 0, 0, 0, 4)
				watch(4)
				fade(1, 3, 0, 0, 0)
				setControlHint("Thanks for playing !", 0, 0, 0, 3)
				watch(3)
				-- fade(0)
				goToTitle()
			elseif isInExitNode and not node_isEntityIn(node, me) then
				isInExitNode = false
			end
		end
		
		entity_moveTowards(me, tx, ty, dt, speed)
		
		x, y = entity_getPosition(me)
		dist = vector_getLength(tx - x, ty - y)
		
		-- distance from the point has increased, meaning we have reached it
		if dist > lastDist or entity_isPositionInRange(me, tx, ty, 10) then
	
			setTargetPoint(me, curSeg + 1)
			lastDist = 999999
			
			-- last segment is reached
			if tx == 0 then
				isFollowing = false -- we stopped following path
				entity_setState(me, STATE_FOLLOW)
			end
		
		elseif dist < lastDist then
			lastDist = dist
		end
		
	elseif entity_isState(me, STATE_WAITFORCLEANUP) then
	
		ent = entity_getNearestEntity(me, "", 600, ET_ENEMY, 0)
		
		if ent == 0 then
			-- setControlHint("cleanup !", 0, 0, 0, 1)
			entity_setState(me, STATE_FOLLOW)
		end
		
		--[[
		ent = getFirstEntity()
		while ent~=0 do
			if entity_getEntityType(me) == ET_ENEMY then
			
			end
			ent = getNextEntity()
		end
		]]
	end

	entity_updateMovement(me, dt)
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end
 
function dieNormal(me)
end
 
function enterState(me)

	if entity_isState(me, STATE_FOLLOW) then
	
		-- change node
		if not isFollowing then
			pathNode = entity_getNearestNode(me, "campath")
			lastDist = 9999999
			isFollowing = true
			
			if init then
				entity_setPosition(me, node_getPathPosition(pathNode, 0))
				setTargetPoint(me, 1)
				init = false
			else
				setTargetPoint(me, 0)
			end		
		end

	elseif entity_isState(me, STATE_WAITFORCLEANUP) then
	
		entity_clearVel(me)
	end
	
end
 
function exitState(me)
end
 
function hitSurface(me)
end
 
function songNote(me, note)
end
 
function songNoteDone(me, note)
end
 
function song(me, song)
end
 
function activate(me)
end