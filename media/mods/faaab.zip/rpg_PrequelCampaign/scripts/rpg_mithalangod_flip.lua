dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_initSkeletal(me, "HellBeast")
	entity_setCull(me, false)	
	entity_scale(me, 1.5, 1.5)
	
	grabPoint = entity_getBoneByName(me, "GrabPoint")
	bone_alpha(grabPoint, 0)
	
	entity_flipHorizontal(me)
	entity_setState(me, STATE_IDLE)
	loadSound("HellBeast-Roar")
end

function update(me, dt)
--[[
	if entity_isState(me, STATE_WALKING) then
		entity_setPosition(me, entity_x(me) + 300 * dt, entity_y(me))
	end
]]--
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	elseif entity_isState(me, STATE_WALKING) then
		entity_animate(me, "move", -1)
	end
end
