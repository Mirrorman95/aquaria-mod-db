dofile("scripts/entities/entityinclude.lua")

n = 0

function init(me)
	setupEntity(me)
 
	entity_initSkeletal(me, "Naija", "teen")

	entity_setEntityType(me, ET_NEUTRAL)	
	entity_scale(me, 0.5, 0.5)

	bone_alpha(entity_getBoneByName(me, "Fish2"), 0)
	bone_alpha(entity_getBoneByName(me, "DualFormGlow"), 0)

	entity_flipHorizontal(me)
	entity_setState(me, STATE_IDLE)

	entity_setInvincible(me, true)
end

function update(me, dt)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end