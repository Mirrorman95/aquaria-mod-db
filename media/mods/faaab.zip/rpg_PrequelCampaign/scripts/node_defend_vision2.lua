dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
energyDoor = 0
sunkenDoor = 0

spawn1 = 0
spawn2 = 0
spawn3 = 0
spawn4 = 0
abaddon1 = 0
abaddon2 = 0
createdBigBlaster = false

waveNumber = 1
waveSetup = false
group1Spawned = false
group2Spawned = false
delayWave = 10
delaySpawn1 = 2
delaySpawn2 = 4

--delaySpawn3 = 10

function init(me)
	n = getNaija()

	spawn1 = getNode("SPAWN1")
	spawn2 = getNode("SPAWN2")
	spawn3 = getNode("SPAWN3")
	spawn4 = getNode("SPAWN4")

	abaddon1 = getNode("ABADDON1")
	abaddon2 = getNode("ABADDON2")

	energyDoor = node_getNearestEntity(me, "energydoor")
	entity_setState(energyDoor, STATE_OPENED)

	sunkenDoor = node_getNearestEntity(me, "sunkendoor")	
	
	loadSound("mia-appear")
	loadSound("mia-scream")
	loadSound("mia-sillygirl")

--RESET MISSION
	if getFlag(VISION_2) ~= 0 then
		setFlag(VISION_2, 0)
	end

	--node_setCursorActivation(me, true)
end


function update(me, dt)

	--SCARY!
	if isFlag(VISION_2, 1) then
		setFlag(VISION_2, 2)

		shakeCamera(10, 2)
		voice("laugh2")

		watch(2)

		entity_setState(energyDoor, STATE_CLOSE)
		playMusic("bigboss")
	--START WAVES
	elseif isFlag(VISION_2, 3) then
		--DELAY START OF WAVE
		if delayWave > 0 then
			if delayWave < 5 and waveSetup == false then
				waveSetup = true
				centerText("Incoming! Wave " .. waveNumber .. "/5")
			end		

			delayWave = delayWave - dt
		else
			--WAVE 1
			if waveNumber == 1 then
				if group1Spawned == true and group2Spawned == true then
					group1Spawned = false
					group2Spawned = false
					delaySpawn1 = math.random(1,3)
					delaySpawn2 = math.random(4,6)	

					waveNumber = waveNumber + 1
					delayWave = 15
					waveSetup = false			
				else
					if delaySpawn1 > 0 then
						delaySpawn1 = delaySpawn1 - dt
					elseif group1Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
						spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))

						createEntity("mutantnaija", "", node_x(spawn2), node_y(spawn2))		
						createEntity("mutileye", "", node_x(spawn2), node_y(spawn2))
						createEntity("mutileye", "", node_x(spawn3), node_y(spawn3))

						group1Spawned = true
					end

					if delaySpawn2 > 0 then
						delaySpawn2 = delaySpawn2 - dt
					elseif group2Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
						spawnParticleEffect("MiaWarp", node_x(spawn4), node_y(spawn4))

						createEntity("rednautilus", "", node_x(spawn1), node_y(spawn1))		
						createEntity("rednautilus", "", node_x(spawn1), node_y(spawn1))
						createEntity("rednautilus", "", node_x(spawn4), node_y(spawn4))
						createEntity("mutileye", "", node_x(spawn4), node_y(spawn4))

						group2Spawned = true
					end
				end
			--WAVE 2
			elseif waveNumber == 2 then
				if group1Spawned == true and group2Spawned == true then
					group1Spawned = false
					group2Spawned = false
					delaySpawn1 = math.random(1,3)
					delaySpawn2 = math.random(4,6)	

					waveNumber = waveNumber + 1
					delayWave = 20
					waveSetup = false		
				else
					if delaySpawn1 > 0 then
						delaySpawn1 = delaySpawn1 - dt
					elseif group1Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
						spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))

						createEntity("deepeel", "", node_x(spawn2), node_y(spawn2))
						createEntity("blaster", "", node_x(spawn3), node_y(spawn3))
						createEntity("mutilus", "", node_x(spawn2), node_y(spawn2))
						createEntity("rednautilus", "", node_x(spawn2), node_y(spawn2))

						group1Spawned = true
					end

					if delaySpawn2 > 0 then
						delaySpawn2 = delaySpawn2 - dt
					elseif group2Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(abaddon1), node_y(abaddon1))
						spawnParticleEffect("MiaWarp", node_x(abaddon2), node_y(abaddon2))

						createEntity("abaddon", "", node_x(abaddon1), node_y(abaddon1))
						createEntity("abaddon", "", node_x(abaddon2), node_y(abaddon2))

						group2Spawned = true
					end	
				end
			--WAVE 3
			elseif waveNumber == 3 then
				if group1Spawned == true and group2Spawned == true then
					group1Spawned = false
					group2Spawned = false
					delaySpawn1 = math.random(1,3)
					delaySpawn2 = math.random(4,6)	

					waveNumber = waveNumber + 1
					delayWave = 20
					waveSetup = false		
				else
					if delaySpawn1 > 0 then
						delaySpawn1 = delaySpawn1 - dt
					elseif group1Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
						spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))

						createEntity("rednautilus", "", node_x(spawn1), node_y(spawn1))
						createEntity("rednautilus", "", node_x(spawn1), node_y(spawn1))
						createEntity("blaster", "", node_x(spawn3), node_y(spawn3))
						createEntity("blaster", "", node_x(spawn3), node_y(spawn3))

						group1Spawned = true
					end

					if delaySpawn2 > 0 then
						delaySpawn2 = delaySpawn2 - dt
					elseif group2Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn1), node_y(spawn1))
						spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
						spawnParticleEffect("MiaWarp", node_x(spawn4), node_y(spawn4))

						createEntity("abyssoctopus", "", node_x(spawn1), node_y(spawn1))
						createEntity("mutilus", "", node_x(spawn2), node_y(spawn2))
						createEntity("blaster", "", node_x(spawn4), node_y(spawn4))
						createEntity("blaster", "", node_x(spawn4), node_y(spawn4))

						group2Spawned = true
					end	
				end
			--WAVE 4
			elseif waveNumber == 4 then
				if group1Spawned == true and group2Spawned == true then
					group1Spawned = false
					group2Spawned = false
					delaySpawn1 = math.random(1,3)
					delaySpawn2 = math.random(4,6)	

					waveNumber = waveNumber + 1
					delayWave = 25
					waveSetup = false		
				else
					if delaySpawn1 > 0 then
						delaySpawn1 = delaySpawn1 - dt
					elseif group1Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn4), node_y(spawn4))

						createEntity("deepeel", "", node_x(spawn4), node_y(spawn4))
						createEntity("anglerfish", "", node_x(spawn4), node_y(spawn4))

						group1Spawned = true
					end

					if delaySpawn2 > 0 then
						delaySpawn2 = delaySpawn2 - dt
					elseif group2Spawned == false then
						playSfx("mia-appear")
						spawnParticleEffect("MiaWarp", node_x(spawn3), node_y(spawn3))
						spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))

						createEntity("mutantnaija", "", node_x(spawn3), node_y(spawn3))
						createEntity("blaster", "", node_x(spawn2), node_y(spawn2))

						group2Spawned = true
					end		
				end
			--WAVE 5
			elseif waveNumber == 5 then				
				--BIG BLASTER
				if createdBigBlaster == false then
					createdBigBlaster = true

					playSfx("mia-appear")
					spawnParticleEffect("MiaWarp", node_x(spawn2), node_y(spawn2))
					createEntity("bigblaster", "", node_x(spawn2), node_y(spawn2))
				--BIG BLASTER DEAD?
				--elseif node_getNearestEntity(me, "bigblaster") == 0 then
					--CHANGE PHASE
					--setFlag(VISION_2, 4)
				end
			end
		end
	--WRAPUP: this is set by death of bigblaster
	elseif isFlag(VISION_2, 4) then
		setFlag(VISION_2, 5)
		entity_setState(sunkenDoor, STATE_OPEN)
		entity_setState(energyDoor, STATE_OPEN)
		updateMusic()

		entity_setInvincible(n, true)
		entity_idle(n)
		entity_clearVel(n)

		createEntity("crystal_small", "", entity_x(n), entity_y(n))
		createEntity("crystal_small", "", entity_x(n), entity_y(n))

		watch(3)

		setControlHint("Thank you. Hopefully my next journey here proves more fruitful. I must return to my son Li.",  0, 0, 0, 8, "li/helmet")		

		watch(8)		

		--RESET MAP
		setFlag(VISION_2, 0)

		--LOAD OUT
		if isFlag(MITHALAS_CORRUPTED, 0) then
			loadMap("rpg_cathedral01", "vendor", "l")
		else
			loadMap("rpg_cathedral01_c", "vendor", "l")
		end
	end
end

--[[
function activate(me)
	setFlag(VISION_2, 0)
	setControlHint("Event reset/started.",  0, 0, 0, 5, "")
end
]]--