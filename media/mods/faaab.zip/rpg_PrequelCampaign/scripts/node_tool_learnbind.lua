
n= 0
islearned=false


function init(me)
	n = getNaija()
	createEntity("hintBubble", "", node_x(me), node_y(me))   
end


function update(me, dt)

 if islearned==false then

  if node_isEntityIn(me, n) then
    setControlHint("You've found a new song! You can now use BIND song!", 0, 0, 0, 16)
    learnSong(4)
    islearned=True
  end
 end

end