dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleTridentHead", FLAG_COLLECTIBLE_TRIDENTHEAD)
end

function update(me, dt)
end
