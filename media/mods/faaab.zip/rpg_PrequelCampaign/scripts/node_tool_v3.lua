dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, true)
	next = createEntity("panel_next", "", node_x(me), node_y(me))
	entity_alpha(next, 1, 1.5)
end

function activate(me)
	centerText("Version 3")
	
	setFlag(MITHALAS_CORRUPTED, 1)

	setFlag(DT_VERSION_DRASK, 3)
	setFlag(DT_VERSION_WALKER, 3)
	setFlag(DT_VERSION_MIA, 3)
	setFlag(DT_VERSION_NAIJA, 3)
	setFlag(DT_VERSION_OLDFRED, 3)

	setFlag(DT_VERSION_RAJAH, 3)
	setFlag(DEATH_OF_DRASK, 0)
end