dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
tempVar = 0
DRUNIAD_HOTEL = {}

function init(me)
	n = getNaija()

	--creates Druniad entities
	if isFlag(CS_DRUNIADS, 0) or isFlag(CS_DRUNIADS, 1) then
		
		spawn1 = getNode("SPAWN1")
		spawn2 = getNode("SPAWN2")
		spawn3 = getNode("SPAWN3")
		spawn4 = getNode("SPAWN4")

		tempVar = createEntity("druniad", "", node_x(spawn1), node_y(spawn1))
		table.insert(DRUNIAD_HOTEL, tempVar)

		tempVar = createEntity("druniad", "", node_x(spawn2), node_y(spawn2))
		table.insert(DRUNIAD_HOTEL, tempVar)

		tempVar = createEntity("druniad", "", node_x(spawn3), node_y(spawn3))
		table.insert(DRUNIAD_HOTEL, tempVar)

		tempVar = createEntity("druniad", "", node_x(spawn4), node_y(spawn4))
		table.insert(DRUNIAD_HOTEL, tempVar)
	end

	--node_setCursorActivation(me, true)
end


function update(me, dt)
	if isFlag(CS_DRUNIADS, 1) and node_isEntityIn(me, n) then
		setFlag(CS_DRUNIADS, 2)
		
		playMusic("sunwormcave")
		--playMusic("inevitable")

		entity_setInvincible(n, true)
		entity_idle(n)
		entity_clearVel(n)
		
		start = getNode("camStart")
		finish = getNode("camFinish")

		camDummy = createEntity("Empty")
		entity_warpToNode(camDummy, start)
		cam_toEntity(camDummy)
		overrideZoom(0.4)
		entity_setPosition(camDummy, node_x(finish), node_y(finish), 10)

		shakeCamera(10, 10)
		voice("laugh2")

		watch(2)

		for i=1, #DRUNIAD_HOTEL do
			entity_setState(DRUNIAD_HOTEL[i], STATE_DONE)
			DRUNIAD_HOTEL[i] = nil
			watch(2)
		end

		playSfx("naijagasp")

		entity_setInvincible(n, false)
		cam_toEntity(n)
		overrideZoom(0)

		--updateMusic()
	end
end

--[[
function activate(me)
	setFlag(CS_DRUNIADS, 1)
	setControlHint("FLAG (CS_DRUNIADS) = " .. getFlag(CS_DRUNIADS),  0, 0, 0, 5, "")
end
]]--