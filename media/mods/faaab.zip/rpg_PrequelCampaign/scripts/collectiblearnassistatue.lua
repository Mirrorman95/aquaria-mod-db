-- song cave collectible

--dofile("scripts/include/collectibletemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/collectibletemplate.lua"))

function init(me)
	commonInit(me, "Collectibles/arnassi-statue", FLAG_COLLECTIBLE_ARNASSISTATUE)
end

function update(me, dt)
	commonUpdate(me, dt)
end

function enterState(me, state)
	commonEnterState(me, state)
	--[[
	if entity_isState(me, STATE_COLLECTEDINHOUSE) then
		ent = createEntity("SeaHorse", "", entity_x(me)-200, entity_y(me))
		ent = createEntity("SeaHorse3", "", entity_x(me), entity_y(me))
		ent = createEntity("SeaHorse4", "", entity_x(me)+200, entity_y(me))
	end
	]]--
end

function exitState(me, state)
	commonExitState(me, state)
end
