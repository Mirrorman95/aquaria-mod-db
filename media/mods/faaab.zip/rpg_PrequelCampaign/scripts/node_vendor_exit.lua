dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, false)	
end


function update(me, dt)
	if isFlag(VENDOR_ACTIVE, 1) then
		node_setCursorActivation(me, true)
		
		if (isLeftMouse() or isRightMouse()) and not mbDown then
			mbDown = true
		elseif (not isLeftMouse() and not isRightMouse()) and mbDown then
			mbDown = false
			node = getNodeToActivate()
			setNodeToActivate(0)
			stopCursorGlow()
			if node ~= 0 then
				node_activate(node, 0)
			end
		end
	else
		node_setCursorActivation(me, false)
	end
end


function activate(me)
	playSfx("recipemenu-close")	

	setFlag(VENDOR_EXIT, 1)
	node_setCursorActivation(me, false)
end