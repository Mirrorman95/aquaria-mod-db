dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "gui/vendor_lock")	
	
	entity_alpha(me, 0)
	entity_scale(me, 1, 1)
	entity_setEntityLayer(me, 1)
end

function update(me, dt)
end