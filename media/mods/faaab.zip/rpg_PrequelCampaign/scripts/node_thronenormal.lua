dofile("scripts/entities/entityinclude.lua")

function init(me)
	node_setCursorActivation(me, true)
end

function update(me, dt)
end

function activate(me)
	n = getNaija()
	
	entity_idle(n)
	
	entity_swimToNode(n, me)
	entity_watchForPath(n)
	
	entity_animate(n, "sitThrone")

	overrideZoom(0.5, 2)
	
	watch(2)
	
	while (not isLeftMouse()) and (not isRightMouse()) do
		watch(FRAME_TIME)
	end
	
	entity_idle(n)
	entity_addVel(n, 0, -200)
	overrideZoom(1, 1)
	watch(1)
	overrideZoom(0)
end
