--dofile("scripts/include/nodecollectibletemplate.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleWalkerBaby", FLAG_COLLECTIBLE_WALKERBABY)
end

function update(me, dt)
end
