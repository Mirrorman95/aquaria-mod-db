          o                                                                   
        oc                                                                    
       ccc                                                                    
      Oooo                                                         8oo        
      @oooo                                                            oo     
      @CCCCC                                                            .CC   
      8OOOOO.       @                                                    cO:  
      8OO.OO8    @OO8                                                     8O  
      @@@ @@@   8@@@@                                                     C@. 
      @@.  @@  @@@@  @8    @@          @     @@@@@@   @@@     @           O@: 
      88   @8oO88@     88 8888    @  .888      88:88@ 888.  @8888     8   88  
   c@OOOOO@cOO@OO       OCOOO     @  O8 @O    OOo  O8  OOO  OO  O8   O   @OO  
     O8     @O8OOCO     O:OO8     O OOc  @O  OO8 OC    CO  OO8  .O.Oo   8O8   
     C       C.OCC 8CCCCO 8CC   8C CCC    C CCCOCCCCCO C8 CCC. CCCo   CCC     
    @         o  oooooOo  ooooooo  ooO    @O@ooC      .oooooooo88oooooO       
    8          o      ooo    8ooooooo C8OCcocoo:O8oooooooC        @:          
   c             8                cc    :cCOcOCc.                   C         
                                              8c                      o@@o    

                                Costume Mod Aquaria
                                  By Alphasoldier

Overview:
This is an Aquaria mod
It features a map to try out and admire all the costumes in the game, added to it is an extra costume (The Zero Suit from Metroid).
There is a known bug on the map where you go through the hot steam on the left side, up the tube, then going down the right tube and getting stuck, if you have a nice alternative, contact me.
To get all the forms, click the hanging lamp/sphere in the main room.

Installing:
To install place the CostumeMod folder and CostumeMod.xml into your Aquaria _mods folder (ex: X:\Games\Aquaria\_mods).backup is provided in the rar file.

Uninstall:
Remove the CostumeMod folder and CostumeMod.xml from your _mods folder.

Credits:
The Bit-Blot team for making this amazing game Aquaria.
Nintendo for making the delicious Zero Suit for Samus Aran.
Me, Alphasoldier, for creating the Naija Zero Suit and creating this map.

Contact:
If you encounter any bugs, have any requests or think there could be improvements feel free to contact me at:
alphasoldier@hotmail.com