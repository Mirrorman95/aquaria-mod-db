dofile("_mods/rpg_PrequelCampaign/scripts/rpg_include.lua")

function init(me)
	setupEntity(me)
	
	entity_initSkeletal(me, "merwoman", "merwoman-skin2")
	
	entity_setState(me, STATE_IDLE)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "sit", -1)
		spawnParticleEffect("abyssoctopusdie", entity_getPosition(me))
	elseif entity_isState(me, STATE_EXPLODE) then
		spawnParticleEffect("bigredexplode", entity_getPosition(me))
		entity_setState(me, STATE_DEAD, -1, 1)
	end
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end