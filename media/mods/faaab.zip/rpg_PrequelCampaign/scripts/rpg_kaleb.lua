dofile("scripts/entities/entityinclude.lua")

bone_fish1 = 0
bone_fish2 = 0
bone_weaponGlow = 0

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_initSkeletal(me, "rpg_kaleb")
	
	entity_setState(me, STATE_IDLE)
	entity_scale(me, 0.6, 0.6)
	--entity_setEntityLayer(me, -1)
	--entity_flipHorizontal(me)

	bone_fish1 = entity_getBoneByName(me, "Fish1")
	bone_fish2 = entity_getBoneByName(me, "Fish2")
	bone_weaponGlow = entity_getBoneByName(me, "WeaponGlow")

	bone_setBlendType(bone_weaponGlow, BLEND_ADD)
	bone_alpha(bone_fish1)
	bone_alpha(bone_fish2)
end

function postInit(me)
	flip = entity_getNearestNode(me, "FLIP")
	if flip~=0 and node_isEntityIn(flip, me) then
		entity_fh(me)
	end

	bwgsz = bone_getScale(bone_weaponGlow)
	refreshWeaponGlow(me)
end

function update(me, dt)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end

function refreshWeaponGlow(me)
	t = 0.5
	f = 3
	if isFlag(FLAG_LICOMBAT, 1) then
		bone_alpha(bone_weaponGlow, 1, 0.5)
		bone_color(bone_weaponGlow, 1, 0.5, 0.5, t)
	else
		bone_alpha(bone_weaponGlow, 0.5, 0.5)
		bone_color(bone_weaponGlow, 0.5, 0.5, 1, t)
	end
	--[[
	bone_scale(bone_weaponGlow, bwgsz, bwgsz)
	bone_scale(bone_weaponGlow, bwgsz*f, bwgsz*f, t*0.75, 1, 1)		
	]]--
end