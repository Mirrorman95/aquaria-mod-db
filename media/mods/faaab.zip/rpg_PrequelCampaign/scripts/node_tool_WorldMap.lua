dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

function init(me)
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function activate(me)
	--All maps now viewable on the world map
	for i,list in ipairs(mapArr) do
		setFlag(mapArr[i][7], 1)
	end
	
	setControlHint("All maps now viewable on the world map!", 0, 0, 0, 8)
end