dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Mia/panelMia_"
entityOther = "rpg_mia"
entityOtherScale = 1.7
gemToCreate = "mia"

flagChatBubble = DT_NEW_MIA
flagRepeat = 0
flagVersion = DT_VERSION_MIA
flagMain = DT_MAIN_MIA

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		0		},
		{"3a", 				"other",		"4"								},
		{"3b", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5b",		"5c"	},
		{"5a", 				"other",		"5ae1"							},
		{"5ae1",			"other",		"4"								},
		{"5b", 				"other",		"4"								},
		{"5c", 				"other",		"4"								},
	}
	
	
arrayVersion2 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		"3c"	},
		{"3a", 				"other",		"2"								},
		{"3b", 				"other",		"3b1"							},
		{"3b1", 			"elena",		"3b1a",		"3b1b",		0		},
		{"3b1a", 			"other",		"2"								},
		{"3b1b", 			"other",		"2"								},
		{"3c", 				"other",		"3c1"							},
		{"3c1", 			"elena",		"3c1a",		"3c1b",		0		},		
		{"3c1a",			"other",		"2"								},
		{"3c1b",			"other",		"2"								},
	}
	
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 3A or 3B
		if numPanel == "3a" or numPanel == "3b" then
			if isFlag(LEARNED_SHIELD, 0) then
				learnSong(7)
				setControlHint("You Have Learned The Shield Song!", 0, 0, 0, 8, "", 7)
				setFlag(LEARNED_SHIELD, 1)
			end
			
		--PANEL 4
		elseif numPanel == "4" then
			AlphaChatBubble()
			setFlag(flagMain, 1)
			
			if isFlag(HINT_DIALOGUE_OPTIONS, 0) then
				setControlHint("Panels with a '?' act as a 'Main Panel'. All subsequent panels will eventually return here. To exit simply press 'X'", 0, 0, 0, 16, "gui/icon-help")
				setFlag(HINT_DIALOGUE_OPTIONS, 1)
			end
		end
		
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 1
		if numPanel == "2" then
			AlphaChatBubble()
			setFlag(flagMain, 2)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 1
		if numPanel == "1" then
			
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	CreateMapEntity(entityOther, x, y, 0)
	CreateChatBubble(x + 40, y - 70, 0)
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)
	--MAIN
	if getFlag(flagVersion) == getFlag(flagMain) then
		if isFlag(flagMain, 1) then
			numPanel = "4"
		end
	end
	
	CommonActivate(me)
end