dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/YoungFred/panelYoungFred_"
entityOther = "druniad"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = DT_NEW_YOUNGFRED
flagRepeat = 0
flagVersion = DT_VERSION_YOUNGFRED
flagMain = 0

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		0		},
		{"3a", 				"other",		"3ae1"							},
		{"3ae1",			"other",		"4"								},
		{"3b", 				"other",		"3be1"							},
		{"3be1",			"other",		"4"								},
		{"4", 				"elena",		"5",		"5",		0		},
		{"5", 				"other",		"5e1"							},
		{"5e1", 			"other",		"6"								},
		{"6", 				"other",		"7"								},
		{"7", 				"other",		"8"								},
		{"8", 				"other",		"exit"							},
	}
	
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 6
		if numPanel == "6" then
			--SWITCH CHARS(YoungFred > OldFred)
			ChangeRightEntity("architect", 0.8, x + 670, y - 40)
			
		--PANEL 7
		elseif numPanel == "7" then
			--SWITCH CHARS(OldFred > YoungFred)
			ChangeRightEntity("druniad", 1.7, x + 670, y - 40)
			
		--PANEL 8
		elseif numPanel == "8" then
			AlphaChatBubble()
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
				
	numPanel = "1"
	currentRowID = 1
end

--INIT
function init(me)
	CommonInit(me)
	node_setCursorActivation(me, false)
end

done = false
--UPDATE
function update(me, dt)	
	if not done and (node_getNearestEntity(me, "druniad") ~= 0) then
		done = true
	
		CreateChatBubble(x + 60, y - 80, 0)
		--CreateMapEntity(entityOther, x, y, 0)
		node_setCursorActivation(me, true)
	end
	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end