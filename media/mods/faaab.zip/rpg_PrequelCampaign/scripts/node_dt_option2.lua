dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	node_setCursorActivation(me, false)	
end


function update(me, dt)
	if isFlag(DT_OPTION2, 1) then
		node_setCursorActivation(me, true)
	else
		node_setCursorActivation(me, false)
	end
end


function activate(me)
	node_setCursorActivation(me, false)
	playSfx("click")
	
	setFlag(DT_OPTION1, 0)
	setFlag(DT_OPTION2, 0)	
	setFlag(DT_OPTION3, 0)
	setFlag(CLICKED_OPTION2, 1)
end