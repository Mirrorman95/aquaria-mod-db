function init(me)
end

function update(me, dt)
	if node_isEntityIn(me, getNaija()) then
		clearControlHint()
	end
end
