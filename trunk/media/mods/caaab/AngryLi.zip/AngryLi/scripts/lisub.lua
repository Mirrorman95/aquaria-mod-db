dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/AngryLi/scripts/include.lua"))

-- ANGRY LI !
-- Naija has been imprisoned in a crystal by the infamous Mia, go rescue her !

-- Taking 3 ingredients upgrade the missiles

n = 0

touchDelay = 0.4
touchTimer = 0

fadeOutTimer = 0

WEAPON_NONE      = 0
WEAPON_MISSILE   = 1
WEAPON_MISSILE_1 = 2
WEAPON_MISSILE_2 = 3
WEAPON_MISSILE_3 = 4
WEAPON_SHOCK     = 10

primaryWeapon = WEAPON_NONE
secondaryWeapon = WEAPON_NONE

STATE_STARTENGINE = 888

primaryTimer = 0
primaryRate = 0

secondaryTimer = 0
secondaryRate = 0

shockRate = 5
shockRange = 400
shockCharged = false
shockLedGlow = 0
shockLed = 0

zoom = 0.5

ing = 0
weaponUpgrade = 0
subHealth = 25

function init(me)
 
	setupEntity(me)

	entity_initSkeletal(me, "lisub")
	entity_scale(me, 0.5, 0.5)
	shockLed = entity_getBoneByName(me, "led")
	bone_alpha(shockLed, 0)
	shockLedGlow = entity_getBoneByName(me, "ledglow")
	bone_setBlendType(shockLedGlow, BLEND_ADD)

	missileSpot = entity_getBoneByName(me, "missilespot")
	bone_alpha(missileSpot, 0)
	
	entity_setEntityType(me, ET_AVATAR)
	
	entity_setHealth(me, subHealth)
	entity_setCollideRadius(me, 32)
	entity_setUpdateCull(me, -1)
	entity_setMaxSpeed(me, 2000)
	
	entity_setDeathScene(me, true)
	
	setFlag(FLAG_LI, 0)
	li = getEntity("Li")
	if li ~= 0 then
		entity_delete(li)
		setLi(0)
	end
	
	loadSound("airship-engineloop")

	-- missiles
	loadSound("airship-boost")
	loadSound("bossdiesmall")
	loadSound("fizzlebarrier")
	
	licave = getNode("licave")
	
	if isFlag(FLAG_INTRO, 0) and isMapName("lisub1") then
		entity_setState(me, STATE_INTRO)
	else
		entity_setState(me, STATE_IDLE)
	end
	
	entity_setBounce(me, 0)
	
	entity_setBeautyFlip(me, false)
	entity_fh(me)
	entity_setBeautyFlip(me, true)
	
	--qa = createQuad("manaballlines")
	--qb = createQuad("manaballlines")
	
end
 
function postInit(me)

	n = getNaija()
	entity_alpha(n, 0)
	setCanChangeForm(false)
	
	-- set position to the last check point reached
	if isFlag(FLAG_INTRO,1) then
		entity_setPosition(me, getFlag(CHECKPOINT_X), getFlag(CHECKPOINT_Y))
		setPrimaryWeapon(WEAPON_MISSILE)
		setSecondaryWeapon(WEAPON_SHOCK)
		updateShockLed(true)
	end
	
	entity_setPosition(n, entity_getPosition(me))

	-- remove manaball dropping
	ent = getFirstEntity()
	while ent ~= 0 do
		if entity_getEntityType(ent) == ET_ENEMY then
			-- entity_setUpdateCull(ent, 1000)
			entity_setDropChance(ent,0)
		end
		ent = getNextEntity()
	end
	
	-- create camera
	cam	= createEntity("lisub_cam", entity_getPosition(me))
	entity_setPosition(cam, entity_getPosition(me))
	cam_toEntity(cam) -- view follow camera
	
	updateShockLed(false)
	
end

function getWeaponRate(weapon)
	if weapon == WEAPON_MISSILE then
		return 0.3
	elseif weapon == WEAPON_MISSILE_1 then
		return 0.22
	elseif weapon == WEAPON_MISSILE_2 then
		return 0.22
	elseif weapon == WEAPON_MISSILE_3 then
		return 0.18
	elseif weapon == WEAPON_SHOCK then
		return shockRate
	else
		return 1
	end
end

function setPrimaryWeapon(weapon)
	primaryWeapon = weapon
	primaryRate = getWeaponRate(weapon)
	primaryTimer = 0
end

function setSecondaryWeapon(weapon)
	secondaryWeapon = weapon
	secondaryRate = getWeaponRate(weapon)
	secondaryTimer = 0
end

function updateShockLed(charged)
	shockCharged = charged
	
	t = 0.5
	f = 3
	if shockCharged then
		bone_alpha(shockLedGlow, 1, 0.5)
		bone_color(shockLedGlow, 0.5, 0.5, 1, t)
		bone_scale(shockLedGlow, 1, 1)
		bone_scale(shockLedGlow, f, f, t*0.75, -1, 1)
		bone_alpha(shockLed, 0.8)
	else
		bone_alpha(shockLedGlow, 0.1, 0.5)
		-- bone_color(shockLedGlow, 0.5, 0.5, 1, t)
	end
	
end

-- shock : deal heavy damage to all creatures around the submarine
function shock(me)

	spawnParticleEffect("lisub-shock", entity_x(me), entity_y(me))
	playSfx("fizzlebarrier",0,2)
	
	ent = getFirstEntity()
	while ent~=0 do
		if entity_getEntityType(ent) == ET_ENEMY
		and entity_getDistanceToEntity(me, ent) <= shockRange then
			entity_damage(ent, me, 10)
		end
		ent = getNextEntity()
	end
	
end

-- fire a weapon
function fireWeapon(me, weapon)

	if weapon == WEAPON_NONE then
	elseif weapon == WEAPON_MISSILE then
		createEntity("lisub_missile0", "", bone_getWorldPosition(missileSpot))
	elseif weapon == WEAPON_MISSILE_1 then
		createEntity("lisub_missile1", "", bone_getWorldPosition(missileSpot))
	elseif weapon == WEAPON_MISSILE_2 then
		createEntity("lisub_missile2", "", bone_getWorldPosition(missileSpot))
	elseif weapon == WEAPON_MISSILE_3 then
		createEntity("lisub_missile3", "", bone_getWorldPosition(missileSpot))
	elseif weapon == WEAPON_SHOCK then
		shock(me)
		updateShockLed(false)
	end
	
end

-- give position on the screen, return position in-game
function toWorldFromWindow( wx, wy, zoom)
	cx, cy = getScreenCenter()
	return cx + (-400 + wx) / zoom, cy + (-300 + wy) / zoom
end

ini = 0

function update(me, dt)

	--------------------------
	-- RESULUTION DETECTION --
	--------------------------
	
	-- this will check if we are using widescreen or not.
	if ini < 2 then
		
		-- we need to wait a frame so the mouse position is restricted into the visible area.
		if ini == 0 then
			setMousePos(-1000, 0)
		elseif ini == 1 then
			x, y = getMousePos()
			
			-- record the widescreen amount
			if x <= 0 then
				wideScreenAmount = math.abs(x)
				setFlag(WIDESCREEN_AMOUNT,wideScreenAmount)
				-- center mouse
				setMousePos(400,300)
			-- problem with detection (user moved mouse ?) try again
			else
				ini = 0
			end
		end
		
		ini = ini + 1
	end
	
	-- exit when in menu
	if isNestedMain() or isNested() then
		return
	end
	
	if isEscapeKey() then
		
		pause()
		
		enableInput()
		if confirm("", "exit") then
			goToTitle()
		else
			unpause()
		end

	end

	if isInputEnabled() then
		avatar_toggleCape(false)
		disableInput()
	end
	
	if entity_isState(me, STATE_INTRO) then
		watch(3)
		entity_setState(me, STATE_IDLE)
		entity_fhTo(me, entity_isfh(cam))
		-- watch(2)
		return
	elseif entity_isState(me, STATE_IDLE) then
		overrideZoom(zoom, 2)
	end
	
	--------------------
	-- WALL COLLISION --
	--------------------
	
	mx, my = getMouseWorldPos()
	x, y = entity_getPosition(me)

	if isObstructed(mx, my) then

		-- find nearest wall point
		if not isObstructed(x, y) then
			
			-- vector sub->mouse
			vx, vy = mx-x, my-y
			len = vector_getLength(vx, vy)

			while len > 20.0 do

				-- 2 times smaller
				len = len / 2.0
				vx, vy = vx/2.0, vy/2.0

				-- make point closer to border
				if not isObstructed(x + vx, y + vy) then
					x, y = x + vx, y + vy
				end

			end
			
			setMousePos(toWindowFromWorld(x, y))
			entity_setPosition(me, getMouseWorldPos())
			
		end
	else
		entity_setPosition(me, mx, my)
	end
	
	-------------
	-- WEAPONS --
	-------------
	
	if primaryTimer > 0 then
		primaryTimer = primaryTimer - dt
	end
	
	if secondaryTimer > 0 then
		secondaryTimer = secondaryTimer - dt
	end
	
	-- shock is charged
	if not shockCharged and (secondaryWeapon == WEAPON_SHOCK and secondaryTimer <= 0) then
		updateShockLed(true)
	end
	
	-- fire weapon !
	if isLeftMouse() and primaryTimer <= 0 then
		fireWeapon(me, primaryWeapon)
		primaryTimer = primaryRate
	end
	if isRightMouse() and secondaryTimer <= 0 then
		fireWeapon(me, secondaryWeapon)
		secondaryTimer = secondaryRate
	end
	
	-------------------------
	-- PICKUP INGREDIENT --
	-------------------------

	while 1==1 do
	
		ent = entity_getNearestEntity(me, "", 100, ET_INGREDIENT)
		if ent == 0 then
			break
		end
		
		ing = ing + 1
		playSfx("pickup-ingredient")
		-- setControlHint('INGREDIENT !', 0, 0, 0, 1)
		
		-- an upgrade requires more and more ingredients
		if weaponUpgrade == 0 and ing >= 1
        or weaponUpgrade == 1 and ing >= 2
		or weaponUpgrade == 2 and ing >= 3 then
			ing = 0 -- reset ing counter
			weaponUpgrade = weaponUpgrade + 1
			setPrimaryWeapon(WEAPON_MISSILE + weaponUpgrade)
			setControlHint('WEAPON UPGRADE !', 0, 0, 0, 1)
		end
		entity_delete(ent)
		-- entity_setFlag(ent, 1)
	end
	
	-------------------
	-- ENEMY DAMAGES --
	-------------------
				
	entity_handleShotCollisions(me)
	
	if touchTimer > 0 then
		touchTimer = touchTimer - dt
	-- can be touched by an entity
	else
		ent = entity_getNearestEntity(me, "", 100, ET_ENEMY)
		
		-- touching an entity !!!
		if ent ~= 0 then

			if entity_getCollideRadius(me) + entity_getCollideRadius(ent) >= entity_getDistanceToEntity(me, ent) then
				entity_damage(me, ent, 1)
			end
		end
	
	end

	-----------
	-- FLASH --
	-----------
	
	-- for the red flash when we are touched
	if fadeOutTimer > 0 then
		fadeOutTimer = fadeOutTimer - dt
		if fadeOutTimer <= 0 then
			fade(0, 0.05)
		end
	end
	
	-- make Naija's position match the sub position
	entity_setPosition(n, entity_getPosition(me))

	-- quad_setPosition(qa, toWorldFromWindow(-wideScreenAmount,0,0.5))
	-- quad_setPosition(qb, toWorldFromWindow(800 + wideScreenAmount,600,0.5))

end

function damage(me, attacker, bone, damageType, dmg)

	dmg = 1 -- all is 1 damage

	if touchTimer <= 0 then
		
		-- red flash
		bone_damageFlash(entity_getBoneByName(me, "subfront"))
		fade(0.3, 0.05, 1, 0, 0)
		fadeOutTimer = 0.1 -- will fade out in 0.1 sec
		playSfx("vinehit")
		
		health = entity_getHealth(me) - dmg
		entity_setHealth(me, entity_getHealth(me) - dmg)
		
		if health <= 0 then
			entity_setInvincible(me, true)
			pause()
			setControlHint("You are dead ...", 0, 0, 0, 1)
			fade(0.8, 1, 1, 0, 0)
			watch(1)
			warpAvatar(getMapName())
			return false
		end
		
		setControlHint('Structure points : ' .. health .. '/' .. subHealth, 0, 0, 0, 1)
		
		if health <= subHealth / 4.0  then
			entity_animate(me, "damaged", -1)
		else
			entity_animate(me, "idle", -1)
		end
		
		ing = 0 -- reset ing count
		
		-- loose one level of weapon upgrade
		if weaponUpgrade > 0 then
			weaponUpgrade = weaponUpgrade - 1
			setPrimaryWeapon(WEAPON_MISSILE + weaponUpgrade)
		end
		
		-- small delay before being able to be touched again
		touchTimer = touchDelay
	end
	
	return false
end
 
function dieNormal(me)
end

function animationKey(me, key)
	if entity_isState(me, STATE_INTRO) then
		if key == 1 then
			entity_offset(me, 0, -5, 0.1, -1, 1, 1)
			playSfx("airship-engineloop", 1000, 0.9)
		end
	end
end
 
function enterState(me)

	if entity_isState(me, STATE_INTRO) then
		overrideZoom(2)
		overrideZoom(1.6, 2)
		entity_animate(me, "intro")
		entity_setPosition(me, node_getPosition(licave))
		entity_setPosition(cam, entity_getPosition(me))
		setControlHint("Naija has been imprisoned in a crystal by the infamous Mia, go rescue her !", 0, 0, 0, 4)
		setPrimaryWeapon(WEAPON_NONE)
		setSecondaryWeapon(WEAPON_NONE)
	elseif entity_isState(me, STATE_IDLE) then
		overrideZoom(0.5, 10)
		entity_stopAllAnimations(n)
		entity_offset(me, 0, -5, 0.1, -1, 1, 1)
		playSfx("airship-engineloop", 1000, 0.9)
		entity_animate(me, "idle", -1)
		entity_setState(cam, STATE_FOLLOW)
	elseif entity_isState(me, STATE_DEATHSCENE) then
		-- warpAvatar(getMapName())
	end

end

-- hint nodes that activate weapons
function msg(me, msg)
	if msg == "activatemissile" then
		setPrimaryWeapon(WEAPON_MISSILE)
	elseif msg == "activateshock" then
		setSecondaryWeapon(WEAPON_SHOCK)
		updateShockLed(true)
	end
end
 
function exitState(me)
end
 
function hitSurface(me)
end
 
function songNote(me, note)
end
 
function songNoteDone(me, note)
end
 
function song(me, song)
end
 
function activate(me)
end