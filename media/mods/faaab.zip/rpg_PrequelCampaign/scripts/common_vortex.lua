n = 0
fedor = 0
destination = 0

function commonInit(me, strDestination)
	n = getNaija()
	fedor = entity_getNearestEntity(n, "rpg_Fedor")
	destination = getNode(strDestination)
	
	node_setCursorActivation(me, true)
	loadSound("mia-appear")
	spawnParticleEffect("vortex", node_x(me), node_y(me))
end

function commonActivate(me)
	--ORB: move bound energy orb through vortex
	orb = entity_getNearestEntity(n, "EnergyOrb")
	orbCracked = entity_getNearestEntity(n, "EnergyOrbCracked")
	if entity_isBeingPulled(orb) then
		entity_warpToNode(orb, destination)
	elseif entity_isBeingPulled(orbCracked) then
		entity_warpToNode(orbCracked, destination)
	end
	
	--FEDOR: if riding warp Fedor first (elena and naija attached)
	if  entity_getRiding(n) ~= 0 and fedor ~= 0 then
		entity_warpToNode(fedor, destination)
	else
		entity_warpToNode(n, destination)
	end
	
	playSfx("mia-appear")
end