dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
	bleh = getNode("dt_brainGuard")
end

function update(me, dt)
	if isFlag(IMPRISONED, 0) and node_isEntityIn(me, n) then
		node_activate(bleh)
		setFlag(IMPRISONED, 1)
	end
end