--dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "symbols/icon-bookcase")	
	
	entity_scale(me, 1.5, 1.5)
	entity_setEntityLayer(me, -1)
	entity_alpha(me, 0.9)
end

function postInit(me)
end

function update(me, dt)
end

function enterState(me)
end

function exitState(me)
end