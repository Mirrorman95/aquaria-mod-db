dofile("scripts/entities/entityinclude.lua")

attackTimer = 0
n = 0
body = 0


function init(me)
	setupEntity(me)
	
	entity_initSkeletal(me, "SunkenDad")
	entity_setState(me, STATE_IDLE)
	entity_scale(me, 2, 2)
	
	entity_setCull(me, false)
	entity_setEntityType(me, ET_NEUTRAL)
	
	entity_generateCollisionMask(me)
	n = getNaija()
	
	entity_setDamageTarget(me, DT_AVATAR_LIZAP, false)
	entity_setDamageTarget(me, DT_ENEMY_ENERGYBLAST, false)
	
	entity_setEatType(me, EAT_NONE)
	entity_setTargetRange(me, 256)
	body = entity_getBoneByName(me, "Body")
	entity_setTargetRange(me, 2000)
	
	loadSound("sunkendad-roar")
	loadSound("sunkendad-hit")
	loadSound("ChopRock")
	loadSound("sunkendad-stomp")
	loadSound("sunkendad-breakout")
	loadSound("mia-appear")
	loadSound("sunkendad-headspurt")
end

function postInit(me)
end

function animationKey(me, key)
	if entity_isState(me, STATE_ATTACK1) then
		if key == 4 then
			shakeCamera(10, 0.5)
			playSfx("ChopRock")
		end
	elseif entity_isState(me, STATE_ATTACK2) then
		if key == 2 then
			shakeCamera(10, 0.5)
			playSfx("ChopRock")
		end
	elseif entity_isState(me, STATE_PREP3) then
		if key == 4 or key == 6 or key == 8 then
			playSfx("sunkendad-stomp")
		end
	elseif entity_isState(me, STATE_ATTACK3) then
		if key == 2 or key == 4 then
			playSfx("sunkendad-stomp")
		end
	end
	dadMax = getNode("DADMAX")
	dadMin = getNode("DADMIN")
end

function update(me, dt)
end

function hitSurface(me)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
		entity_flipToEntity(me, n)
	elseif entity_isState(me, STATE_PREP1) then
		playSfx("sunkendad-roar")
		entity_setStateTime(me, entity_animate(me, "prep1"))
	elseif entity_isState(me, STATE_PREP2) then
		playSfx("sunkendad-roar")
		entity_flipToEntity(me, n)
		entity_setStateTime(me, entity_animate(me, "prep2"))
	elseif entity_isState(me, STATE_PREP3) then
		playSfx("sunkendad-roar")
		entity_setStateTime(me, entity_animate(me, "prep3"))
		entity_flipToEntity(me, n)
	elseif entity_isState(me, STATE_ATTACK1) then
		entity_flipToEntity(me, n)
		entity_animate(me, "attack")
	elseif entity_isState(me, STATE_ATTACK2) then
		entity_flipToEntity(me, n)
		entity_animate(me, "attack2")
		minJumpLen = 100
		maxJumpLen = 600
		dist = entity_x(n) - entity_x(me)
		if dist > maxJumpLen then
			dist = maxJumpLen
		end
		if dist < minJumpLen then
			dist = minJumpLen
		end
		if dist > -maxJumpLen then
			dist = -maxJumpLen
		end
		if dist < -minJumpLen then
			dist = -minJumpLen
		end		
		entity_setPosition(me, entity_x(n) + dist, entity_y(me), 1)
		entity_offset(me, 0, -650, 0.5, 1, 1)
	elseif entity_isState(me, STATE_ATTACK3) then
		entity_flipToEntity(me, n)
		entity_animate(me, "attack3", -1)
		chargeDist = 2000
		spd = 1800
		if entity_x(n) < entity_x(me) then
			entity_setPosition(me, entity_x(me) - chargeDist, entity_y(me), -1 * spd)
		else
			entity_setPosition(me, entity_x(me) + chargeDist, entity_y(me), -1 * spd)
		end
	elseif entity_isState(me, STATE_WAITFORKISS) then
		entity_animate(me, "idle", -1)
	elseif entity_isState(me, STATE_KISS) then
		entity_setStateTime(me, entity_animate(me, "kiss"))
	elseif entity_isState(me, STATE_RAGE) then
		entity_setStateTime(me, entity_animate(me, "rage"))
		entity_color(me, 1, 0.5, 0.5, 3)
		enraged = true
		entity_setDamageTarget(me, DT_AVATAR_LIZAP, true)
	elseif entity_isState(me, STATE_CALM) then
		enraged = false
		entity_setStateTime(me, entity_animate(me, "calm"))
		entity_color(me, 1, 1, 1, 3)
		entity_setDamageTarget(me, DT_AVATAR_LIZAP, false)
	elseif entity_isState(me, STATE_DEATHSCENE) then
		--entity_setStateTime(mom, 10)
		entity_setAllDamageTargets(me, false)
		debugLog("DEATH SCENE!")
		pickupGem("Boss-SunkenDad")
		deathScene = true
		entity_animate(me, "die")
		entity_setStateTime(me, -1)
		entity_setState(mom, STATE_DEATHSCENE)
		entity_color(me, 1, 1, 1, 5)
		entity_stopInterpolating(me)
		entity_setPosition(me, entity_x(me), entity_y(me), 0.1)
		cutScene(me)
		toggleSteam(false)
		
	elseif entity_isState(me, STATE_START) then
		started = true
		entity_setStateTime(me, 0.1)
	end
end

function exitState(me)
	if entity_getEnqueuedState(me) == STATE_DEATHSCENE or entity_getEnqueuedState(me) == STATE_ENRAGED then
		return
	end
	
	if entity_isState(me, STATE_KISS) then
		entity_setState(me, STATE_IDLE)
		attackTimer = -1
	elseif entity_isState(me, STATE_RAGE) then
		entity_setState(me, STATE_IDLE)
	elseif entity_isState(me, STATE_PREP2) then
		entity_setState(me, STATE_ATTACK2)
	elseif entity_isState(me, STATE_PREP3) then
		entity_setState(me, STATE_ATTACK3)
	elseif entity_isState(me, STATE_START) then
		entity_setState(me, STATE_IDLE)		
	end
end