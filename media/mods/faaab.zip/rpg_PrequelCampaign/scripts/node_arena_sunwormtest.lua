dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_cutman.lua"))

flag = TIMER_BOSS_SUNWORMTEST

function init(me)
	commonInit(me, flag)
end

function update(me, dt)	
	commonUpdate(me, dt)
end