--[[ 
DIALOGUE TREE CODE: by Danny O'Connell [ http:://doconnell.wordpress.com ]
This file calls functions in "common_DialogueTree.lua"
]]--

dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/OldFred/panelOldFred_"
entityOther = "architect"
entityOtherScale = 0.8
gemToCreate = 0

flagChatBubble = DT_NEW_OLDFRED
flagRepeat = DT_REPEAT_OLDFRED
flagVersion = DT_VERSION_OLDFRED
flagMain = DT_MAIN_OLDFRED_V1

nodeActive = false
nodeClickableOnExit = true
architect = 0


arrayVersion1 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"1e1"							},	--next
		{"1e1", 			"other", 	"2"								},
		{"2", 				"elena",	"3a", 		"3b", 		0		},	--input
		{"3a", 				"other",	"4"								},
		{"3b", 				"other",	"4"								},
		{"4", 				"elena",	"5a", 		0,			"5b"	},
		{"5a", 				"other",	"5e1"							},
		{"5b", 				"other",	"5e1"							},
		{"5e1", 			"other",	"6"								},
		{"6", 				"elena",	"7", 		0,			0		},
		{"7", 				"other",	"8"								},
		{"8", 				"elena",	"9a", 		"9b",		"9c"	},
		{"9a", 				"other",	"8"								},
		{"9b", 				"other",	"8"								},
		{"9c", 				"other",	"9ce1"							},
		{"9ce1",			"other",	"8"								},
	}
	
arrayVersion2 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"2"								},	--next
		{"2", 				"elena",	"3a", 		"3b", 		"3c"	},	--input
		{"3a", 				"other",	"4"								},
		{"3b",				"other",	"4"								},
		{"3c",				"other",	"4"								},
		{"4", 				"elena",	"5a", 		0,			0		},
		{"5a", 				"other",	"5ae1"							},
		{"5ae1",			"other",	"5ae2"							},
		{"5ae2", 			"other",	"6"								},
		{"6", 				"elena",	"7a", 		"7b",		0		},
		{"7a", 				"other",	"8"								},
		{"7b", 				"other",	"8"								},
		{"8", 				"other",	"exit"							},	--exit
	}
	
arrayVersion3 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"2"								},	--next
		{"2", 				"elena",	"3a", 		"3b", 		"3c"	},	--input
		{"3a", 				"other",	"3e1"							},
		{"3b", 				"other",	"3e1"							},
		{"3c", 				"other",	"3e1"							},
		{"3e1", 			"other",	"4"								},
		{"4", 				"elena",	"5", 		"5",		0		},
		{"5", 				"other",	"5e1"							},
		{"5e1", 			"other",	"exit"							},	--exit
	}



--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 8
		if numPanel == "8" then
			AlphaChatBubble()
			setFlag(flagMain, 1)
			
		--PANEL 9C
		elseif numPanel == "9c" then
			--QUEST
			if isFlag(QUEST_OLDFRED_SOUP, 0) then
				setFlag(QUEST_OLDFRED_SOUP, 1)
				setControlHint("Retrieve Old Fred's Royal Soup from the Ice Veil accessed from the southwest of the veil.", 0, 0, 0, 16, "ingredients/royal-soup")
			end
		end
		
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 8
		if numPanel == "8" then
			AlphaChatBubble()
			setFlag(MITHALAS_VISION, 1)
		end
		
	--VERSION 3
	elseif isFlag(flagVersion, 3) then
		--PANEL 5E1
		if numPanel == "5e1" then
			AlphaChatBubble()
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 8
		if numPanel == "8" then
			--Mithala Vision
			if isFlag(MITHALAS_VISION, 1) then
				setFlag(MITHALAS_VISION, 2)
				entity_setPosition(n, x + 75, y)

				watch(1)

				--PORT OUT ELENA
				entity_setInvincible(n, true)
				entity_idle(n)
				entity_clearVel(n)
				
				spawnParticleEffect("MiaWarp", x + 75, y)
				playSfx("mia-appear")
				entity_alpha(n, 0, 2)

				watch(3)

				warpNaijaToSceneNode("rpg_CathedralPriest", "visionstart", "r")
			end
		end
	--VERSION 3
	elseif isFlag(flagVersion, 3) then
		--PANEL 5E1
		if numPanel == "5e1" then
			nodeClickableOnExit = false
			
			--CUTSCENE
			setFlag(CS_PIPESUCK, 1)
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	if getFlag(flagVersion) < 4 then
		CommonInit(me)
		CreateMapEntity(entityOther, x, y, 0)
		CreateChatBubble(x - 50, y - 100, 1)
		
		loadSound("mia-appear")
	end
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	--IF MAIN ON THIS VERSION
	if getFlag(flagVersion) == getFlag(flagMain) then
		--VERSION 1
		if isFlag(flagMain, 1) then
			numPanel = "8"
		end
	end
	
	CommonActivate(me)
end