dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "panels/panel_bg")	
	
	entity_scale(me, 2.2, 2.2)
	entity_alpha(me, 0)
	entity_setEntityLayer(me, 0)
end

function update(me, dt)
end