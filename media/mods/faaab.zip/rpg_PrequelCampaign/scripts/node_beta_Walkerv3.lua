dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5

function init(me)
	n = getNaija()
	
	if isFlag(DT_VERSION_WALKER, 3) then
		node_setCursorActivation(me, true)
		createEntity("hintBubble", "", node_x(me), node_y(me))
	end
	
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("The Walker informs you that Drask and the Walker himself have been leading you on a wild goose chase.", 0, 0, 0, 10)		
	elseif thingSaying == 1 then
		setControlHint("They were protecting you from Mithalas' corrupt fall from within. More would be talked about reguarding that.", 0, 0, 0, 10)
	elseif thingSaying == 2 then
		setControlHint("The Walker went against the plan and let you return to Drask earlier as Drask worried about not seeing you one last time. Return to Corrupt Mithalas.", 0, 0, 0, 12)
	elseif thingSaying == 3 then
		setFlag(MITHALAS_CORRUPTED, 1)
		setFlag(DT_VERSION_WALKER, 4)
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end