dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
camDummy = 0


function init()
	n = getNaija()
	entity_setPosition(n, 0, 0)
	camDummy = createEntity("Empty")
	start = getNode("start")
	finish = getNode("finish")
	statue = getNode("statue")
	
	--[[
	entity_warpToNode(camDummy, statue)
	--cam_toEntity(camDummy)
	cam_toNode(statue)

	overrideZoom(0.6)

	watch(3)
	
	fade(0,4)
	overrideZoom(0.7, 8)
	--setControlHint("The greatest of their stories started with the desertion of Mithala.", 0, 0, 0, 6)
	
	watch(4)

	fade(1,4)

	watch(4)
	]]--

	overrideZoom(0.3, 0)
	entity_warpToNode(camDummy, start)
	cam_toEntity(camDummy)
	entity_setPosition(camDummy, node_x(finish), node_y(finish), 40)

	watch(1)
	fade(0,4)
	watch(3)

	setControlHint("In ages past, Mithala constantly traversed his waters in the defense of his people. Even after the Krotite wars, when Aquaria was at peace, he never tired.", 0, 0, 0, -1)
	watch(8)
	
	setControlHint("Unbeknownst to his subjects, he waited in fear of one much greater than himself... but they never came. His wanderings began to slowly put distance between he and his people, and eventually he left his waters never to return.", 0, 0, 0, -1)
	watch(11)
	
	setControlHint("His absence slowly devoured the Mithalan faith, and they began to perceive that he was not the god they once thought he was.", 0, 0, 0, -1)	
	watch(7)

	fade(1,4)

	watch(3.5)
	
	--loadMap("rpg_cathedralhome")
	loadMap("rpg_intro03")
end