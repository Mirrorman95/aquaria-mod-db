dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

n = 0

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
end
	
function activate(me)
	savePoint(me)
end

function update(me, dt)
	if node_isEntityIn(me, n) then
		if node_isFlag(me, 0) then
			node_foundGem(me, "savepoint")
			node_setFlag(me, 1)
		end
	end
end
