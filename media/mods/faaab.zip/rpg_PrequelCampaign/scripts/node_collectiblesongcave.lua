dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleSongCave", FLAG_COLLECTIBLE_SONGCAVE)
end

function update(me, dt)
end
