dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 2
holderID = 17
flag = ED_ENTER_CATHEDRALPRIEST

dofile("scripts/include/energyslottemplate.lua")