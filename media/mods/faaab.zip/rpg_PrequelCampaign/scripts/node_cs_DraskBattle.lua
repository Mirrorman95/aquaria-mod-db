dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
door = 0
battleEntities = 0
delay = 5
setup = false
timer = false

CamDummy = 0
battleEntities = 0

function init(me)
	n = getNaija()

	fightLocation = getNode("BATTLE")
	start = getNode("START")
	finish = getNode("FINISH")
end


function update(me, dt)
	if isFlag(CS_DRASKBATTLE, 0) then
		if (setup == false) and node_isEntityIn(me, n) then
			entity_setInvincible(n, true)
			entity_idle(n)
			entity_clearVel(n)
			disableInput()

			battleEntities = createEntity("draskpriestbattle", "", node_x(fightLocation), node_y(fightLocation))
			--shakeCamera(10, 5)
			playSfx("naijagasp")
	
			camDummy = createEntity("empty", "", node_x(start), node_y(start))
			cam_toEntity(camDummy)
			entity_setPosition(camDummy, node_x(finish), node_y(finish), 5)
		
			setup = true
			timer = true
		end

		if delay > 0 and (timer == true) then
			delay = delay - dt
		end

		if delay <= 0 and (timer == true) then
			timer = false
			setFlag(DEATH_OF_DRASK, 1)
			setFlag(CS_DRASKBATTLE, 1)

			cam_toEntity(n)
			overrideZoom(0)
			entity_setInvincible(n, false)
			enableInput()
		
			entity_delete(battleEntities)
			entity_delete(camDummy)

		--CREATE DRASK-Statue
			node = getNode("dt_brainDrask_v3")
			drask = createEntity("drask-statue", "", node_x(node), node_y(node))
		end
	end
end