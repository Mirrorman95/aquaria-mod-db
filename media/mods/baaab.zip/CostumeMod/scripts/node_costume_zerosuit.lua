dofile("scripts/entities/EntityInclude.lua")

costum="zerosuit"
n= 0

function init(me)
	node_setCursorActivation(me, true)
end
	
function activate(me)
	if getCostume()==costum then
		setCostume("")
	else
		setCostume(costum)
	end
	spawnParticleEffect("sunflare", entity_x(getNaija()), entity_y(getNaija()))
	playSfx("dualform-switch")
end

function update(me, dt)
end