dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))
dofile("scripts/entities/entityinclude.lua")

imagePath = "panels/Mithala/panelMithala_"
entityOther = "rpg_mithalangod_flip"
entityOtherScale = 0.5
gemToCreate = 0

flagChatBubble = DT_NEW_MITHALA
flagRepeat = 0
flagVersion = DT_VERSION_MITHALA
flagMain = 0

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3",		"3",		0		},
		{"3", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5a",		"5c"	},
		{"5a", 				"other",		"5c"							},
		{"5c", 				"other",		"6"								},
		{"6", 				"elena",		"7a",		0,			"7b"	},
		{"7a", 				"other",		"8"								},
		{"7b", 				"other",		"8"								},
		{"8", 				"elena",		"9a",		"9b",		"9b"	},
		{"9a", 				"other",		"9ae1"							},
		{"9ae1",			"other",		"10"							},
		{"9b", 				"other",		"10"							},
		{"10", 				"other",		"exit"							},
	}

	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 1
		if numPanel == "1" then
			entity_setPosition(other, x + 670, y + 40)
		
		--PANEL 9A
		elseif numPanel == "9a" then
			--STANCE ON MITHALA: oppose
			setFlag(MITHALA_STANCE, 2)
			
		--PANEL 9B
		elseif numPanel == "9b" then
			--STANCE ON MITHALA: support
			setFlag(MITHALA_STANCE, 1)
			
		--PANEL 10
		elseif numPanel == "10" then
			--SWITCH CHARS(OLDFRED)
			ChangeRightEntity("architect", 0.8, x + 670, y - 40)
			AlphaChatBubble()

			--LEARN BEAST FORM
			learnSong(SONG_BEASTFORM)
			setControlHint("You Have Learned The Beast Song!", 0, 0, 0, 8, "", 6)	
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 10
		if numPanel == "10" then
			--BEAST IT UP
			changeForm(FORM_BEAST)
			
			--PORT OUT ELENA
			entity_setInvincible(n, true)
			entity_idle(n)
			entity_clearVel(n)
			
			spawnParticleEffect("MiaWarp", x, y)
			playSfx("mia-appear")
			entity_alpha(n, 0, 2)

			watch(3)

			--MIA CS
			Mia = createEntity("eric_13", "", x - 350, y - 20)
			entity_fh(Mia)
			entity_alpha(Mia, 0)
			entity_alpha(Mia, 1, 2)
	
			spawnParticleEffect("MiaWarp", x - 350, y - 20)
			playSfx("mia-appear")
			
			watch(3)

			entity_animate(Mia, "touchNaija")
			playSfx("13Touch")
			setControlHint("It is time, Mithala. Fail me, and you will watch as I kill every last one of your people.",  0, 0, 0, 6, "")
			watch(7)
			
			spawnParticleEffect("MiaWarp", x - 350, y - 20)
			entity_delete(Mia, 2)
			entity_delete(mapEntity, 2)
			entity_delete(chatBubble, 2)

			watch(3)

			--GTFO!
			setFlag(MITHALAS_VISION, 3)
			setFlag(DT_VERSION_OLDFRED, 3)
			setFlag(DT_NEW_OLDFRED, 0)
			warpNaijaToSceneNode("rpg_oldfred", "dt_next", "l")
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)	
	if getFlag(MITHALAS_VISION) < 3 then
		CommonInit(me)
		CreateMapEntity(entityOther, x + 350, y + 475, 0)
		CreateChatBubble(x - 150, y - 250, 1)
		entity_scale(chatBubble, 2, 2)
		
		loadSound("13Touch")
		loadSound("mia-appear")
	end
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end