dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))
dofile("scripts/entities/entityinclude.lua")

imagePath = "panels/Rajah/panelRajah_"
entityOther = "priestnormal"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = DT_NEW_RAJAH
flagRepeat = DT_REPEAT_RAJAH
flagVersion = DT_VERSION_RAJAH
flagMain = DT_MAIN_RAJAH

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3",		"3",		0		},
		{"3", 				"other",		"exit"							},
		{"R", 				"other",		"exit"							},
	}
	
	
arrayVersion2 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		"3c"	},
		{"3a", 				"other",		"3a1"							},
		{"3a1", 			"elena",		"3a1a",		0,			0		},
		{"3a1a",			"other",		"2"								},
		{"3b", 				"other",		"2"								},
		{"3c", 				"other",		"2"								},
		
	}

	
arrayVersion3 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		0		},
		{"3a", 				"other",		"4"								},
		{"3b", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5b",		0		},
		{"5a", 				"other",		"6"								},
		{"5b", 				"other",		"6"								},
		{"6", 				"elena",		"7a",		"7b",		0		},
		{"7a", 				"other",		"8"								},
		{"7b", 				"other",		"8"								},
		{"8", 				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 3
		if numPanel == "3" then
			AlphaChatBubble()
			setFlag(flagRepeat, 1)
		end
		
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 2
		if numPanel == "2" then
			AlphaChatBubble()
			setFlag(flagMain, 2)
		end
		
	--VERSION 3
	elseif isFlag(flagVersion, 3) then
		--PANEL 8
		if numPanel == "8" then
			AlphaChatBubble()
			nodeClickableOnExit = false
			
			--SUN FORM
			learnSong(11)
			setControlHint("You Have Learned The Sun Song!", 0, 0, 0, 8, "", 7)
			setFlag(LEARNED_SUN, 1)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 3
		if numPanel == "3" then
			if isFlag(CS_GHOSTS_IN_MITHALAS, 0) then
				setFlag(CS_GHOSTS_IN_MITHALAS, 1)

				watch(1)
				loadMap("rpg_Mithalas01")
			end
		end
		
	--VERSION 3
	elseif isFlag(flagVersion, 3) then
		--PANEL 8
		if numPanel == "8" then
			--SUN IT UP
			changeForm(FORM_SUN)
			
			playSfx("mia-appear")
			spawnParticleEffect("MiaWarp", x, y)
			entity_delete(mapEntity, 2)
			entity_delete(chatBubble, 2)				

			nodeClickableOnExit = false
			setFlag(DT_VERSION_RAJAH, 4)
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)	
	--VERSION 1 and 2
	if getFlag(flagVersion) < 3 and isMapName("rpg_cathedral01") then
		CommonInit(me)
		CreateMapEntity(entityOther, x, y, 0)
		CreateChatBubble(x - 40, y - 90, 1)
		
	--VERSION 3
	elseif isFlag(flagVersion, 3) and isMapName("rpg_openWater01") and isFlag(DEATH_OF_DRASK, 3) then
		CommonInit(me)
		CreateMapEntity(entityOther, x, y, 1)
		CreateChatBubble(x - 40, y - 90, 1)

		loadSound("mia-appear")		
	end
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	--MAIN
	if getFlag(flagVersion) == getFlag(flagMain) then
		if isFlag(flagMain, 2) then
			numPanel = "2"
		end
	end
	
	CommonActivate(me)
end