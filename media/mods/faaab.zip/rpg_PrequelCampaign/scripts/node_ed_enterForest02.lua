dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 19
holderID = 24
flag = ED_ENTER_FOREST02

dofile("scripts/include/energyslottemplate.lua")