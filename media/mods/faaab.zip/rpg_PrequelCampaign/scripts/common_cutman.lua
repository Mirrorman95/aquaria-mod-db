dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
timer = 0
flagTimer = 0
oldTime = 0
stopTimer = false

function commonInit(me, flag)	
	n = getNaija()
	avatar_setCanDie(false)

	--previous best time
	flagTimer = flag
	oldTime = getFlag(flagTimer)

	--show timer
	setTimerTextAlpha(1, 1)
end

function commonUpdate(me, dt)
	--ELENA COSTUME
	if getCostume() == "" then
		setCostume("elena")
	end
	
	--FAILED: player died -> prevent game over screen
	if entity_getHealth(n) <= 1 then
		Wrapup("You died!")
		
	--SUCCESS: completed level
	elseif isFlag(ARENA_COMPLETE, 1) then
		setFlag(ARENA_COMPLETE, 0)
		
		--FIRST FINISH
		if oldTime == 0 then
			setFlag(flagTimer, timer)
		--EVERY TIME AFTER FIRST: is the new time faster?
		elseif timer < oldTime then
			setFlag(flagTimer, timer)
		end
	
		Wrapup("You won!")
		
	--TIMER: increase and display
	elseif not stopTimer then
		timer = timer + dt
		setTimerText(timer)
	end
end

function Wrapup(text)
	stopTimer = true
	
	avatar_setCanDie(true)
	entity_clearVel(n)
	entity_idle(n)
		
	setControlHint(text, 0, 0, 0, 8)
	watch(3)
	
	cureAllStatus()
	entity_heal(n, 100)
	warpNaijaToSceneNode("rpg_veil03", "arenaMaster", "r")
end