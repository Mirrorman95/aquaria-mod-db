dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if getFlag(FEDOR_HANGOUT) > 0 and node_isEntityIn(me, n) then
		setFlag(FEDOR_HANGOUT, 0)
	end
end