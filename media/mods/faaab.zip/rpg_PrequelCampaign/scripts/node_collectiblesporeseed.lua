dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleSporeSeed", FLAG_COLLECTIBLE_SPORESEED)
end

function update(me, dt)
end
