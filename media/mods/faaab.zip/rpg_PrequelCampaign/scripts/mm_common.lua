--ARRAY ICON ENTRIES
--x, y, +/-flag, image path
--x and y are offsets from the tile center

mapArr = 
	{
		{"rpg_ForestMermog", "mmaps/rpg_ForestMermog.png", 0, 0, 512, 512, 650, "Forest Mermog",
			{
				{450,  400, -651, "gui/icon-help.png"}, --forest02
			}
		},
		{"rpg_Forest02", "mmaps/rpg_Forest02.png", 360, 80, 1200, 1200, 651, "The Kelp Forest",
			{
				{415,  400, -650, "gui/icon-help.png"}, --forestMermog
				{1080, 930, -652, "gui/icon-help.png"}, --forest01
			}
		},
		{"rpg_Forest01", "mmaps/rpg_Forest01.png", 1080, 550, 1024, 1024, 652, "The Kelp Forest",
			{
				{2120,  1090, -655, "gui/icon-help.png"}, --mithalas
				{1190,  1360, -654, "gui/icon-help.png"}, --energyTemple01
				{1550,  710, -653, "gui/icon-help.png"}, --forestWalker
				{1035,  925, -651, "gui/icon-help.png"}, --forest02
			}
		},
		{"rpg_ForestWalker", "mmaps/rpg_ForestWalker.png", 1430, 330, 512, 512, 653, "Forest Walker",
			{
				{1590,  730, -652, "gui/icon-help.png"}, --forest01
			}
		},
		{"rpg_EnergyTemple01", "mmaps/rpg_EnergyTemple01.png", 435, 952, 900, 900, 654, "Energy Temple",
			{
				{1195,  1300, -652, "gui/icon-help.png"}, --forest01
			}
		},
		{"rpg_Mithalas01", "mmaps/rpg_Mithalas01.png", 2120, 325, 1500, 1500, 655, "Mithalas",
			{
				{2090,  1090, -652, "gui/icon-help.png"}, --forest01
				{2660,  630, -657, "gui/icon-help.png"}, --veil01
				{2880,  1010, -660, "gui/icon-help.png"}, --cathedral01
				{3180,  1495, -668, "gui/icon-help.png"}, --cathedralHome
				{3330,  1560, -662, "gui/icon-help.png"}, --openWater01
				{2250,  1400, -656, "gui/icon-help.png"}, --crystalCave
			}
		},
		{"rpg_CrystalCave", "mmaps/rpg_CrystalCave.png", 1380, 1145, 1024, 1024, 656, "Crystal Cave",
			{
				{2320,  1400, -655, "gui/icon-help.png"}, --mithalas01
			}
		},
		{"rpg_Veil01", "mmaps/rpg_Veil01.png", 2250, -50, 800, 800, 657, "Veil",
			{
				{2670,  620, -655, "gui/icon-help.png"}, --mithalas01
				{2330,  440, -658, "gui/icon-help.png"}, --veil02
				{3070,  5, -659, "gui/icon-help.png"}, --veil03
			}
		},
		{"rpg_Veil02", "mmaps/rpg_Veil02.png", 1400, -230, 1024, 1024, 658, "Veil",
			{
				{2330,  440, -657, "gui/icon-help.png"}, --veil01
			}
		},
		{"rpg_Veil03", "mmaps/rpg_Veil03.png", 2990, -690, 2048, 1024, 659, "Veil",
			{
				{3060,  15, -657, "gui/icon-help.png"}, --veil01
			}
		},
		{"rpg_Cathedral01", "mmaps/rpg_Cathedral01.png", 2700, 425, 1024, 1024, 660, "Cathedral",
			{
				{2870,  1015, -655, "gui/icon-help.png"}, --mithalas01
				{3120,  1210, -668, "gui/icon-help.png"}, --cathedralHome
			}
		},
		{"rpg_CathedralPriest", "mmaps/rpg_CathedralPriest.png", 3343, -47, 1024, 1024, 661, "Cathedral Priest",
			{
				--{3000,  120, -660, "gui/icon-help.png"}, --cathedral01_c
			}
		},
		{"rpg_OpenWater01", "mmaps/rpg_OpenWater01.png", 2460, 1430, 1400, 1400, 662, "Open Water",
			{
				{3325,  1500, -655, "gui/icon-help.png"}, --mithalas01
				{2650,  1895, -663, "gui/icon-help.png"}, --jelly miniboss
				{2860,  2800, -664, "gui/icon-help.png"}, --abyss01
			}
		},
		{"rpg_OpenWater01_MB", "mmaps/rpg_OpenWater01_MB.png", 2460, 1490, 512, 512, 663, "Open Water - MB",
			{
				{2645,  1995, -662, "gui/icon-help.png"}, --openWater01
			}
		},
		{"rpg_Abyss01", "mmaps/rpg_Abyss01.png", 2350, 2700, 1024, 1024, 664, "Abyss",
			{
				{2865,  2745, -662, "gui/icon-help.png"}, --openWater01
				{2700,  3770, -665, "gui/icon-help.png"}, --final
			}
		},
		{"rpg_Final", "mmaps/rpg_Final.png", 2450, 3550, 512, 512, 665, "Final Confrontation",
			{
				{-12,  -200, -662, "gui/icon-help.png"}, --abyss01
			}
		},
		{"rpg_Mithalas01_C", "mmaps/rpg_Mithalas01.png", 2120, 325, 1500, 1500, 666, "Mithalas Corrupted",
			{
				{2090,  1090, -652, "gui/icon-help.png"}, --forest01
				{2660,  630, -657, "gui/icon-help.png"}, --veil01
				{2880,  1010, -667, "gui/icon-help.png"}, --cathedral01_c
				{3180,  1495, -668, "gui/icon-help.png"}, --cathedralHome
				{3330,  1560, -662, "gui/icon-help.png"}, --openWater01
				{2250,  1400, -656, "gui/icon-help.png"}, --crystalCave
			}
		},
		{"rpg_Cathedral01_C", "mmaps/rpg_Cathedral01_C.png", 2700, 425, 1024, 1024, 667, "Cathedral Corrupted",
			{
				{2870,  1015, -666, "gui/icon-help.png"}, --mithalas01_c
				{3120,  1210, -668, "gui/icon-help.png"}, --cathedralHome
				{3455,  685, -661, "gui/icon-help.png"}, --cathedralPriest
			}
		},
		{"rpg_CathedralHome", "mmaps/rpg_CathedralHome.png", 2957, 1135, 512, 512, 668, "Cathedral Home",
			{
				{3020,  1455, -655, "gui/icon-help.png"}, --mithalas01
				{3120,  1145, -660, "gui/icon-help.png"}, --cathedral01
			}
		},
	}
--[[
mapArr entry format:
{ [map file name],
  [world map tile image path],
  [tile x position],
  [tile y position],
  [tile x size],
  [tile y size],
  [flag indicating that map has been entered],
  [test to display on entering map],
  {list of map markers}
}

Unexplored passage entry format:
{ [x position relative to center of map tile],
  [y position relative to center of map tile],
  [flag id for when to display the icon*],
  [path to icon image]
}

*negative flag id values mean that icon will be displayed until
 the flag is set to a non-zero value.  Note that icons in a map
 tile entry will not be displayed if the map has not been explored.
 For icons that you want to have appear regardless of whether a
 map tile has been explored, use the gemArr list.
]]--

-- Note on choice of flags:
-- The default scenario uses flags 650-669 (and 670-699 are unused) to track which maps have been explored.
-- Note: You will need to have unique entries for different versions of a map, although you may
-- use the same flags.

mmScaleFactor = 1/1
--[[
Size of world map tiles relative to the maptemplate images.
Example: if the world map tiles are 1/4 the size of the maptemplate
 images, mmScaleFactor = 1/4.
]]--


gemArr = {}
--[[
Do not modify this.  If you need to start the game with
non-map-specific icons visible, call the foundGem function
from mod-init.lua.

If there is demand during the beta test, I'll create an 
initialization function that can be used to set up an initial
global map gem list.
]]--

-- Function to call instead of pickupGem if you want a node to
-- have a gem on the world map.
-- iconname is just the name of the image in the gfx/gems folder
-- with no extension.  i.e. the image "gfx/gems/statue.png" could
-- be used by iconname = "statue".
function node_foundGem(me, iconname)
	-- debugLog("Creating gem " .. iconname .. " for node")
	-- Load the current gem array from the persistent store
	loadGemArr()
	
	-- Get the gem's location within the map.
	-- scan through mapArr to get the current map
	-- Search mapArr for the map's name
	thisMapName = string.lower(getMapName())
	for i,list in ipairs(mapArr) do
		if string.lower(list[1]) == thisMapName then
			-- use the current map's location to set the gem's location
			local eX, eY = node_getPosition(me)
			egX = eX/20*mmScaleFactor + list[3]-- -list[5]/2 -- 20 pixel map/pixel of mapTemplate
			egY = eY/20*mmScaleFactor + list[4]-- -list[6]/2
			break 
		end
	end
	
	-- Get the first empty slot in gemArr and add the new gem there
	i = 1
	while gemArr[i] ~= nil do i = i + 1 end
	gemArr[i] = {egX, egY, 0, "gems/"..iconname..".png"}
	
	-- update the persistent store.
	saveGemArr()
	
	-- Display the built-in "got a minimap gem" animation
	pickupGem(iconname)
end

-- Function to call instead of pickupGem if you want an entity to
-- have a gem on the world map.
function entity_foundGem(me, iconname)
	-- debugLog("Creating gem " .. iconname .. " for entity")
	-- Load the current gem array
	loadGemArr()
	
	-- Get the gem's location within the map.
	thisMapName = string.lower(getMapName())
	for i,list in ipairs(mapArr) do
		if string.lower(list[1]) == thisMapName then
			local eX, eY = entity_getPosition(me)
			egX = eX/20*mmScaleFactor + list[3] -- -list[5]/2
			egY = eY/20*mmScaleFactor + list[4] -- -list[6]/2
			break 
		end
	end
	
	-- Add the new gem to gemArr.
	i = 1
	while gemArr[i] ~= nil do i = i + 1 end
	gemArr[i] = {egX, egY, 0, "gems/"..iconname..".png"}
	
	-- Update the persistent store.
	saveGemArr()
	
	-- Display the built-in "got a minimap gem" animation
	pickupGem(iconname)
end

-- General function to add a gem at an arbitrary point on the map.
-- Needs global coordinates, not coordinates relative to any map.
function foundGem(x, y, flag, iconname, flashyflag)
	-- debugLog("Creating new global gem")
	-- Load the current gem array
	loadGemArr()
	
	-- Add the gem to the array
	i = 1
	while gemArr[i] ~= nil do i = i + 1 end
	gemArr[i] = {egX, egY, flag, "gems/"..iconname..".png"} -- global x,y,flag,image
	
	-- update the persistent store.
	saveGemArr()
	
	-- Display the built-in "got a minimap gem" animation if not supressed
	if flashyflag then pickupGem(iconname) end
end

-- Save the list of global gems to the persistent store
-- Mod designers should never need to call this directly
function saveGemArr()
	debugLog("Saving world map gem array\n")
	local gemLen = table.getn(gemArr)
	debugLog(gemLen)
	local saveString = "gemArr = {"
	for i,v in ipairs(gemArr) do
		saveString = saveString .. "{" .. v[1] .. "," .. v[2] .. "," .. v[3] .. ",\"" .. v[4] .. "\"}"
		if i ~= gemLen then saveString = saveString .. "," end
	end
	saveString = saveString .. "}"
	setStringFlag("gemarr", saveString)
	debugLog("Saved world map gem array\n"..saveString)
end

-- Recover the list of global gems from the persistent store
-- Mod designers should never need to call this directly
function loadGemArr()
	debugLog("Loading world map gem array")
	f = assert(loadstring(getStringFlag("gemarr")))
	f()
	debugLog("Successfully loaded world map gems")
end
	

--REMOVE GEM: need to pass node to reset node_flag
function RemoveGem(gemToRemove)
	gemToRemove = "gems/"..gemToRemove..".png"
	
	loadGemArr()
	for i, gem in ipairs(gemArr) do
		if gemToRemove == gem[4] then
			table.remove(gemArr, i)
			break
		end
	end
	saveGemArr()
end