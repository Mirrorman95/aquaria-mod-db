dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Walker/panelWalker_"
entityOther = "rpg_walker"
entityOtherScale = 0.5
gemToCreate = "walker"

flagChatBubble = DT_NEW_WALKER
flagRepeat = DT_REPEAT_WALKER
flagVersion = DT_VERSION_WALKER
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"2"								},	--next
		{"2", 				"elena",	"3a", 		"3b", 		0		},	--input
		{"3a", 				"other",	"4"								},
		{"3b", 				"other",	"4"								},
		{"4", 				"elena",	"5a", 		"5b",		0		},
		{"5a", 				"other",	"6"								},
		{"5b", 				"other",	"6"								},
		{"6", 				"elena",	"7", 		"7",		"7"		},
		{"7", 				"other",	"7e1"							},
		{"7e1", 			"other",	"8"								},
		{"8", 				"elena",	"9a", 		"9b",		0		},
		{"9a", 				"other",	"10"							},
		{"9b", 				"other",	"10"							},
		{"10", 				"elena",	"11", 		"11",		0		},
		{"11", 				"other",	"11e1"							},
		{"11e1", 			"other",	"exit"							},	--exit
		{"R", 				"other",	"exit"							}
	}
	
arrayVersion2 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"2"								},	--next
		{"2", 				"elena",	"3", 		"3", 		0		},	--input
		{"3", 				"other",	"3e1"							},
		{"3e1",				"other",	"4"								},
		{"4", 				"elena",	"5a", 		"5b",		0		},
		{"5a", 				"other",	"5e1"							},
		{"5b", 				"other",	"5e1"							},
		{"5e1", 			"other",	"5e2"							},
		{"5e2", 			"other",	"6"								},
		{"6", 				"elena",	"7a", 		0,			"7b"	},
		{"7a", 				"other",	"8"								},
		{"7b", 				"other",	"8"								},
		{"8", 				"other",	"8e1" 							},
		{"8e1", 			"other",	"exit"							},	--exit
		{"R", 				"other",	"exit"							}
	}
	
arrayVersion3 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"2"								},	--next
		{"2", 				"elena",	"3a", 		"3b", 		0		},	--input
		{"3a", 				"other",	"3e1"							},
		{"3b", 				"other",	"3e1"							},
		{"3e1",				"other",	"4"								},
		{"4", 				"elena",	"5", 		"5",		0		},
		{"5", 				"other",	"6"								},
		{"6", 				"elena",	"7a", 		"7b",		0		},
		{"7a", 				"other",	"7e1"							},
		{"7b", 				"other",	"7e1"							},
		{"7e1", 			"other",	"7e2"							},
		{"7e2", 			"other",	"8"								},
		{"8", 				"elena",	"9a",		0,			"9b"	},
		{"9a",	 			"other",	"exit"							},	--exit
		{"9b",	 			"other",	"9be1"							},
		{"9be1",			"other",	"exit"							},
	}



--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
	
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		if numPanel == "3" then
			--CS 1: create King and Krotites
			setFlag(CS_KINGSBETRAYAL, 1)
		elseif numPanel == "3e1" then
			--CS 3: Krotite vs Erulian
			setFlag(CS_KINGSBETRAYAL, 3)
		elseif numPanel == "4" then
			--CS 5: wrap it up
			setFlag(CS_KINGSBETRAYAL, 5)
		end
	--VERSION 3
	elseif isFlag(flagVersion, 3) then
		--PANEL 9A or 9BE1
		if numPanel == "9a" or numPanel == "9be1" then
			nodeClickableOnExit = false
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 11e1
		if numPanel == "11e1" then
			AlphaChatBubble()
			
			--REPEAT
			if flagRepeat ~= 0 then
				setFlag(flagRepeat, 1)
			end

			--QUEST: update flag
			if isFlag(QUEST_WALKER1, 0) then
				setFlag(QUEST_WALKER1, 1)
			end
			
			--LEARN BIND
			if isFlag(LEARNED_BIND, 0) then
				learnSong(4)
				setControlHint("You Have Learned The Bind Song!", 0, 0, 0, 8, "", 4)
				setFlag(LEARNED_BIND, 1)
				setFlag(CLICKED_NEXT, 0)
			end
		end
		
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 8e1
		if numPanel == "8e1" then
			AlphaChatBubble()
			
			--REPEAT
			if flagRepeat ~= 0 then
				setFlag(flagRepeat, 1)
			end
			
			--Restart CS if it wasn't finished
			if isFlag(CS_KINGSBETRAYAL, 2) then
				setFlag(CS_KINGSBETRAYAL, 10)
			elseif isFlag(CS_KINGSBETRAYAL, 4) then
				setFlag(CS_KINGSBETRAYAL, 20)
			elseif isFlag(CS_KINGSBETRAYAL, 6) then
				setFlag(CS_KINGSBETRAYAL, 0)
			end
			
			--UPDATE CONVERSATIONS: change to version 2
			setFlag(DT_VERSION_DRASK, 2)
			setFlag(DT_VERSION_MIA, 2)
			setFlag(DT_VERSION_RAJAH, 2)
			setFlag(DT_VERSION_NAIJA, 2)
			
			setFlag(DT_NEW_DRASK, 0)
			setFlag(DT_NEW_MIA, 0)
			setFlag(DT_NEW_RAJAH, 0)
			setFlag(DT_NEW_NAIJA, 0)
			
			setFlag(DT_REPEAT_DRASK, 0)
			setFlag(DT_REPEAT_RAJAH, 0)
		end
		
	--VERSION 3
	elseif isFlag(flagVersion, 3) then
		--PANEL 9A or 9BE1
		if numPanel == "9a" or numPanel == "9be1" then			
			AlphaChatBubble()

			--FLAG CONVERSATIONS
			setFlag(DT_VERSION_WALKER, 4)
			setFlag(DT_VERSION_DRASK, 3)
			setFlag(DT_VERSION_MIA, 3)
			setFlag(DT_VERSION_NAIJA, 3)
			
			setFlag(DT_REPEAT_DRASK, 0)

			setFlag(DT_NEW_DRASK, 0)
			setFlag(DT_NEW_MIA, 0)
			setFlag(DT_NEW_NAIJA, 0)
			
			RemoveGem("drask")
			RemoveGem("mia")
			RemoveGem("naija")
			RemoveGem("walker")
			--RemoveGem("rajah")
			--RemoveGem("oldfred")
			
			watch(2)

			--DEATH OF WALKER
			spawnParticleEffect("TinyGreenExplode", x, y)
			spawnParticleEffect("LeafExplode", x, y)
			
			spawnParticleEffect("TinyGreenExplode", x + 400, y)
			spawnParticleEffect("LeafExplode", x + 400, y)

			spawnParticleEffect("TinyGreenExplode", x + 200, y + 200)
			spawnParticleEffect("LeafExplode", x + 200, y + 200)

			entity_delete(mapEntity, 2)
			entity_delete(chatBubble, 2)
		end
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	if getFlag(flagVersion) < 4 then
		CommonInit(me)
		CreateChatBubble(x - 80, y - 120, 1)
		CreateMapEntity(entityOther, x + 310, y - 220, 0)
	end
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
	
	entity_setPosition(other, x + 670, y - 100)
end