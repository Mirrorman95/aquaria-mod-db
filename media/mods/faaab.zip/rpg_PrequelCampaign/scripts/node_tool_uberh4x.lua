dofile("scripts/entities/entityinclude.lua")

n = 0
numTimes = 3

function init(me)
	n = getNaija()
	
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function update(me, dt)
	--INVINCIBLE
	entity_setInvincible(n, true)
end

function activate(me)
	
	--FOOD
	for i=1, numTimes do
		spawnIngredient("plumpperogi", node_x(me), node_y(me))
	end
	
	--ALL SONGS
	learnSong(1)
	--learnSong(2)
	learnSong(3)
	learnSong(4)
	learnSong(5)
	learnSong(6)
	learnSong(7)
	--learnSong(8)
	learnSong(9)
	learnSong(10)
	learnSong(11)
	learnSong(12)
end