dofile("scripts/entities/entityinclude.lua")

n = 0
singDelay = 60
goBackTimer = 0
miny = 0
lx=0
ly=0
node = 0

seen = false

function init(me)
	setupEntity(me)
	entity_initSkeletal(me, "CC_GF")
		
	entity_setState(me, STATE_IDLE)
	
	entity_scale(me, 0.6, 0.6)
end

function postInit(me)
	n = getNaija()
	entity_setTarget(me, n)
	
	miny = entity_y(me)-300
end

function update(me, dt)
	if getFlag(FLAG_SUNKENCITY_PUZZLE) <= SUNKENCITY_GF then
		if entity_isState(me, STATE_IDLE) and not done then
			if goBackTimer > 0 then
				goBackTimer = goBackTimer - dt
				if goBackTimer < 0 then
					entity_setPosition(me, lx, ly, math.abs(entity_x(me)-lx)*0.003, 0, 0)
				end
			end
		end
	end
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	elseif entity_isState(me, STATE_DONE) then
		--entity_animate(me, "idle", -1)
		--debugLog("CC_GF in NON IDLE STATE")
	end
end

function exitState(me)
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end

function animationKey(me, key)
end

function hitSurface(me)
end

function songNote(me, note)
end

function songNoteDone(me, note)
end

function song(me, song)
end

function sporesDropped(me, x, y, t)
	if t ~= 0 then return end
	if not entity_isState(me, STATE_IDLE) then
		return
	end
	if not done then
		if entity_isPositionInRange(me, x, y, 700) then
			if lx==0 and ly==0 then
				lx,ly=entity_getPosition(me)
			end
			if not isObstructed(x, y-80) then
				if y > miny then
					entity_setPosition(me, x, y-128, math.abs(entity_x(me)-x)*0.005, 0, 0)
				else
					entity_setPosition(me, x, entity_y(me), math.abs(entity_x(me)-x)*0.005, 0, 0)
				end
				goBackTimer = 4
				if x >= entity_x(me) then
					if not entity_isfh(me) then	entity_fh(me) end
				else
					if entity_isfh(me) then	entity_fh(me) end
				end
				entity_animate(me, "float", -1)
			end
		end
	end
end

function activate(me)
end

