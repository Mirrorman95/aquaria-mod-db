dofile("scripts/entities/EntityInclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))


function init(me)
	node_setCursorActivation(me, false)
end
	
function activate(me)
	n = getNaija()
	avatar_fallOffWall()
	entity_idle(n)
	entity_setInvincible(n, true)
	entity_swimToNode(n, me)
	entity_watchForPath(n)
	
	entity_animate(n, "sitBack", LOOP_INF)

	overrideZoom(0.5, 2)
	watch(2)
	
	emote(EMOTE_NAIJASIGH)
	
	while (not isLeftMouse()) and (not isRightMouse()) do
		watch(FRAME_TIME)		
	end
	
	entity_idle(n)
	entity_addVel(n, 0, -200)
	overrideZoom(1, 1)
	esetv(n, EV_NOINPUTNOVEL, 0)
	watch(1)
	esetv(n, EV_NOINPUTNOVEL, 1)
	overrideZoom(0)
	entity_setInvincible(n, false)
end

function update(me, dt)
	if isFlag(DT_ACTIVE, 1) then
		node_setCursorActivation(me, false)
	else
		node_setCursorActivation(me, true)
	end
end
