dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")


function init(me)
	--node_setCursorActivation(me, false)	
end

--[[
function update(me, dt)
	if isFlag(VENDOR_ACTIVE, 1) and isFlag(VENDOR_BOUGHT_CRYSTALS_2, 0) then
		node_setCursorActivation(me, true)
	else
		node_setCursorActivation(me, false)
	end
end
]]--

function activate(me)
	if getFlag(TOTAL_CRYSTALS) < 4 then
		setControlHint("This item is locked until you have collected four large crystals.", 0, 0, 0, 8, "lightcrystal/crystal", 0, 0.5)
	elseif getFlag(CURRENCY) < 1 then
		setControlHint("You don't have any large crystals to exchange!", 0, 0, 0, 8, "lightcrystal/crystal", 0, 0.5)
	else
		purchase = confirm("Are you sure you want to purchase\nItem: 4 Small Crystals", "buy")
		if( purchase == true ) then
			setFlag(VENDOR_EXIT, 1)
			num = getFlag(CURRENCY)
			setFlag(CURRENCY, num - 1)

			setFlag(VENDOR_BOUGHT_CRYSTALS_2, 1)
			node_setCursorActivation(me, false)
		
			setFlag(CREATE_CRYSTALS_2, 1)
		end
	end
end