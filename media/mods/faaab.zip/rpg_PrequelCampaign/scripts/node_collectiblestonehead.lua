dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleStoneHead", FLAG_COLLECTIBLE_STONEHEAD)
end

function update(me, dt)
end
