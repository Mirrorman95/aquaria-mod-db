dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Scout/panelScout_"
entityOther = "merman"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = DT_NEW_SCOUT
flagRepeat = 0
flagVersion = DT_VERSION_SCOUT
flagMain = DT_MAIN_SCOUT

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3a",		"3c"	},
		{"3a", 				"other",		"3a1"							},
		{"3a1", 			"elena",		"3a1a",		"3a1a",		0		},
		{"3a1a", 			"other",		"4"								},
		{"3c", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5b",		"5c"	},
		{"5a", 				"other",		"4"								},
		{"5b", 				"other",		"4"								},
		{"5c", 				"other",		"4"								},
	}
	
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 4
		if numPanel == "4" then
			AlphaChatBubble()
			setFlag(flagMain, 1)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
				
	numPanel = "1"
	currentRowID = 1
end

--INIT
function init(me)
	if getFlag(DT_VERSION_WALKER) < 2 then
		CommonInit(me)
		CreateMapEntity(entityOther, x, y, 1)
		CreateChatBubble(x - 40, y - 90, 1)
	end
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	--IF MAIN ON THIS VERSION
	if getFlag(flagVersion) == getFlag(flagMain) then
		--VERSION 1
		if isFlag(flagMain, 1) then
			numPanel = "4"
		end
	end
	
	CommonActivate(me)
end