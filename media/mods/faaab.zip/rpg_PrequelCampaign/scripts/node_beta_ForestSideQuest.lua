dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

started 		= false
n 			= 0
timer 			= 999
thingsToSay		= 20
thingSaying		= -1
timeToSay		= 5

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
	createEntity("hintBubble", "", node_x(me), node_y(me))
end

function sayNext()
	if thingSaying == 0 then
		setControlHint("This entire map is a side quest. The Druniads habitat is being encroached upon by Mermogs. Successful defeat of the Giant Mermog (frog miniboss in game) would yield a vendor crystal + the pet.", 0, 0, 0, 13)
	elseif thingSaying == 1 then
		setControlHint("The Druniads hug you in thanks as you pass out of the map. However, upon exiting the map the Druniads are mysteriously killed.", 0, 0, 0, 10)
	elseif thingSaying == 2 then
		setControlHint("Needs coding and implementation of Mermog miniboss map.", 0, 0, 0, 8)
	end
end

function update(me, dt)
	if getStringFlag("editorhint") ~= node_getName(me) then
		started = false
		return
	end
	if started then
		timer = timer + dt
		if timer > timeToSay then
			timer = 0
			thingSaying = thingSaying + 1
			sayNext()
		end
	end
end

function activate(me)
	clearControlHint()
	started = true
	thingSaying = -1
	timer = 999
	setStringFlag("editorhint", node_getName(me))
end