dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
bigblaster = 0
checkOnce = false
blasterCleanup = false

door1_ID = 82
door2_ID = 39

function init(me)
	n = getNaija()
	spawn = getNode("bigblaster_spawn")

	door1 = getEntityByID(door1_ID)
	door2 = getEntityByID(door2_ID)

	if isFlag(BIGBLASTER, 0) then
		bigblaster = createEntity("bigblaster", "", node_x(spawn), node_y(spawn))

		entity_setState(door1, STATE_OPENED)
		entity_setState(door2, STATE_CLOSED)
	else
		entity_setState(door1, STATE_OPENED)
		entity_setState(door2, STATE_OPENED)
	end
end

function update(me, dt)
	if isFlag(BIGBLASTER, 0) and node_isEntityIn(me, n) and (checkOnce == false) then
		entity_setState(door1, STATE_CLOSE)
		checkOnce = true
	end

	if isFlag(BIGBLASTER, 1) and (blasterCleanup == false) then
		entity_setState(door1, STATE_OPEN)
		entity_setState(door2, STATE_OPEN)
		
		blasterCleanup = true
		setFlag(BIGBLASTER, 2)
	end
end