dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Events/Vision_1/panelVision01_"
entityOther = "rpg_mia"
entityOtherScale = 1.6
gemToCreate = 0

flagChatBubble = 0
flagRepeat = 0
flagVersion = DT_VERSION_VISION01
flagMain = 0

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"other",		"3"								},
		{"3", 				"other",		"4"								},
		{"4", 				"other",		"5"								},
		{"5", 				"other",		"6"								},
		{"6", 				"other",		"7"								},
		{"7", 				"other",		"7e1"							},
		{"7e1",				"other",		"8"								},
		{"8", 				"other",		"9"								},
		{"9", 				"other",		"10"							},
		{"10", 				"other",		"11"							},
		{"11", 				"other",		"exit"							},
	}
	
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 1
		if numPanel == "1" then
			--SWITCH CHARS(Elena > NaijaChild)
			ChangeLeftEntity("naijachild", 1.6, x - 675, y - 50)
			entity_color(other, 1, 1, 1, 1)
			entity_color(elena, 0.2, 0.2, 0.2, 1)
			
		--PANEL 2
		elseif numPanel == "2" then
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
		
		--PANEL 4
		elseif numPanel == "4" then
			--SWITCH CHARS(NaijaChild > EnergyGod)
			ChangeLeftEntity("templestatue", 0.8, x - 675, y +10)
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 6
		elseif numPanel == "6" then
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 8
		elseif numPanel == "8" then
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
			
		--PANEL 10
		elseif numPanel == "10" then
			entity_color(elena, 1, 1, 1, 1)
			entity_color(other, 0.2, 0.2, 0.2, 1)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 11
		if numPanel == "11" then
			if isFlag(MITHALAS_CORRUPTED, 0) then
				loadMap("rpg_cathedral01", "vendor", "l")
			else
				loadMap("rpg_cathedral01_c", "vendor", "l")
			end
		end
	end
				
	numPanel = "1"
	currentRowID = 1
end

--INIT
function init(me)
	CommonInit(me)
	CreateMapEntity(entityOther, x, y, 0)
	CreateChatBubble(x + 40, y - 80, 0)
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end