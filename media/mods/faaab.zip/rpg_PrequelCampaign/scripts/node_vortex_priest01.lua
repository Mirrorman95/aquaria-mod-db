n = 0
destination = 0

function init(me)
	n = getNaija()
	destination = getNode("vortex_priest02")
	
	node_setCursorActivation(me, true)
	loadSound("mia-appear")
	spawnParticleEffect("vortex", node_x(me), node_y(me))	
end

function update(me, dt)
end

function activate(me)
	orb = entity_getNearestEntity(n, "EnergyOrb")
	orbCracked = entity_getNearestEntity(n, "EnergyOrbCracked")
	if entity_isBeingPulled(orb) then
		entity_warpToNode(orb, destination)
	elseif entity_isBeingPulled(orbCracked) then
		entity_warpToNode(orbCracked, destination)
	end
	
	playSfx("mia-appear")
	entity_warpToNode(n, destination)
end