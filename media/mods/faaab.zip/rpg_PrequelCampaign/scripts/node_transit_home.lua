dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))


function init(me)
	node_setCursorActivation(me, false)
end

function update(me, dt)
	--SETUP
	if getFlag(TRANSTURTLE_ACTIVATE) > 0 then
		setFlag(TRANSTURTLE_ACTIVATE, getFlag(TRANSTURTLE_ACTIVATE) -1) 
		node_setCursorActivation(me, true)
	--WRAPUP
	elseif getFlag(TRANSTURTLE_DEACTIVATE) > 0 then
		setFlag(TRANSTURTLE_DEACTIVATE, getFlag(TRANSTURTLE_DEACTIVATE) -1) 
		node_setCursorActivation(me, false)
	end
end

function activate(me)
	if isMapName("rpg_CathedralHome") then
		setControlHint("You are currently in Elena's Home.", 0, 0, 0, 5, "transturtle/headicon")
	elseif isFlag(TRANSTURTLE_HOME, 1) then
		setFlag(TRANSTURTLE_GO_HOME, 1)
		setFlag(TRANSTURTLE_GO, 1)
	else
		setControlHint("You need to locate the transit turtle in Elena's Home.", 0, 0, 0, 5, "transturtle/headicon")
	end
end