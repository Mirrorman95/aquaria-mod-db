dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

n = 0
seat = 0
seat2 = 0
tame = 0
leave = 0
avatarAttached = false
liAttached = false
myFlag = 0

light1 = 0
light2 = 0

seen = false
sbank = 0


function init(me)
	n = getNaija()

	setupEntity(me, "")
	entity_initSkeletal(me, "TransTurtle")

	entity_setEntityType(me, ET_NEUTRAL)
	entity_setActivation(me, AT_CLICK, 128, 512)

	seat = entity_getBoneByName(me, "Seat")
	seat2 = entity_getBoneByName(me, "Seat2")
	tame = entity_getBoneByName(me, "Tame")
	entity_setCullRadius(me, 1024)
	
	bone_alpha(seat, 0)
	bone_alpha(seat2, 0)
	bone_alpha(tame, 0)


	if isMapName("rpg_cathedralhome") then
		myFlag = TRANSTURTLE_HOME
		sbank = "Elena's Home"
	elseif isMapName("rpg_forest01") then
		myFlag = TRANSTURTLE_FOREST01
		sbank = "The Kelp Forest"
	elseif isMapName("rpg_veil01") then
		myFlag = TRANSTURTLE_VEIL01
		sbank = "The Veil"
	elseif isMapName("rpg_openwater01") then
		myFlag = TRANSTURTLE_OPENWATER01
		sbank = "OpenWaters"
	elseif isMapName("rpg_abyss01") then
		myFlag = TRANSTURTLE_ABYSS01
		sbank = "The Abyss"
	end

	if myFlag ~= 0 and (not entity_isFlag(me, 0)) then
		setFlag(myFlag, 1)
	end
	
	
	light1 = entity_getBoneByName(me, "Light1")
	light2 = entity_getBoneByName(me, "Light2")
	
	bone_setBlendType(light1, BLEND_ADD)
	bone_setBlendType(light2, BLEND_ADD)	

	loadSound("TransTurtle-Light")
	loadSound("transturtle-takeoff")
end


function lights(me, on, t)
	a = 1
	if not on then
		a = 0
		debugLog("Lights off!")
	else
		debugLog("Lights on!")
	end
	
	bone_alpha(light1, a, t)
	bone_alpha(light2, a, t)
end


function postInit(me)
	t = entity_getNearestNode(me, "FLIP")
	if t ~= 0 and node_isEntityIn(t, me) then
		entity_fh(me)
	end

	leave = entity_getNearestNode(me, "TRANSTURTLELEAVE")
	
	if isFlag(myFlag, 0) then
		lights(me, false, 0)
	else
		-- turn on ze lights
		lights(me, true, 0)
	end
		
	if sbank ~= 0 then
		if entity_isEntityInRange(me, n, 600) then
			--centerText(getStringBank(sbank))
			centerText(sbank)
		end
	end

	-- if naija starts on a turtle, ignore the seen/hint
	if entity_isEntityInRange(me, n, 350) then
		seen = true
	end
end


function update(me, dt)
	--[[if entity_isFlag(me, 0) then
		entity_setActivationType(me, AT_NONE)
	else
		entity_setActivationType(me, AT_CLICK)
	end]]--

	if isFlag(TRANSTURTLE_ACTIVE, 1) then
		entity_setActivationType(me, AT_NONE)
	else
		entity_setActivationType(me, AT_CLICK)
	end


	if isFlag(TRANSTURTLE_EXIT, 1) then
		setFlag(TRANSTURTLE_EXIT, 0)
		setFlag(TRANSTURTLE_DEACTIVATE, 5)
		
		entity_delete(menu, 1)
		entity_setInvincible(n, false)
		enableInput()
		overrideZoom(0)
		cam_toEntity(n)	
	end	

	if avatarAttached then
		--entity_flipToSame(n, me)
		x,y = bone_getWorldPosition(seat)
		entity_setRidingData(me, x, y, 0, entity_isfh(me))
	end

	if liAttached then
		x,y = bone_getWorldPosition(seat2)
		entity_setPosition(li, x, y)
		entity_rotate(li, entity_getRotation(me))
		if entity_isfh(me) and not entity_isfh(li) then
			entity_fh(li)
		elseif not entity_isfh(me) and entity_isfh(li) then
			entity_fh(li)
		end
	end
	
	if entity_isEntityInRange(me, n, 300) then
		if not seen then
			emote(EMOTE_NAIJAWOW)
			if anyOtherFlag() then
				setControlHint(getStringBank(226), 0, 0, 0, 5, "transturtle/headicon")
			else
				setControlHint(getStringBank(225), 0, 0, 0, 5, "transturtle/headicon")
			end
		seen = true
		end
	end
	
	if isNested() then return end

	if entity_isEntityInRange(me, n, 300) and (not isFlag(myFlag, 1) or entity_isFlag(me, 0)) and entity_isUnderWater(n) then
		entity_idle(n)
		entity_setInvincible(n, true)
		entity_flipToEntity(n, me)
		cam_toEntity(me)
		watch(1.5)
		playSfx("TransTurtle-Light")
		lights(me, true, 1.5)
		watch(2)
		cam_toEntity(n)
		watch(1)
		setFlag(myFlag, 1)

		--GEM
		if getNode("mm_flagmap") ~= 0 then
			entity_foundGem(me, "Turtle")
		end
		
		entity_setFlag(me, 1)
	end
	
	
	if isFlag(TRANSTURTLE_GO, 1) then
		--if entity_isFlag(me, 0) then return end
	
		--[[if entity_getRiding(getNaija())~=0 then
			return
		end]]--	
	
		if anyOtherFlag() then
			setFlag(TRANSTURTLE_ACTIVE, 0)
			playSfx("recipemenu-close")
			entity_delete(menu)
		
			if isFlag(TRANSTURTLE_FIRST, 0) then
				setFlag(TRANSTURTLE_FIRST, 1)
				
				x,y = bone_getWorldPosition(tame)
				entity_swimToPosition(n, x, y)
				entity_watchForPath(n)
				entity_flipToEntity(n, me)
				entity_animate(n, "tameTurtle", 0, LAYER_UPPERBODY)
				entity_animate(me, "tame")
		
				while entity_isAnimating(me) do
					watch(FRAME_TIME)
				end

				entity_idle(n)
				entity_animate(me, "idle")
				watch(0.5)
			end

			li = 0
			if hasLi() then
				li = getLi()
				if entity_isEntityInRange(n, li, 512) then
				else
					fade2(1, 0.2, 1, 1, 1)
					watch(0.2)
					entity_setPosition(li, entity_x(n), entity_y(n))
					fade2(0, 0.5)
					watch(0.5)
				end
			end

			x,y = bone_getWorldPosition(seat)

			entity_swimToPosition(n, x, y)
			entity_watchForPath(n)
			entity_animate(n, "rideTurtle", -1)
			avatarAttached = true
	
			if entity_isfh(me) and not entity_isfh(n) then
				entity_fh(n)
			elseif not entity_isfh(me) and entity_isfh(n) then
				entity_fh(n)
			end


			if li ~= 0 then
				debugLog("here!")
				entity_setState(li, STATE_PUPPET, -1, 1)
				x2,y2 = bone_getWorldPosition(seat2)
				entity_swimToPosition(li, x2, y2)
				entity_watchForPath(li)
				entity_animate(li, "rideTurtle", -1)
				liAttached = true
				entity_setRiding(li, me)
			end
		
	
			entity_setRiding(n, me)
			overrideZoom(0.75, 1.5)
			entity_animate(me, "swimPrep")
	
			while entity_isAnimating(me) do
				watch(FRAME_TIME)
			end
		
			entity_moveToNode(me, leave, SPEED_FAST)
			entity_animate(me, "swim", -1)
			playSfx("transturtle-takeoff")
			watch(1)
			fade(1, 1)
			watch(1)

			setFlag(TRANSTURTLE_GO, 0)
			
			if isFlag(TRANSTURTLE_GO_HOME, 1) then
				setFlag(TRANSTURTLE_GO_HOME, 0)
				warpNaijaToSceneNode("rpg_CathedralHome", "TRANSTURTLE")
			elseif isFlag(TRANSTURTLE_GO_FOREST01, 1) then
				setFlag(TRANSTURTLE_GO_FOREST01, 0)
				warpNaijaToSceneNode("rpg_Forest01", "TRANSTURTLE")
			elseif isFlag(TRANSTURTLE_GO_VEIL01, 1) then
				setFlag(TRANSTURTLE_GO_VEIL01, 0)
				warpNaijaToSceneNode("rpg_Veil01", "TRANSTURTLE")
			elseif isFlag(TRANSTURTLE_GO_OPENWATER01, 1) then
				setFlag(TRANSTURTLE_GO_OPENWATER01, 0)
				warpNaijaToSceneNode("rpg_OpenWater01", "TRANSTURTLE")
			elseif isFlag(TRANSTURTLE_GO_ABYSS01, 1) then
				setFlag(TRANSTURTLE_GO_ABYSS01, 0)
				warpNaijaToSceneNode("rpg_Abyss01", "TRANSTURTLE")
			end			
		end
	end	
end


function isOtherFlag(flag)
	return (myFlag ~= flag and isFlag(flag, 1))
end


function anyOtherFlag()
	if isOtherFlag(TRANSTURTLE_HOME, 1) then
		return true
	elseif isOtherFlag(TRANSTURTLE_FOREST01, 1) then
		return true
	elseif isOtherFlag(TRANSTURTLE_VEIL01, 1) then
		return true
	elseif isOtherFlag(TRANSTURTLE_OPENWATER01, 1) then
		return true
	elseif isOtherFlag(TRANSTURTLE_ABYSS01, 1) then
		return true
	end
	return false
end


function activate(me)
	if anyOtherFlag() then
		setFlag(TRANSTURTLE_ACTIVE, 1)
		setFlag(TRANSTURTLE_ACTIVATE, 5)

		overrideZoom(0.52)
		cam_toEntity(me)
		--cam_setPosition(me)
		entity_setInvincible(n, true)
		entity_setPosition(n, entity_x(me), entity_y(me))
		disableInput()
		toggleCursor(true, 0.1)

		playSfx("recipemenu-open")
		menu = createEntity("transitMenu", "", entity_x(me), entity_y(me) - 1000)
		entity_setPosition(menu, entity_x(menu), entity_y(menu) + 800, 1.5)
	end
end


function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "idle", -1)
	end
end