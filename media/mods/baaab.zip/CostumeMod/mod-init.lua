dofile("scripts/entities/entityinclude.lua")

function init()
	loadMap("modtest")
end
