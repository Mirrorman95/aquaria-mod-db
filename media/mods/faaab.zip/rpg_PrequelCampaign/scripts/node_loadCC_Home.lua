dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if node_isEntityIn(me, n) then
		if isFlag(MITHALAS_CORRUPTED, 0) then
			warpNaijaToSceneNode("rpg_Cathedral01", "bottom", "r")
		elseif isFlag(MITHALAS_CORRUPTED, 1) then
			warpNaijaToSceneNode("rpg_Cathedral01_C", "bottom", "r")
		end
	end
end