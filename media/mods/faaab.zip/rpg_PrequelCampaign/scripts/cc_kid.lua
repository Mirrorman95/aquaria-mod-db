dofile("scripts/entities/entityinclude.lua")

-- throw rocks
n = 0
function init(me)
	setupEntity(me)
	entity_initSkeletal(me, "CC_Kid")
		
	entity_setState(me, STATE_IDLE)
	
	entity_scale(me, 0.6, 0.6)
	
	entity_setBeautyFlip(me, false)	
end

function postInit(me)
	n = getNaija()
	entity_setTarget(me, n)
	--entity_fh(me)	
end

function update(me, dt)
end

function enterState(me)
	if entity_isState(me, STATE_IDLE) then
		entity_animate(me, "throwing", -1)
		--entity_update(me, math.random(100)/100.0)
	elseif entity_isState(me, STATE_TRANSFORM) then
		entity_setStateTime(me, entity_animate(me, "transform"))
	end
end

function exitState(me)
	if entity_isState(me, STATE_TRANSFORM) then
		e = createEntity("Scavenger", "", entity_x(me), entity_y(me))
		entity_setState(e, STATE_GROW, -1, 1)
		entity_alpha(e, 0)
		entity_alpha(e, 1, 0.5)
		entity_delete(me, 0.5)
	end
end

function damage(me, attacker, bone, damageType, dmg)
	return false
end

function animationKey(me, key)
end

function hitSurface(me)
end

function songNote(me, note)
end

function songNoteDone(me, note)
end

function song(me, song)
end

function sporesDropped(me, x, y)
end

function activate(me)
end

