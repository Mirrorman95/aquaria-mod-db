dofile("scripts/include/sealtemplate.lua")

function init(me)
	commonInit(me, "Seal-Queen", FLAG_SEAL_QUEEN)
end
