--[[ 
DIALOGUE TREE CODE: by Danny O'Connell (http:://doconnell.wordpress.com)
The following functions are used for creating, updating, and clearing dialogue trees 
This file is called by "node_dt_brain" files
]]--

dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))

n = 0
elena = 0
other = 0
lastOther = 0
mapEntity = 0

panel = 0
panel_bg = 0
next = 0
exit = 0
chatBubble = 0

x = 0
y = 0

numPanel = "1"
firstPanel = true
currentRowID = 1
arrayDT = {}



--CREATE MAP ENTITY: places entity (character) seen in map
function CreateMapEntity(entity, xPlacement, yPlacement, flip)
	if entity ~= 0 then
		mapEntity = createEntity(entity, "", xPlacement, yPlacement)
		
		--flip on horizontal axis?
		if flip == 1 then
			entity_fh(mapEntity)
		end
	end
end


--CREATE CHAT BUBBLE: places a chat bubble graphic near the map entity to show that the entity can be talked to
function CreateChatBubble(xPlacement, yPlacement, flip)
	chatBubble = createEntity("symbol_chatbubble", "", xPlacement, yPlacement)
	
	--flip on horizontal axis?
	if flip == 1 then
		entity_fh(chatBubble)
	end
	
	--is there a global flag for this particular entity?
	if flagChatBubble ~= 0 then
		--if the player has talked to this entity before fade the chat bubble out
		if not isFlag(flagChatBubble, 0) then
			entity_alpha(chatBubble, 0.25)
		end
	end
end


--ALPHA CHAT BUBBLE: fades out the chat bubble once the player has talked to the entity
function AlphaChatBubble()
	--is there a global flag for this particular entity?
	if isFlag(flagChatBubble, 0) then
		setFlag(flagChatBubble, 1)
		entity_alpha(chatBubble, 0.25, 1)
	end
end
			
			
--WORLD MAP GEM: places a gem (graphic) on the world map for this entity
function WorldMapGem(me)
	--is the avatar located inside this node?
	if node_isEntityIn(me, n) then
		if gemToCreate ~= 0 and node_isFlag(me, 0) then
			node_foundGem(me, gemToCreate)
			node_setFlag(me, 1)
		end
	end
end


--COMMONT INIT: sets basic values when the map is being built
function CommonInit(me)
	n = getNaija()
	x = node_x(me)
	y = node_y(me)
	
	--global flag values default to 0 but DTs are built around reading 1+
	if getFlag(flagVersion) == 0 then
		setFlag(flagVersion, 1)
	end
	
	node_setCursorActivation(me, true)
	imagePath = imagePath .. "v" .. getFlag(flagVersion) .. "_"
end


--COMMON UPDATE
function CommonUpdate(me, dt)	
	--WORLD MAP GEM: if a gem is available
	WorldMapGem(me)
	
	--NODE: is this DT engaged?
	if nodeActive == true then
		
		--EXIT
		if isFlag(DT_EXIT, 1) then
			nodeActive = false
			
			--can this entity be talked to again?
			if nodeClickableOnExit then
				node_setCursorActivation(me, true)
			end
			
			--clean up our mess so that the game can resume
			WrapupDT()
			
		--CLICKED BUTTON: this code checks to see if the player clicked a button 
		elseif isFlag(CLICKED_NEXT, 1) or isFlag(CLICKED_OPTION1, 1) or isFlag(CLICKED_OPTION2, 1) or isFlag(CLICKED_OPTION3, 1) then
			UpdateDT()
		end
	end
end


--COMMON ACTIVATE: player clicked the entity to begin a conversation
function CommonActivate(me)
	
	--CREATE FIRST PANEL
	if nodeActive == false then
		nodeActive = true
		node_setCursorActivation(me, false)
		
		--PASS CORRECT ARRAY
		if isFlag(flagVersion, 1) then
			SetupDT(arrayVersion1)
		elseif isFlag(flagVersion, 2) then
			SetupDT(arrayVersion2)
		elseif isFlag(flagVersion, 3) then
			SetupDT(arrayVersion3)
		end
		
		UpdateDT()
	end
end


--UPDATE DIALOGUE TREE
function UpdateDT()	
	
	--EXIT
	if firstPanel == false and LegitExit() == true then		
		setFlag(CLICKED_NEXT, 0)
		setFlag(CLICKED_OPTION1, 0)
		setFlag(CLICKED_OPTION2, 0)
		setFlag(CLICKED_OPTION3, 0)
		
		setFlag(DT_EXIT, 1)
		
	--MAKE THE NEXT PANEL
	else	
		firstPanel = false
		
		--ADVANCE PANEL: clicked button next
		if isFlag(CLICKED_NEXT, 1) then
			numPanel = arrayDT[currentRowID][3]
			
		--ADVANCE PANEL: clicked option 1
		elseif isFlag(CLICKED_OPTION1, 1) then
			numPanel = arrayDT[currentRowID][3]
			
		--ADVANCE PANEL: clicked option 2
		elseif isFlag(CLICKED_OPTION2, 1) then
			numPanel = arrayDT[currentRowID][4]
			
		--ADVANCE PANEL: clicked option 3
		elseif isFlag(CLICKED_OPTION3, 1) then
			numPanel = arrayDT[currentRowID][5]
		end
		
		setFlag(CLICKED_NEXT, 0)
		setFlag(CLICKED_OPTION1, 0)
		setFlag(CLICKED_OPTION2, 0)
		setFlag(CLICKED_OPTION3, 0)
	
		UpdateCurrentRowID()
		CreatePanel()
		ButtonsAndCharacters()
		ActionPanel()
	end
end

--LEGIT EXIT: returns true that an exit matches with a player's button click
function LegitExit()
	if arrayDT[currentRowID][3] == "exit" and ( isFlag(CLICKED_NEXT, 1) or isFlag(CLICKED_OPTION1, 1) ) then
		return true
	elseif arrayDT[currentRowID][4] == "exit" and isFlag(CLICKED_OPTION2, 1) then
		return true
	elseif arrayDT[currentRowID][5] == "exit" and isFlag(CLICKED_OPTION3, 1) then
		return true
	else
		return false
	end
end


--UPDATE CURRENT ROW ID: find row number for current panel
function UpdateCurrentRowID()
	for i,v in ipairs(arrayDT) do
		if numPanel == arrayDT[i][1] then
			currentRowID = i
			break
		end
	end
end


--CREATE PANEL: a PNG image of text
function CreatePanel()
	if panel ~= 0 then
		quad_delete(panel)
	end
	
	panel = createQuad(imagePath .. numPanel)
	quad_setPosition(panel, x, y)
	quad_scale(panel, 1.25, 1.25)
	quad_alpha(panel, 0)
	quad_alpha(panel, 1, 1.5)
end


--BUTTONS AND CHARACTERS: adjust character colors and setup buttons that can be clicked
function ButtonsAndCharacters()

	--ELENA
	if arrayDT[currentRowID][2] == "elena" then
		entity_color(elena, 1, 1, 1, 1)
		entity_color(other, 0.2, 0.2, 0.2, 1)
		entity_alpha(next, 0, 1.5)
		
		--OPTION 1
		if arrayDT[currentRowID][3] ~= 0 then
			setFlag(DT_OPTION1, 1)
		end
		
		--OPTION 2
		if arrayDT[currentRowID][4] ~= 0 then
			setFlag(DT_OPTION2, 1)
		end
		
		--OPTION 3
		if arrayDT[currentRowID][5] ~= 0 then
			setFlag(DT_OPTION3, 1)
		end
		
	--OTHER
	else	
		entity_color(other, 1, 1, 1, 1)
		entity_color(elena, 0.2, 0.2, 0.2, 1)
		entity_alpha(next, 1, 1.5)
		
		setFlag(DT_NEXT, 1)
	end
end


--CHANGE LEFT ENTITY: this is called if there is a new entity talking on the left side of the DT
function ChangeLeftEntity(ent, scale, xPlacement, yPlacement)
	entity_delete(elena)
	elena = createEntity(ent, "", xPlacement, yPlacement)
	entity_scale(elena, scale, scale)
end


--CHANGE RIGHT ENTITY: this is called if there is a new entity talking on the right side of the DT
function ChangeRightEntity(ent, scale, xPlacement, yPlacement)
	entity_delete(other)
	other = createEntity(ent, "", xPlacement, yPlacement)
	entity_scale(other, scale, scale)
end


--SETUP DT: removes control from the player and creates the basic structure of the DT
function SetupDT(array)
	panel = 0
	arrayDT = array
	DealWithSeahorse()
	
	setFlag(DT_ACTIVE, 1)
	
	avatar_fallOffWall() 
	playSfx("recipemenu-open")
	overrideZoom(0.52)

	cam_setPosition(x, y)
	entity_setInvincible(n, true)
	entity_alpha(n, 0, 1.0)
	entity_setPosition(n, x, y)
	disableInput()
	toggleCursor(true, 0.1)

	--PANEL BG
	panel_bg = createEntity("panel_bg", "", x, y)
	entity_alpha(panel_bg, 1, 1.5)	
	
	--ELENA: entity on left
	elena = createEntity("rpg_elena", "", x - 675, y - 50)
	entity_scale(elena, 1.6, 1.6)
	
	--OTHER: entity on right
	other = createEntity(entityOther, "", x + 670, y - 40)
	entity_scale(other, entityOtherScale, entityOtherScale)
	
	--BUTTON: next
	next = createEntity("panel_next", "", x + 550, y + 90)
	entity_alpha(next, 1, 1.5)

	--BUTTON: exit
	exit = createEntity("panel_exit", "", x + 750, y - 120)
	entity_alpha(exit, 1, 1.5)
	
	--if the DT has a Repeat (that is flagged) it displays that instead of panel 1
	if flagRepeat ~= 0 then
		if getFlag(flagRepeat) == getFlag(flagVersion) then
			numPanel = "R"
			
			UpdateCurrentRowID()
			CreatePanel()
			ButtonsAndCharacters()
			ActionPanel()
		end
	end
end


--DEAL WITH SEAHORSE: all seahorse entities are sent a msg and throw Elena off if riding == true
function DealWithSeahorse()
	ent = getFirstEntity()
	while ent ~= 0 do
		if entity_getName(ent) == "Seahorse" then
			entity_msg(ent, "DialogueTree")
		end		
		ent = getNextEntity()
	end
end


--WRAPUP DT: clean up flags/graphics and return control to the player
function WrapupDT()	
	firstPanel = true
	
	setFlag(DT_ACTIVE, 0)

	setFlag(DT_EXIT, 0)
	setFlag(DT_NEXT, 0)
	setFlag(DT_OPTION1, 0)
	setFlag(DT_OPTION2, 0)
	setFlag(DT_OPTION3, 0)
			
	entity_setInvincible(n, false)
	enableInput()
	entity_alpha(n, 1.0)
	overrideZoom(0)

	if panel ~= 0 then
		quad_delete(panel, 1)
	end
	
	entity_delete(elena, 1)
	entity_delete(other, 1)
	entity_delete(panel_bg, 1)
	entity_delete(next, 1)
	entity_delete(exit, 1)	
	
	cam_toEntity(n)
	
	ActionExit()
end