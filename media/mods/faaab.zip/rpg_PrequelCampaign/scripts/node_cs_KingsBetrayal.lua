dofile("scripts/entities/entityinclude.lua")	
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
tempVar = 0

KROTITE_HOTEL = {}
king = 0
krotiteVSErulian = 0

spawn1 = 0
spawn2 = 0
spawn3 = 0
spawn4 = 0

function init(me)
	n = getNaija()

	--creates Krotite entities
	if isFlag(CS_KINGSBETRAYAL, 0) then
		spawn1 = getNode("SPAWN1")
		spawn2 = getNode("SPAWN2")
		spawn3 = getNode("SPAWN3")
		spawn4 = getNode("SPAWN4")
	end

	--node_setCursorActivation(me, true)
end


function update(me, dt)
--CS: king watches Krotites on journey 
	if isFlag(CS_KINGSBETRAYAL, 1) then
		setFlag(CS_KINGSBETRAYAL, 2)

		setSceneColor(0.5, 0.5, 1, 2)

		king = createEntity("rpg_king", "", node_x(me), node_y(me))
	
		tempVar = createEntity("krotiteontheway", "", node_x(spawn1), node_y(spawn1))
		entity_rotate(tempVar, 145, 0)
		entity_fh(tempVar)
		table.insert(KROTITE_HOTEL, tempVar)

		tempVar = createEntity("krotiteontheway", "", node_x(spawn2), node_y(spawn2))
		entity_rotate(tempVar, 145, 0)
		entity_fh(tempVar)
		table.insert(KROTITE_HOTEL, tempVar)

		tempVar = createEntity("krotiteontheway", "", node_x(spawn3), node_y(spawn3))
		entity_rotate(tempVar, 145, 0)
		entity_fh(tempVar)
		table.insert(KROTITE_HOTEL, tempVar)

		tempVar = createEntity("krotiteontheway", "", node_x(spawn4), node_y(spawn4))
		entity_rotate(tempVar, 145, 0)
		entity_fh(tempVar)
		table.insert(KROTITE_HOTEL, tempVar)

--CS: king watches krotite kill erulians
	elseif isFlag(CS_KINGSBETRAYAL, 3) then
		setFlag(CS_KINGSBETRAYAL, 4)

		for i=1, #KROTITE_HOTEL do
			entity_delete(KROTITE_HOTEL[i], 1)
			KROTITE_HOTEL[i] = nil
		end
		
		krotiteVSErulian = createEntity("krotiteerulianbattle01", "", node_x(spawn2), node_y(spawn2))
		entity_setState(krotiteVSErulian, STATE_ON)

--CLEANUP: cutscene finished
	elseif isFlag(CS_KINGSBETRAYAL, 5) then
		setFlag(CS_KINGSBETRAYAL, 6)
		setSceneColor(1, 1, 1, 2)

		entity_delete(krotiteVSErulian, 1)
		entity_delete(king, 1)




--CLEANUP: cutscene was not finished. exited at flag: 2
	elseif isFlag(CS_KINGSBETRAYAL, 10) then
		setFlag(CS_KINGSBETRAYAL, 0)

		setSceneColor(1, 1, 1, 2)
		entity_delete(king, 1)

		for i=1, #KROTITE_HOTEL do
			entity_delete(KROTITE_HOTEL[i], 1)
			KROTITE_HOTEL[i] = nil
		end

--CLEANUP: cutscene was not finished. exited at flag: 4
	elseif isFlag(CS_KINGSBETRAYAL, 20) then
		setFlag(CS_KINGSBETRAYAL, 0)
		
		setSceneColor(1, 1, 1, 2)

		entity_delete(krotiteVSErulian, 1)
		entity_delete(king, 1)
	end
end


--[[ DEBUG TOOL
function activate(me)
	setFlag(CS_KINGSBETRAYAL, 0)
	setControlHint("FLAG (CS_KINGSBETRAYAL) = " .. getFlag(CS_KINGSBETRAYAL),  0, 0, 0, 5, "")
end
]]--