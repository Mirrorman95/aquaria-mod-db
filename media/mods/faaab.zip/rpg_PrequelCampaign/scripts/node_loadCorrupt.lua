dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if node_isEntityIn(me, n) then
		if isMapName("rpg_forest01") and isFlag(MITHALAS_CORRUPTED, 0) then
			warpNaijaToSceneNode("rpg_Mithalas01", "left", "r")
		elseif isMapName("rpg_forest01") and isFlag(MITHALAS_CORRUPTED, 1) then
			warpNaijaToSceneNode("rpg_Mithalas01_C", "left", "r")
		end

		if isMapName("rpg_veil01") and isFlag(MITHALAS_CORRUPTED, 0) then
			warpNaijaToSceneNode("rpg_Mithalas01", "topmiddle", "l")
		elseif isMapName("rpg_veil01") and isFlag(MITHALAS_CORRUPTED, 1) then
			warpNaijaToSceneNode("rpg_Mithalas01_C", "topmiddle", "l")
		end

		if isMapName("rpg_openwater01") and isFlag(MITHALAS_CORRUPTED, 0) then
			warpNaijaToSceneNode("rpg_Mithalas01", "bottomright", "l")
		elseif isMapName("rpg_openwater01") and isFlag(MITHALAS_CORRUPTED, 1) then
			warpNaijaToSceneNode("rpg_Mithalas01_C", "bottomright", "l")
		end

		if isMapName("rpg_crystalcave") and isFlag(MITHALAS_CORRUPTED, 0) then
			warpNaijaToSceneNode("rpg_Mithalas01", "bottomleft", "r")
		elseif isMapName("rpg_crystalcave") and isFlag(MITHALAS_CORRUPTED, 1) then
			warpNaijaToSceneNode("rpg_Mithalas01_C", "bottomleft", "r")
		end
	end
end