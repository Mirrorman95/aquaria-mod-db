dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_vortex.lua"))

strDestination = "vortex_veil03_2c"

function init(me)
	commonInit(me, strDestination)
end

function update(me, dt)
end

function activate(me)
	commonActivate(me)
	spawnParticleEffect("MiaWarp", node_x(destination), node_y(destination))
end