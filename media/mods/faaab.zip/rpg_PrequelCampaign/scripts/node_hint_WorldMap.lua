dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)
	if isFlag(HINT_WORLDMAP, 0) and node_isEntityIn(me, n) then
		setFlag(HINT_WORLDMAP, 1)
		
		setControlHint("[DOUBLE CLICK] the minimap to access the world map.\n{LEFT MOUSE DRAG] to move and [RIGHT CLICK] to exit.", 0, 0, 0, 10)
	end
end