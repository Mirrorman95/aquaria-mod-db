dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleGear", FLAG_COLLECTIBLE_GEAR)
end

function update(me, dt)
end
