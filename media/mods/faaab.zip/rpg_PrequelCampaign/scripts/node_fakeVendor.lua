dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))


function init(me)
	node_setCursorActivation(me, true)
	loadSound ("gateway-die")
	createEntity("symbol_treasure", "", node_x(me), node_y(me) - 250)
end


function update(me, dt)
end

function activate(me)
	playSfx("gateway-die")
	createEntity("nightmare_M", "", node_x(me), node_y(me))
	createEntity("nightmare_M", "", node_x(me), node_y(me))
end