dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

n = 0
skull = 0

function init(me)
	n = getNaija()

	if isFlag(FLAG_COLLECTIBLE_SKULL, 0) then
		skull = createEntity("rpg_skull", "", node_x(me), node_y(me))
		entity_rotate(skull, 45, 0, 0)
	end
end

function update(me, dt)
	if isFlag(DT_VERSION_WALKER, 1) and node_isEntityIn(me, n) then
		setFlag(DT_VERSION_WALKER, 2)
		setFlag(DT_REPEAT_WALKER, 0)
		setFlag(DT_NEW_WALKER, 0)
		
		setFlag(QUEST_WALKER1, 2)
		setFlag(FLAG_COLLECTIBLE_SKULL, 1)
	
		entity_idle(n)
		cam_toNode(me)
		
		overrideZoom(1.2, 7)
		musicVolume(0.1, 3)
		setSceneColor(1, 0.9, 0.5, 3)
			
		spawnParticleEffect("treasure-glow", node_x(me), node_y(me))
		playSfx("low-note1", 0, 0.4)
		playSfx("low-note5", 0, 0.4)

		watch(3)

		entity_setPosition(skull, node_x(me), node_y(me) - 100, 3, 0, 0, 1)
		entity_scale(skull, 1.2, 1.2, 3)
		playSfx("Collectible")

		watch(3)			

		playSfx("secret", 0, 0.5)
		cam_toEntity(n)
		
		musicVolume(1, 2)
		setSceneColor(1, 1, 1, 1)
		overrideZoom(0)
		
		entity_delete(skull, 0, 1)
		spawnParticleEffect("Collect", node_x(me), node_y(me))

		setControlHint("The skull of a once great great Mithalan. Return this artifact to the Walker.", 0, 0, 0, 8)
	end
end