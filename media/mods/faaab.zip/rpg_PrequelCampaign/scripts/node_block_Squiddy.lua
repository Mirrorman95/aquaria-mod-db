--[[ 
BLOCK PC CODE: by Danny O'Connell (vxnervegas [at] gmail [dot] com)
This code blocks the PC from further progression until receiving the 2nd quest from Drask.
One panel of dialog is shown. When Drask gives the PC the 2nd quest this script shows Squiddy leaving.
]]--

dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))
dofile("scripts/entities/entityinclude.lua")

imagePath = "panels/Squiddy/panelSquiddy_"
entityOther = "rpg_Squiddy"
entityOtherScale = 1.7
gemToCreate = 0

flagChatBubble = 0
flagRepeat = 0
flagVersion = DT_VERSION_SQUIDDY
flagMain = 0

nodeActive = false
nodeClickableOnExit = false
engaged = false


arrayVersion1 = 
	{
		--current panel		talking 	possible destination panels				
		{"1", 				"other", 	"exit"							},	--next
	}


--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 1
		if numPanel == "1" then
			
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		engaged = false
		entity_setPosition(n, x, y + 200)
		
		s = createShot("EnemyInk", mapEntity, n, entity_x(mapEntity), entity_y(mapEntity))
		shot_setAimVector(s, 0, 1)
	end
				
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	node_setCursorActivation(me, false)

	--CUTSCENE: squiddy leaves the area allowing the PC to progress	
	if isFlag(QUEST_DRASK2, 2) then
		setFlag(QUEST_DRASK2, 3)
	
		CreateMapEntity(entityOther, x, y, 0)
	
		entity_setPosition(n, 0, 0)
		overrideZoom(0.5)
		cam_toNode(me)
		watch(1)
		fade(0, 5, 0, 0, 0)

		setControlHint("Old Fred awaits you Elena.",  0, 0, 0, 6, "squiddy", 0, 0.5)
		watch(2)

		entity_followPath(mapEntity, me, SPEED_VERYSLOW, 0)
		watch(5)

		fade(1,4)
		watch(3.5)

		warpNaijaToSceneNode("rpg_cathedral01", "dt_brainDrask", "l")
		
	--STATIC SQUID: create visual
	elseif isFlag(QUEST_DRASK2, 0) then
		CreateMapEntity(entityOther, x, y, 0)
		--CreateChatBubble(x + 50, y - 100, 0)
	end
end

--UPDATE
function update(me, dt)
	--CONVERSATION: starts conversation telling the PC that they cannot progress
	if node_isEntityIn(me, n) and not engaged and isFlag(QUEST_DRASK2, 0) then
		engaged = true
		CommonActivate(me)
	end
	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end