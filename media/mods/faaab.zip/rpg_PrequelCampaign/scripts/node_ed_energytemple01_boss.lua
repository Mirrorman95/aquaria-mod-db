dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 78
holderID = 63
flag = ED_ENERGYTEMPLE01_BOSS

dofile("scripts/include/energyslottemplate.lua")