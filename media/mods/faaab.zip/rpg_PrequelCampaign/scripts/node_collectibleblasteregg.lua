dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleBlasterEgg", FLAG_COLLECTIBLE_BLASTEREGG)
end

function update(me, dt)
end
