dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

function init(me)
	if isFlag(QUEST_DRASK1, 1) then
		node = node_getNearestNode(me, "current 600 0.4")
		if node ~= 0 then
			node_setActive(node, false)
		end
	end
end


--not supported?
--node = getNearestNodeByType(node_x(me), node_y(me), PATH_CURRENT)