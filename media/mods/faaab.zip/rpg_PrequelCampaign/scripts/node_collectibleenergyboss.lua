dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleEnergyBoss", FLAG_COLLECTIBLE_ENERGYBOSS)
end

function update(me, dt)
end
