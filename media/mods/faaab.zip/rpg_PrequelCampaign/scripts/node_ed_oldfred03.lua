dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 12
holderID = 4
flag = ED_OLDFRED_03

dofile("scripts/include/energyslottemplate.lua")