dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0

mithala = 0
eric = 0
theCreator = 0


function init(me)	
	n = getNaija()
	mithala = node_getNearestEntity(me, "rpg_mithalangod")
	eric = node_getNearestEntity(me, "rpg_eric")
	theCreator = node_getNearestEntity(me, "creatorform1")
	
	if isFlag(FINAL_CONFRONTATION, 2) then
		entity_alpha(mithala, 0, 2)
	elseif isFlag(FINAL_CONFRONTATION, 4) then
		entity_alpha(mithala, 0, 2)
		entity_alpha(eric, 0, 2)
		entity_alpha(theCreator, 0, 2)
	end
end


function update(me, dt)
end


function activate(me)
	disableInput()
	
	watch(1)

	overrideZoom(0.45)
		
	--PORT OUT: mithala
	if isFlag(FINAL_CONFRONTATION, 1) then
		setFlag(FINAL_CONFRONTATION, 2)
		
		cam_toEntity(mithala)

		watch(1)
	
		spawnParticleEffect("MiaWarp", entity_x(mithala), entity_y(mithala))
		playSfx("mia-appear")

		entity_alpha(mithala, 0, 2)		

	--PORT OUT: eric and creator
	elseif isFlag(FINAL_CONFRONTATION, 3) then
		setFlag(FINAL_CONFRONTATION, 4)

		cam_toEntity(eric)

		watch(1)

		spawnParticleEffect("MiaWarp", entity_x(eric), entity_y(eric))
		spawnParticleEffect("MiaWarp", entity_x(theCreator), entity_y(theCreator))
		playSfx("mia-appear")

		entity_alpha(eric, 0, 2)
		entity_alpha(theCreator, 0, 2)
	end
	
	watch(3)

	enableInput()
	cam_toEntity(n)
	node_activate(getNode("dt_brainFinalConfrontation"))
end