
function init(me)
	node_setElementsInLayerActive(me, 12, false)
	reconstructGrid()
end