dofile("scripts/entities/EntityInclude.lua")

n= 0
liset = false

function init(me)
	if getFlag(FLAG_LI) ~= 100 then
	node_setCursorActivation(me, true)
	end
end
	
function activate(me)
	setControlHint("You've obtained everything!", 0, 0, 0, 16)
	learnSong(SONG_SHIELD)
	learnSong(SONG_BIND)
	learnSong(SONG_ENERGYFORM)
	learnSong(SONG_BEASTFORM)
	learnSong(SONG_NATUREFORM)
	learnSong(SONG_SUNFORM)
	learnSong(SONG_FISHFORM)
	learnSong(SONG_SPIRITFORM)
	learnSong(SONG_DUALFORM)
	learnSong(SONG_LI)
	setFlag(FLAG_LI,100)
	createEntity("li", "", node_x(me), node_y(me))
	node_setCursorActivation(me, false)
	spawnParticleEffect("sunflare", node_x(me), node_y(me))
	liset = true
end 

function update(me, dt)
  if liset == true then
	liset = false
	setLi(getEntity("li"))
  end
end 