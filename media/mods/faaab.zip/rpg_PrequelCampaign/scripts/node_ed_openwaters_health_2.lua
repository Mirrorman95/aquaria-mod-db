dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 15
holderID = 9
flag = ED_OPENWATERS_HEALTH_2

dofile("scripts/include/energyslottemplate.lua")