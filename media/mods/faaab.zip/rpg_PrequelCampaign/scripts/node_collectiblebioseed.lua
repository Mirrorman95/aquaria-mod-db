dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/nodecollectibletemplate.lua"))

function init(me)
	commonInit(me, "CollectibleBioSeed", FLAG_COLLECTIBLE_BIOSEED)
end

function update(me, dt)
end
