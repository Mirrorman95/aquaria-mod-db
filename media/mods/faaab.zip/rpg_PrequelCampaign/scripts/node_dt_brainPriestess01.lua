dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Extras/Cathedral/panelPriestess01_"
entityOther = "priestnormal"
entityOtherScale = 1.7
gemToCreate = 0

flagChatBubble = DT_NEW_PRIESTESS01
flagRepeat = 0
flagVersion = DT_VERSION_PRIESTESS01
flagMain = 0

nodeActive = false
nodeClickableOnExit = true


arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2",				"elena",		"3",		"3",		0		},
		{"3",				"other",		"exit"							},
	}
	
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 3
		if numPanel == "3" then
			AlphaChatBubble()
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		
	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)
	CommonInit(me)
	CreateMapEntity(entityOther, x, y - 25, 0)
	CreateChatBubble(x + 40, y - 90, 0)
end

--UPDATE
function update(me, dt)
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	CommonActivate(me)
end