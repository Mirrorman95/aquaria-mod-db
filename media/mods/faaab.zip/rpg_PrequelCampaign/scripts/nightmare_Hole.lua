function init(me)	
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)	
	entity_setTexture(me, "rothole")
	entity_scale(me, 0.8, 0.8)

	entity_setEntityLayer(me, -2)
end

function update(me, dt)
end