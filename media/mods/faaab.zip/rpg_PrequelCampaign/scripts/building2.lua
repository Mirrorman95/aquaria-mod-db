dofile("scripts/entities/entityinclude.lua")

function init(me)
	setupEntity(me)
	entity_setEntityType(me, ET_NEUTRAL)
	entity_setTexture(me, "city-house-0003")	
	
	entity_scale(me, 1.75, 1.75)
	--entity_flipHorizontal(me)
	entity_setEntityLayer(me, -3)
end


function update(me, dt)
end