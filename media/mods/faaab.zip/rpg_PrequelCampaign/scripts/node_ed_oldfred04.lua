dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

doorID = 11
holderID = 6
flag = ED_OLDFRED_04

dofile("scripts/include/energyslottemplate.lua")