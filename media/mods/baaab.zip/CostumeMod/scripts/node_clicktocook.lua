dofile("scripts/entities/entityinclude.lua")

function init(me)
	node_setCursorActivation(me, true)
end

function activate(me)
	showInGameMenu(0,0,MENUPAGE_FOOD)
end

function update(me, dt)
end
