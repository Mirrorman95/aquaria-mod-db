dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
camDummy = 0

function init()
	n = getNaija()
	entity_setPosition(n, 0, 0)
	plush = getNode("plush")
	cam_toNode(plush)

	overrideZoom(0.5)
	watch(3)
	fade(0,4)
	overrideZoom(0.8, 26)
	watch(3)

	setControlHint("The Mithalans looked to the priestesses for answers. Delving into the Verse, they announced that Mithala had left so his people could choose their own path, but that he also wanted to see what his creations would do when he was not present.", 0, 0, 0, -1)
	watch(10)

	setControlHint("Rumors began to spread about dark spirits killing Mithalans, and though the priestesses wrote off as insane those who claimed to have witnessed such things, the public at large grew suspicious.", 0, 0, 0, -1)
	watch(10)

	fade(1,4)
	watch(3)
	loadMap("rpg_cathedralhome")
	--loadMap("rpg_intro02")
end