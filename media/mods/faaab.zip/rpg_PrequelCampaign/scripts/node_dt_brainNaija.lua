dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/common_DialogueTree.lua"))

imagePath = "panels/Naija/panelNaija_"
entityOther = "rpg_naija_l"
entityOtherScale = 1.7
gemToCreate = "naija"

flagChatBubble = DT_NEW_NAIJA
flagRepeat = DT_REPEAT_NAIJA
flagVersion = DT_VERSION_NAIJA
flagMain = DT_MAIN_NAIJA

nodeActive = false
nodeClickableOnExit = true



arrayVersion1 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3",		"3",		0		},
		{"3", 				"other",		"4"								},
		{"4", 				"elena",		"5",		0,			"5"		},
		{"5", 				"other",		"6"								},
		{"6", 				"elena",		"7a",		0,			"7b"	},
		{"7a", 				"other",		"8"								},
		{"7b", 				"other",		"8"								},
		{"8", 				"elena",		"9",		"9",		"9"		},
		{"9", 				"other",		"exit"							},
		{"R", 				"other",		"exit"							},
	}
	
	
arrayVersion2 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		0		},
		{"3a", 				"other",		"4"								},
		{"3b", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5b",		"5b"	},
		{"5a", 				"other",		"5e1"							},
		{"5b", 				"other",		"5e1"							},
		{"5e1",				"other",		"5e2"							},
		{"5e2", 			"other",		"6"								},
		{"6", 				"elena",		"7a",		"7b",		0		},
		{"7a", 				"other",		"7e1"							},
		{"7b", 				"other",		"7e1"							},
		{"7e1",				"other",		"exit"							},
	}

	
arrayVersion3 = 
	{
		--current panel		talking 		possible destination panels				
		{"1", 				"other",		"2"								},
		{"2", 				"elena",		"3a",		"3b",		"3b"	},
		{"3a", 				"other",		"4"								},
		{"3b", 				"other",		"4"								},
		{"4", 				"elena",		"5a",		"5b",		0		},
		{"5a", 				"other",		"6"								},
		{"5b", 				"other",		"6"								},
		{"6", 				"elena",		"7a",		"7b",		"7c"	},
		{"7a", 				"other",		"7a1"							},
		{"7a1",				"elena",		"7a1a",		"7a1b",		0		},
		{"7a1a", 			"other",		"6"								},
		{"7a1b",			"other",		"6"								},
		{"7b", 				"other",		"7b1"							},
		{"7b1",				"elena",		"7b1a",		"7b1b",		0		},
		{"7b1a", 			"other",		"6"								},
		{"7b1b",			"other",		"6"								},
		{"7c",				"other",		"6"								},
	}
	
--ACTION PANEL: called at the end of UpdateDT()
function ActionPanel()
	--VERSION 1
	if isFlag(flagVersion, 1) then
		--PANEL 9
		if numPanel == "9" then
			AlphaChatBubble()
			setFlag(flagRepeat, 1)
		end
		
	--VERSION 2
	elseif isFlag(flagVersion, 2) then
		--PANEL 7E1
		if numPanel == "7e1" then
			AlphaChatBubble()
		end
		
	--VERSION 3
	elseif isFlag(flagVersion, 3) then
		--PANEL 6
		if numPanel == "6" then
			AlphaChatBubble()
			setFlag(flagMain, 3)
		end
	end
end

--ACTION EXIT: called at the end of WrapupDT()
function ActionExit()
	--VERSION 1
	if isFlag(flagVersion, 1) then

	end
	
	numPanel = "1"
	currentRowID = 1
end


--INIT
function init(me)	
	--VERSION 1 and 2
	if getFlag(flagVersion) < 3 and isMapName("rpg_cathedral01") then
		CommonInit(me)
		CreateMapEntity("rpg_naija_r", x, y, 0)
		CreateChatBubble(x - 40, y - 60, 1)
		
	--VERSION 3
	elseif isFlag(flagVersion, 3) and isMapName("rpg_cathedralhome") then
		CommonInit(me)
		CreateMapEntity("rpg_naija_l", x, y, 0)
		CreateChatBubble(x + 40, y - 60, 0)
		
		--RESET GEM: naija in new location and can have new gem
		if node_isFlag(me, 1) and isFlag(RESET_GEM_NAIJA, 0) then
			node_setFlag(me, 0)
			setFlag(RESET_GEM_NAIJA, 1)
		end
	end
end

--UPDATE
function update(me, dt)	
	CommonUpdate(me, dt)
end

--ACTIVATE
function activate(me)	
	--IF MAIN ON THIS VERSION
	if getFlag(flagVersion) == getFlag(flagMain) then
		--VERSION 3
		if isFlag(flagMain, 3) then
			numPanel = "6"
		end
	end
	
	CommonActivate(me)
end