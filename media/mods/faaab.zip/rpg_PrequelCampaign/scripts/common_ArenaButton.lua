dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))

n = 0
fedor = 0
play = false
TIMER_GFX = {}


--COMMON INIT
function CommonInit(me)
	n = getNaija()
	fedor = node_getNearestEntity(me, "rpg_fedor")
end

--MENU: cleanup
function menuCleanup()	
	if entity_isEntityInRange(n, fedor, 3000) then
		setFlag(FEDOR_HANGOUT, 1)
	end
	
	setFlag(MENU_TAB, 1)
	setFlag(MENU_ACTIVE, 0)
	setFlag(MENU_EXIT, 0)
end

--TIMER: text
function placeTimerGFX(strTimer, x, y)
	--deleteTimerGFX()
	
	entityIDNum = 0
	tempVar = 0
	offset = 0
	
	--math code taken from Edwards script
	mins = math.floor(strTimer/60)
	secs = strTimer - (mins*60)
	secs1 = math.floor(secs/10)
	secs2 = secs - (secs1*10)
	
	--seconds
	entityIDNum = createEntity("vendorNum_" .. secs2, "", x + offset, y)
	entity_alpha(entityIDNum, 1, 1)
	table.insert(TIMER_GFX, entityIDNum)
	offset = offset - 20
	entityIDNum = createEntity("vendorNum_" .. secs1, "", x + offset, y)
	entity_alpha(entityIDNum, 1, 1)
	table.insert(TIMER_GFX, entityIDNum)
	offset = offset - 20
	
	--colon
	entityIDNum = createEntity("vendorColon", "", x + offset, y)
	entity_alpha(entityIDNum, 1, 1)
	table.insert(TIMER_GFX, entityIDNum)
	offset = offset - 20
	
	--minutes
	for i = string.len(mins), 1, -1  do
		tempVar = string.sub(mins, i, i)
		
		entityIDNum = createEntity("vendorNum_" .. tempVar, "", x + offset, y)
		entity_alpha(entityIDNum, 1, 1)
		table.insert(TIMER_GFX, entityIDNum)
		
		offset = offset - 20
	end
end

--TIMER: delete
function deleteTimerGFX()
	for i = 1, #TIMER_GFX do
		entity_delete(TIMER_GFX[i], 1)
		TIMER_GFX[i] = nil
	end
end