dofile("scripts/entities/entityinclude.lua")
dofile(appendUserDataPath("_mods/angryli/scripts/include.lua"))
n = 0

function init(me)
	n = getNaija()
end

function update(me, dt)

	if node_isFlag(me, 0) and node_isEntityIn(me, n) then
		node_setFlag(me, 1)
               -- put here actions to perform when naija enters the node for the first time
	end
end