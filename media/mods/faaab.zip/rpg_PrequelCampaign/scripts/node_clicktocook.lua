dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/mm_common.lua"))
dofile("scripts/entities/entityinclude.lua")

n = 0

function init(me)
	n = getNaija()
	node_setCursorActivation(me, true)
end

function activate(me)
	showInGameMenu(0,0,MENUPAGE_FOOD)
end

function update(me, dt)
	if node_isEntityIn(me, n) then
		if node_isFlag(me, 0) then
			node_foundGem(me, "kitchen")
			node_setFlag(me, 1)
		end
	end
end