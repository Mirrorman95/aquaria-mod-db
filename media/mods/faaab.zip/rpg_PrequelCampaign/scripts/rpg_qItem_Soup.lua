dofile(appendUserDataPath("_mods/rpg_PrequelCampaign/scripts/flags.lua"))
dofile("scripts/entities/entityinclude.lua")

n = 0
soup = 0

function init(me)
	n = getNaija()
	spawn = getNode("setent rpg_qItem_Soup")
	spawnIngredient("royalsoup", node_x(spawn), node_y(spawn))

	setFlag(QUEST_OLDFRED_SOUP, 2)
	setFlag(DT_VERSION_OLDFRED, 2)
	setFlag(DT_NEW_OLDFRED, 0)
	setControlHint("You have found Old Fred's soup!", 0, 0, 0, 10, "lumerean/head", 0, 0.5)
	entity_delete(me)
end

function update(me, dt)
end